package wily.factoryapi.base.client;

import com.mojang.blaze3d.systems.RenderSystem;
import wily.factoryapi.base.client.drawable.AbstractDrawableButton;
import wily.factoryapi.base.client.drawable.DrawableStatic;
import wily.factoryapi.util.FactoryScreenUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_339;
import net.minecraft.class_4068;
import net.minecraft.class_465;
import net.minecraft.class_768;

public abstract class FactoryScreenWindow<T extends class_465<?>> extends class_339 implements IWindowWidget {
    public final AbstractDrawableButton<?> config;

    private double actualMouseX;

    private double actualMouseY;

    public boolean dragging = false;

    public net.minecraft.class_2960 backgroundSprite;

    protected final class_327 font = class_310.method_1551().field_1772;

    protected final List<class_4068> nestedRenderables = new ArrayList<>();

    protected final DrawableStatic drawable;
    public T parent;

    protected int lastX;
    protected int lastY;

    public FactoryScreenWindow(AbstractDrawableButton<?> config, DrawableStatic drawable, T parent){
        super(drawable.method_3321(),drawable.method_3322(),drawable.width(), drawable.height(), class_2561.method_43473());
        this.config = config;
        this.lastX = method_46426();
        this.lastY = method_46427();
        this.parent = parent;
        this.drawable = drawable;
    }

    @Override
    public boolean isVisible() {
        return config.selected == Boolean.TRUE && config.visible.get();
    }

    public void onClose(){
        this.config.selected = false;
        Consumer<FactoryScreenWindow<?>> onClick = (w)->{ if (w.isVisible()) w.onClickWidget();};
        parent.method_25396().forEach(l-> {if (l instanceof FactoryScreenWindow<?> s) onClick.accept(s);});
        if (parent instanceof IWindowWidget w) w.getNestedRenderables().forEach(l-> {if (l instanceof FactoryScreenWindow<?> s) onClick.accept(s);});
    }

    public void onClickWidget(){
        field_22765 = 1.0F;
        parent.method_25395(this);
    }

    public void onClickOutside(double mouseX, double mouseY) {
        method_25365(false);
        field_22765 = 0.88F;
    }

    //? if >=1.21.9 {
    /*@Override
    public boolean keyPressed(KeyEvent keyEvent) {
        if (keyEvent.isEscape() && isVisible()) {
            onClose();
            return true;
        }

        return false;
    }
    *///?} else {
    @Override
    public boolean method_25404(int i, int j, int k) {
        if (i == 256 && isVisible()) {
            onClose();
            return true;
        }

        return false;
    }
    //?}

    protected void renderBg(net.minecraft.class_332 graphics, int i, int j, float f) {
        FactoryGuiMatrixStack.of(graphics.method_51448()).pushPose();
        FactoryScreenUtil.enableBlend();
        FactoryScreenUtil.enableDepthTest();
        //? if <1.21.6
        //RenderSystem.setShaderColor(1,1,1,alpha);
        if (backgroundSprite != null) FactoryGuiGraphics.of(graphics).blitSprite(backgroundSprite, method_46426(), method_46427(), field_22758, field_22759);
        else drawable.draw(graphics,method_46426(),method_46427());
        //? if >=26.1 {
        /*IWindowWidget.super.extractRenderState(graphics, i, j, f);
        *///?} else {
        IWindowWidget.super.method_25394(graphics, i, j, f);
        //?}
        //? if <1.21.6
        //RenderSystem.setShaderColor(1,1,1,1);
        FactoryScreenUtil.disableBlend();
        FactoryScreenUtil.disableDepthTest();
        FactoryGuiMatrixStack.of(graphics.method_51448()).popPose();
    }

    @Override
    public List<? extends class_4068> getNestedRenderables() {
        return nestedRenderables;
    }

    @Override
    public <R extends class_4068> R addNestedRenderable(R drawable) {
        nestedRenderables.add(drawable);
        return drawable;
    }

    //? if >=26.1 {

    /*@Override
    protected void extractWidgetRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a) {
        if (!isVisible()) return;
        renderBg(graphics, mouseX, mouseY, a);
        renderToolTip(graphics, mouseX, mouseY);
    }

    *///?} else {
    @Override
    protected void method_48579(net.minecraft.class_332 graphics, int i, int j, float f) {
        if (!isVisible()) return;
        FactoryGuiMatrixStack.of(graphics.method_51448()).pushPose();
        FactoryGuiMatrixStack.of(graphics.method_51448()).translate(0D,0D,  getBlitOffset());
        renderBg(graphics,i,j,f);
        renderToolTip(graphics, i, j);
        FactoryGuiMatrixStack.of(graphics.method_51448()).popPose();
    }
    //?}

    public float getBlitOffset(){
        return 450F;
    }

    public void renderToolTip(net.minecraft.class_332 graphics, int i, int j) {

    }

    @Override
    public boolean method_25405(double d, double e) {
        return isVisible() && FactoryScreenUtil.isMouseOver(d,e,method_46426(),method_46427(),field_22758,field_22759);
    }

    public void updateActualMouse(double mouseX, double mouseY){
        actualMouseX = mouseX;
        actualMouseY = mouseY;
    }

    public void updateLastMouse(int mouseX, int mouseY){
        lastX = mouseX;
        lastY = mouseY;
    }

    //? if >=1.21.9 {
    /*@Override
    public boolean mouseClicked(MouseButtonEvent mouseButtonEvent, boolean bl) {
        return handleClick(mouseButtonEvent.x(), mouseButtonEvent.y(), mouseButtonEvent.button()) || IWindowWidget.super.mouseClicked(mouseButtonEvent, bl);
    }

    @Override
    public boolean mouseReleased(MouseButtonEvent mouseButtonEvent) {
        return handleRelease(mouseButtonEvent.x(), mouseButtonEvent.y(), mouseButtonEvent.button()) || IWindowWidget.super.mouseReleased(mouseButtonEvent);
    }

    @Override
    public boolean mouseDragged(MouseButtonEvent mouseButtonEvent, double d, double e) {
        if (!isVisible() || ((parent.isDragging() && !dragging))) return false;
        if (IWindowWidget.super.mouseDragged(mouseButtonEvent, d, e)) return true;
        return handleDragging(mouseButtonEvent.x(), mouseButtonEvent.y(), mouseButtonEvent.button(), d, e) ;
    }

    *///?} else {
    @Override
    public boolean method_25402(double d, double e, int i) {
        return handleClick(d, e, i) || IWindowWidget.super.method_25402(d, e, i);
    }

    @Override
    public boolean method_25406(double d, double e, int i) {
        return handleRelease(d, e, i) || IWindowWidget.super.method_25406(d, e, i);
    }

    @Override
    public boolean method_25403(double x, double y, int i, double dx, double dy) {
        if (!isVisible() || ((parent.method_25397() && !dragging))) return false;
        if (IWindowWidget.super.method_25403(x, y, i, dx, dy)) return true;
        return handleDragging(x, y, i, dx, dy);
    }
    //?}

    public boolean handleClick(double d, double e, int i) {
        if (!isVisible()) return false;
        if (i == 0) {
            if (method_25405(d,e) || config.method_25405(d,e)) {
                onClickWidget();
                if (method_25405(d,e)) updateActualMouse(d, e);
            } else onClickOutside(d,e);
        }
        return false;
    }

    public boolean handleRelease(double d, double e, int i) {
        if (dragging) {
            parent.method_25398(dragging = false);;
            updateLastMouse(method_46426(),method_46427());
            return true;
        }
        return false;
    }

    public boolean handleDragging(double x, double y, int i, double dx, double dy) {
        if (i == 0 && ((method_25405(x, y) || dragging))) {
            double newX =  (lastX + x - actualMouseX);
            double newY = (lastY + y - actualMouseY);
            if (newX + field_22758 < parent.field_22789 && newX > 0 )
                method_46421((int) newX);
            if (newY + field_22759 < parent.field_22790 && newY > 0)
                method_46419((int)newY);
            parent.method_25398(dragging = true);
            return true;
        }
        return false;
    }

    public class_768 getBounds() {
        return new class_768(method_46426(),method_46427(),field_22758,field_22759);
    }

}

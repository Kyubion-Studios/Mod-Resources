//? if >=1.21.6 && <1.21.9 {
package wily.factoryapi.base.client;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_11231;
import net.minecraft.class_11244;
import net.minecraft.class_3532;
import net.minecraft.class_4588;
import net.minecraft.class_8030;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2f;

// Backport from 1.21.9
public record TiledBlitRenderState(
	RenderPipeline pipeline,
	class_11231 textureSetup,
	Matrix3x2f pose,
	int tileWidth,
	int tileHeight,
	int x0,
	int y0,
	int x1,
	int y1,
	float u0,
	float u1,
	float v0,
	float v1,
	int color,
	@Nullable class_8030 scissorArea,
	@Nullable class_8030 bounds
) implements class_11244 {
	public TiledBlitRenderState(
		RenderPipeline renderPipeline,
		class_11231 textureSetup,
		Matrix3x2f matrix3x2f,
		int i,
		int j,
		int k,
		int l,
		int m,
		int n,
		float f,
		float g,
		float h,
		float o,
		int p,
		@Nullable class_8030 screenRectangle
	) {
		this(renderPipeline, textureSetup, matrix3x2f, i, j, k, l, m, n, f, g, h, o, p, screenRectangle, getBounds(k, l, m, n, matrix3x2f, screenRectangle));
	}

	@Override
	public void method_70917(class_4588 vertexConsumer, float level) {
		int i = this.x1() - this.x0();
		int j = this.y1() - this.y0();

		for (int k = 0; k < i; k += this.tileWidth()) {
			int l = i - k;
			int m;
			float f;
			if (this.tileWidth() <= l) {
				m = this.tileWidth();
				f = this.u1();
			} else {
				m = l;
				f = class_3532.method_16439((float)l / this.tileWidth(), this.u0(), this.u1());
			}

			for (int n = 0; n < j; n += this.tileHeight()) {
				int o = j - n;
				int p;
				float g;
				if (this.tileHeight() <= o) {
					p = this.tileHeight();
					g = this.v1();
				} else {
					p = o;
					g = class_3532.method_16439((float)o / this.tileHeight(), this.v0(), this.v1());
				}

				int q = this.x0() + k;
				int r = this.x0() + k + m;
				int s = this.y0() + n;
				int t = this.y0() + n + p;
				vertexConsumer.method_70815(this.pose(), q, s, level).method_22913(this.u0(), this.v0()).method_39415(this.color());
				vertexConsumer.method_70815(this.pose(), q, t, level).method_22913(this.u0(), g).method_39415(this.color());
				vertexConsumer.method_70815(this.pose(), r, t, level).method_22913(f, g).method_39415(this.color());
				vertexConsumer.method_70815(this.pose(), r, s, level).method_22913(f, this.v0()).method_39415(this.color());
			}
		}
	}

	@Nullable
	private static class_8030 getBounds(int i, int j, int k, int l, Matrix3x2f matrix3x2f, @Nullable class_8030 screenRectangle) {
		class_8030 screenRectangle2 = new class_8030(i, j, k - i, l - j).method_71523(matrix3x2f);
		return screenRectangle != null ? screenRectangle.method_49701(screenRectangle2) : screenRectangle2;
	}
}
//?}

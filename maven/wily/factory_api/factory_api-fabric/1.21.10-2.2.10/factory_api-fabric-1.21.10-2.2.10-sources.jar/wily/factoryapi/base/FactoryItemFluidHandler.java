package wily.factoryapi.base;

//? if >=26.2 {
/*import net.minecraft.world.level.block.entity.BlockEntityTypes;
*///?}
import org.jetbrains.annotations.NotNull;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.ItemContainerPlatform;
import wily.factoryapi.init.FactoryRegistries;
import wily.factoryapi.util.CompoundTagUtil;
import wily.factoryapi.util.FluidInstance;
import java.util.function.Function;
import java.util.function.Predicate;
//? if <1.20.5
//import static net.minecraft.world.item.BlockItem.BLOCK_ENTITY_TAG;
import net.minecraft.class_11580;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2591;
import net.minecraft.class_9331;
import net.minecraft.class_9334;

public class FactoryItemFluidHandler extends FactoryFluidHandler implements IPlatformItemFluidHandler {
    private final class_1799 container;

    public FactoryItemFluidHandler(int capacity, class_1799 container) {
        this(capacity, container, f -> true, TransportState.EXTRACT_INSERT);

    }

    public FactoryItemFluidHandler(int capacity, class_1799 stack, Predicate<FluidInstance> validator, TransportState transportState) {
        super(capacity, null, validator, SlotsIdentifier.GENERIC, transportState);
        this.container = stack;

    }

    //? if <1.20.5 {
    /*private CompoundTag getFluidCompound(ItemStack stack){
        return isBlockItem() ? stack.getOrCreateTag().getCompound(BLOCK_ENTITY_TAG).getCompound("singleTank") : stack.getOrCreateTag().getCompound(getStorageKey());
    }
    *///?}

    public String getStorageKey() {
        return isBlockItem() ? "singleTank" : /*? if fabric {*/"fluidVariant"/*?} else {*//*"Fluid"*//*?}*/;
    }

    public boolean isBlockItem() {
        return ItemContainerPlatform.isBlockItem(container);
    }

    @Override
    public void setFluid(FluidInstance fluid) {
        boolean b = isBlockItem();
        //? if <1.20.5 {
        /*CompoundTag tag = container.getOrCreateTag();
        if (b) tag = tag.getCompound(BLOCK_ENTITY_TAG);
        int capacity = getMaxFluid();
        CompoundTag newTag = FluidInstance.toTag(fluid);
        newTag.putInt("capacity",capacity);
        tag.put(getStorageKey(), newTag);
        if (b) container.getTag().put(BLOCK_ENTITY_TAG, tag);
        *///?} else {
        if (b) {
            int capacity = getMaxFluid();
            //? if >=1.21.9 {
            class_2487 beTag = container.method_57826(class_9334.field_49611) ? container.method_58694(class_9334.field_49611).method_72540() : new class_2487();
            //?} else {
            /*CompoundTag beTag = container.getOrDefault(DataComponents.BLOCK_ENTITY_DATA, CustomData.EMPTY).copyTag();
            *///?}
            class_2487 tag = FluidInstance.toTag(fluid);
            tag.method_10569("capacity", capacity);
            beTag.method_10566(getStorageKey(), tag);
            //? if >=1.21.9 {
            //TODO Check if this will cause problems when placing the block
            container.method_57379(class_9334.field_49611, class_11580.method_72535(/*? if <26.2 {*/class_2591/*?} else {*//*BlockEntityTypes*//*?}*/.field_11914, beTag));
            //?} else {
            /*container.set(DataComponents.BLOCK_ENTITY_DATA, CustomData.of(beTag));
            *///?}
        } else {
            container.method_57379(FactoryRegistries.FLUID_INSTANCE_COMPONENT.get(), fluid);
        }
        //?}
    }

    @Override
    public @NotNull FluidInstance getFluidInstance() {
        return /*? if <1.20.5 {*//*FluidInstance.fromTag(getFluidCompound(container))*//*?} else {*/ isBlockItem() ? getFromComponentOrDefault(container,class_9334.field_49611, /*? if >=1.21.9 {*/class_11580::method_72540/*?} else {*//*CustomData::copyTag*//*?}*/, c-> FluidInstance.fromTag(CompoundTagUtil.getCompoundTagOrEmpty(c, getStorageKey())),c-> c.method_10545(getStorageKey()), FluidInstance.empty()) : container.method_58695(FactoryRegistries.FLUID_INSTANCE_COMPONENT.get(), FluidInstance.empty())/*?}*/;
    }

    //? if <1.20.5 {
    /*@Override
    public void deserializeTag(CompoundTag tag) {
        getFluidCompound(container).put(getStorageKey(),tag);
    }

    @Override
    public CompoundTag serializeTag() {
        return getFluidCompound(container);
    }
    *///?} else {
    public static <C,D,T> T getFromComponentOrDefault(class_1799 stack, class_9331<C> type, Function<C,D> getter, Function<D,T> mapper, Predicate<D> allow, T obj){
        D d;
        return !stack.method_57826(type) || !allow.test(d=getter.apply(stack.method_58694(type))) ? obj : mapper.apply(d);
    }
    //?}
    @Override
    public int fill(FluidInstance resource, boolean simulate) {
        if (container.method_7947() != 1 || resource.isEmpty() || !isFluidValid(resource)){
            return 0;
        }

        FluidInstance contained = this.getFluidInstance().copy();
        if (contained.isEmpty())
        {
            int fillAmount = Math.min(getMaxFluid(), resource.getAmount());

            if (!simulate)
            {
                FluidInstance filled = resource.copy();
                filled.setAmount(fillAmount);
                setFluid(filled);
            }

            return fillAmount;
        }
        else
        {
            if (contained.isFluidEqual(resource))
            {
                int fillAmount = Math.min(getMaxFluid() - contained.getAmount(), resource.getAmount());

                if (!simulate && fillAmount > 0) {
                    contained.grow(fillAmount);
                    setFluid(contained);
                }

                return fillAmount;
            }

            return 0;
        }
    }

    @Override
    public @NotNull FluidInstance drain(int maxDrain, boolean simulate) {
        if (container.method_7947() != 1 || maxDrain <= 0 || !getTransport().canExtract()) return FluidInstance.empty();

        FluidInstance contained = this.getFluidInstance().copy();
        if (contained.isEmpty())
            return FluidInstance.empty();

        final int drainAmount = Math.min(contained.getAmount(), maxDrain);

        FluidInstance drained = contained.copy();
        drained.setAmount(drainAmount);

        if (!simulate) {
            contained.shrink(drainAmount);
            if (contained.isEmpty())
                setContainerToEmpty();
            else setFluid(contained);
        }

        return drained;
    }

    protected void setContainerToEmpty() {
        //? if <1.20.5 {
        /*container.removeTagKey(getStorageKey());
        *///?} else {
        container.method_57381(FactoryRegistries.FLUID_INSTANCE_COMPONENT.get());
        container.method_57381(FactoryRegistries.FLUID_CAPACITY_COMPONENT.get());
        //?}
    }

    @Override
    public void setCapacity(int capacity) {
        boolean b = isBlockItem();
        //? if <1.20.5 {
        /*CompoundTag tag = container.getOrCreateTag();
        if (b) tag = tag.getCompound(BLOCK_ENTITY_TAG);
        CompoundTag newTag = getFluidCompound(container);
        newTag.putInt("capacity",capacity);
        tag.put(getStorageKey(), newTag);
        if (b) container.getTag().put(BLOCK_ENTITY_TAG, tag);
        *///?} else {
        if (b) {
            //? if >=1.21.9 {
            class_2487 beTag = container.method_57826(class_9334.field_49611) ? container.method_58694(class_9334.field_49611).method_72540() : new class_2487();
            //?} else {
            /*CompoundTag beTag = container.getOrDefault(DataComponents.BLOCK_ENTITY_DATA, CustomData.EMPTY).copyTag();
             *///?}
            class_2487 tag = CompoundTagUtil.getCompoundTagOrEmpty(beTag, getStorageKey());
            tag.method_10569("capacity",capacity);
            beTag.method_10566(getStorageKey(),tag);
            //? if >=1.21.9 {
            //TODO Check if this will cause problems when placing the block
            container.method_57379(class_9334.field_49611, class_11580.method_72535(/*? if <26.2 {*/class_2591/*?} else {*//*BlockEntityTypes*//*?}*/.field_11914, beTag));
            //?} else {
            /*container.set(DataComponents.BLOCK_ENTITY_DATA, CustomData.of(beTag));
             *///?}
        } else {
            container.method_57379(FactoryRegistries.FLUID_CAPACITY_COMPONENT.get(), capacity);
        }
        //?}
    }

    @Override
    public int getMaxFluid() {
        return /*? if <1.20.5 {*/ /*getFluidCompound(container).contains("capacity") ? getFluidCompound(container).getInt("capacity") : super.getMaxFluid() *//*?} else {*/ isBlockItem() ? getFromComponentOrDefault(container,class_9334.field_49611, /*? if >=1.21.9 {*/class_11580::method_72540/*?} else {*//*CustomData::copyTag*//*?}*/, c-> CompoundTagUtil.getInt(c, getStorageKey()).orElse(0),c-> c.method_10545(getStorageKey()), super.getMaxFluid()) : container.method_58695(FactoryRegistries.FLUID_CAPACITY_COMPONENT.get(),super.getMaxFluid()) /*?}*/;
    }

    @Override
    public class_1799 getContainer() {
        return container;
    }
}

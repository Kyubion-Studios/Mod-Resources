package wily.factoryapi.base.client;

import wily.factoryapi.util.ListMap;

import java.util.Map;
import net.minecraft.class_10042;
import net.minecraft.class_1304;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_3879;

public interface IFactoryItemClientExtension {
    // Map used only to store the IFactoryItem instances with client extensions, not meant to be modified externally, as can result in unexpected behaviour between mod loaders
    Map<class_1792, IFactoryItemClientExtension> map = new ListMap<>();
    /**
     * Its use is only for BlockItem instances
     * By default, returns vanilla's item renderer.
     */
    default IFactoryBlockEntityWLRenderer getCustomRenderer() {
        return null;
    }
    default <T extends class_3879> T getHumanoidArmorModel(/*? if >=1.21.2 && !neoforge {*/class_10042 livingEntityRenderState,/*?} else if <1.21.2 {*//*LivingEntity livingEntity,*//*?}*/ class_1799 itemStack, class_1304 equipmentSlot, T original){
        return original;
    }
    //? if >=1.21.2 && neoforge {
    /*default Model getHumanoidArmorModel(ItemStack stack, /^? if <1.21.4 {^/ EquipmentModel.LayerType/^?} else {^//^EquipmentClientInfo.LayerType^//^?}^/ layerType, Model original){
        return getHumanoidArmorModel(stack,layerType == /^? if <1.21.4 {^/ EquipmentModel.LayerType/^?} else {^//^EquipmentClientInfo.LayerType^//^?}^/.HUMANOID_LEGGINGS ? EquipmentSlot.LEGS : EquipmentSlot.CHEST, original);
    }
    *///?}

}

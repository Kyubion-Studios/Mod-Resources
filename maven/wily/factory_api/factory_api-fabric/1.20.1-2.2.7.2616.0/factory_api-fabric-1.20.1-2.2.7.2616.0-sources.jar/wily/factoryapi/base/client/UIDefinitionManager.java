package wily.factoryapi.base.client;

import com.google.gson.JsonElement;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.Dynamic;
import com.mojang.serialization.JsonOps;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_2588;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_329;
import net.minecraft.class_3298;
import net.minecraft.class_3300;
import net.minecraft.class_339;
import net.minecraft.class_3518;
import net.minecraft.class_3532;
import net.minecraft.class_357;
import net.minecraft.class_3802;
import net.minecraft.class_3871;
import net.minecraft.class_3873;
import net.minecraft.class_3874;
import net.minecraft.class_3928;
import net.minecraft.class_3979;
import net.minecraft.class_4013;
import net.minecraft.class_404;
import net.minecraft.class_407;
import net.minecraft.class_408;
import net.minecraft.class_410;
import net.minecraft.class_412;
import net.minecraft.class_4185;
import net.minecraft.class_4189;
import net.minecraft.class_420;
import net.minecraft.class_422;
import net.minecraft.class_423;
import net.minecraft.class_424;
import net.minecraft.class_426;
import net.minecraft.class_4286;
import net.minecraft.class_4288;
import net.minecraft.class_429;
import net.minecraft.class_4325;
import net.minecraft.class_433;
import net.minecraft.class_434;
import net.minecraft.class_435;
import net.minecraft.class_436;
import net.minecraft.class_437;
import net.minecraft.class_4381;
import net.minecraft.class_4389;
import net.minecraft.class_4395;
import net.minecraft.class_440;
import net.minecraft.class_442;
import net.minecraft.class_443;
import net.minecraft.class_445;
import net.minecraft.class_446;
import net.minecraft.class_447;
import net.minecraft.class_457;
import net.minecraft.class_458;
import net.minecraft.class_466;
import net.minecraft.class_471;
import net.minecraft.class_472;
import net.minecraft.class_476;
import net.minecraft.class_479;
import net.minecraft.class_480;
import net.minecraft.class_486;
import net.minecraft.class_488;
import net.minecraft.class_489;
import net.minecraft.class_4895;
import net.minecraft.class_490;
import net.minecraft.class_4905;
import net.minecraft.class_494;
import net.minecraft.class_495;
import net.minecraft.class_500;
import net.minecraft.class_524;
import net.minecraft.class_525;
import net.minecraft.class_5250;
import net.minecraft.class_526;
import net.minecraft.class_5375;
import net.minecraft.class_5819;
import net.minecraft.class_6599;
import net.minecraft.class_6777;
import net.minecraft.class_7944;
import net.minecraft.class_8032;
import net.minecraft.class_8219;
import net.minecraft.client.gui.screens.*;
import net.minecraft.client.gui.screens.inventory.*;
import net.minecraft.util.*;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIClient;
import wily.factoryapi.FactoryAPIPlatform;
import wily.factoryapi.base.ArbitrarySupplier;
import wily.factoryapi.base.Bearer;
import wily.factoryapi.util.*;

import java.io.BufferedReader;
import java.io.IOException;
import java.util.*;
import java.util.function.*;
import java.util.stream.IntStream;

public class UIDefinitionManager implements class_4013 {
    public static final String UI_DEFINITIONS = "ui_definitions";
    public static final ListMap<net.minecraft.class_2960,Class<?>> NAMED_UI_TARGETS = new ListMap.Builder<String,Class<?>>().put("screen", class_437.class).put("accessibility_onboarding_screen", class_8032.class).put("title_screen",class_442.class).put("options_screen", class_429.class).put("skin_customization_screen", class_440.class).put("video_settings_screen", class_446.class).put("language_select_screen", class_426.class).put("pack_selection_screen", class_5375.class).put("telemetry_info_screen", class_7944.class).put("online_options_screen", class_6777.class).put("sound_options_screen", class_443.class).put("controls_screen", class_458.class).put("mouse_settings_screen", class_4288.class).put("key_binds_screen", class_6599.class).put("chat_options_screen", class_404.class).put("accessibility_options_screen", class_4189.class).put("credits_and_attribution_screen", class_8219.class).put("win_screen", class_445.class).put("confirm_link_screen", class_407.class).put("select_world_screen", class_526.class).put("create_world_screen", class_525.class).put("edit_world_screen", class_524.class).put("join_multiplayer_screen", class_500.class)./*? if <1.21.9 {*/put("edit_server_screen", class_422.class)./*?}*/put("direct_join_server_screen", class_420.class).put("realms_main_screen", class_4325.class).put("realms_screen", class_4905.class).put("realms_confirm_screen", class_4389.class).put("realms_backup_screen", class_4381.class).put("realms_invite_screen", class_4395.class).put("share_to_lan_screen", class_436.class).put("advancements_screen", class_457.class).put("stats_screen", class_447.class).put("confirm_screen", class_410.class).put("level_loading_screen", class_3928.class).put("progress_screen", class_435.class).put("generic_message_screen",/*? if <1.20.5 {*/class_424/*?} else {*//*GenericMessageScreen*//*?}*/.class)./*? if <1.21.9 {*/put("receiving_level_screen", class_434.class)./*?}*/put("connect_screen", class_412.class).put("pause_screen", class_433.class).put("inventory_screen", class_490.class).put("crafting_screen", class_479.class).put("container_screen", class_476.class).put("abstract_furnace_screen", class_489.class).put("furnace_screen", class_3873.class).put("smoker_screen", class_3874.class).put("blast_furnace_screen", class_3871.class).put("loom_screen", class_494.class).put("stonecutter_screen", class_3979.class).put("grindstone_screen", class_3802.class).put("enchantment_screen", class_486.class).put("hopper_screen", class_488.class).put("dispenser_screen", class_480.class).put("shulker_box_screen", class_495.class).put("anvil_screen", class_471.class).put("smithing_screen", class_4895.class).put("brewing_stand_screen", class_472.class).put("beacon_screen", class_466.class).put("chat_screen", class_408.class).put("in_bed_chat_screen", class_423.class).put("gui", class_329.class).mapKeys(FactoryAPI::createVanillaLocation).build();
    public static final ListMap<net.minecraft.class_2960, Function<class_437, class_437>> DEFAULT_SCREENS_MAP = new ListMap.Builder<String, Function<class_437, class_437>>().put("title", s -> new class_442()).put("options", s -> new class_429(s, class_310.method_1551().field_1690/*? if >=26.1 {*//*, Minecraft.getInstance().level != null*//*?}*/)).put("language_select", s -> new class_426(s, class_310.method_1551().field_1690, class_310.method_1551().method_1526())).put("video_settings", s -> new class_446(s,/*? if >=1.21 {*//*Minecraft.getInstance() ,*//*?}*/ class_310.method_1551().field_1690)).put("skin_customization", s -> new class_440(s, class_310.method_1551().field_1690)).put("online_options", s -> /*? if <1.21 {*/class_6777.method_47621(class_310.method_1551(), s, class_310.method_1551().field_1690)/*?} else {*//*new OnlineOptionsScreen(s, Minecraft.getInstance().options)*//*?}*/).put("controls", s -> new class_458(s, class_310.method_1551().field_1690)).put("mouse_settings", s -> new class_4288(s, class_310.method_1551().field_1690)).put("key_binds", s -> new class_6599(s, class_310.method_1551().field_1690)).put("chat_options", s -> new class_404(s, class_310.method_1551().field_1690)).put("accessibility_options", s -> new class_4189(s, class_310.method_1551().field_1690)).put("credits_and_attribution", class_8219::new).put("select_world", class_526::new).mapKeys(FactoryAPI::createVanillaLocation).build();


    public static void registerNamedUITarget(net.minecraft.class_2960 id, Class<?> uiClass) {
        NAMED_UI_TARGETS.put(id, uiClass);
    }

    public static void registerNamedUITarget(String path, Class<?> uiClass) {
        registerNamedUITarget(FactoryAPI.createVanillaLocation(path), uiClass);
    }

    public static void registerDefaultScreen(net.minecraft.class_2960 id, Function<class_437, class_437> defaultScreen) {
        DEFAULT_SCREENS_MAP.put(id, defaultScreen);
    }

    public static void registerDefaultScreen(String path, Function<class_437, class_437> defaultScreen) {
        registerDefaultScreen(FactoryAPI.createVanillaLocation(path), defaultScreen);
    }

    @Override
    public String method_22322() {
        return "factoryapi:ui_definition_manager";
    }


    public record ElementValue<T>(String name, Function<UIAccessor, T> value) implements UIDefinition {
        @Override
        public void beforeInit(UIAccessor accessor) {
            accessor.getElements().put(name, () -> value.apply(accessor));
        }
    }

    public interface WidgetAction<P, W extends class_339> {
        ListMap<net.minecraft.class_2960, WidgetAction<?, class_339>> map = new ListMap.Builder<String, WidgetAction<?, class_339>>().put("open_default_screen", create(net.minecraft.class_2960.field_25139, (s) -> (a, w, t) -> class_310.method_1551().method_1507(DEFAULT_SCREENS_MAP.getOrDefault(s, s1 -> null).apply(a.getScreen())))).put("open_config_screen", create(Codec.STRING, (s) -> (a, w, t) -> class_310.method_1551().method_1507(FactoryAPIClient.getConfigScreen(FactoryAPIPlatform.getModInfo(s), a.getScreen())))).put("reload_ui", create(Codec.EMPTY.codec(), (s) -> (a, w, t) -> a.reloadUI())).put("run_command", createRunCommand(s -> true)).put("run_windows_command", createRunCommand(s -> class_156.method_668() == class_156.class_158.field_1133)).put("run_linux_command", createRunCommand(s -> class_156.method_668() == class_156.class_158.field_1135)).put("run_osx_command", createRunCommand(s -> class_156.method_668() == class_156.class_158.field_1137)).put("toggle_datapacks", createToggleDatapacks()).mapKeys(FactoryAPI::createVanillaLocation).build();
        Codec<WidgetAction<?, class_339>> CODEC = map.createCodec(net.minecraft.class_2960.field_25139);

        Codec<P> getCodec();

        enum Type {
            ENABLE,DISABLE
        }

        interface PressSupplier<W extends class_339> {
            void press(UIAccessor accessor, W widget, Type type);
        }

        PressSupplier<W> press(P result);

        record CycleEntry(class_2561 message, List<PressSupplier<class_339>> actions) {

        }

        default Optional<PressSupplier<W>> press(Predicate<UIAccessor> canApply, Dynamic<?> dynamic) {
            return getCodec().parse(dynamic).result().or(() -> dynamic.get("value").get().result().flatMap(d -> getCodec().parse(d).result())).map(p -> (a, w, type) -> {
                if (canApply.test(a)) press(p).press(a, w, type);
            });
        }

        static WidgetAction<String, class_339> createRunCommand(Predicate<String> shouldRun) {
            return create(Codec.STRING, (s) -> (a, w, t) -> {
                if (shouldRun.test(s)) {
                    try {
                        new ProcessBuilder(s.split(" ")).start();
                    } catch (IOException e) {
                        FactoryAPI.LOGGER.warn(e.getMessage());
                    }
                }
            });
        }



        static WidgetAction<List<String>, class_339> createToggleDatapacks() {
            return create(Codec.STRING.listOf(), (s) -> (a, w, t) -> {
                if (a instanceof DatapackRepositoryAccessor datapackAccessor) {
                    class_3283 repo = datapackAccessor.getDatapackRepository();
                    switch (t) {
                        case ENABLE -> {
                            List<String> datapacks = new ArrayList<>(s);
                            datapacks.removeIf(pack-> !repo.method_29207(pack));
                            Collections.reverse(datapacks);
                            datapacks.addAll(0, repo.method_29210());
                            repo.method_14447(datapacks);
                            datapackAccessor.tryApplyNewDataPacks(repo);
                        }
                        case DISABLE -> {
                            List<String> datapacks = new ArrayList<>(repo.method_29210());
                            datapacks.removeIf(s::contains);
                            repo.method_14447(datapacks);
                            datapackAccessor.tryApplyNewDataPacks(repo);
                        }
                    }
                }
            });
        }

        static <P, W extends class_339> WidgetAction<P, W> create(Codec<P> codec, Function<P,PressSupplier<W>> onPress) {
            return new WidgetAction<>() {
                @Override
                public Codec<P> getCodec() {
                    return codec;
                }

                @Override
                public PressSupplier<W> press(P result) {
                    return onPress.apply(result);
                }
            };
        }
    }

    public static class_4286 createCheckbox(boolean selected, BiConsumer<class_4286, Boolean> onPress) {
        //? if >1.20.1 {
        /*return Checkbox.builder(Component.empty(), Minecraft.getInstance().font).selected(selected).onValueChange(onPress::accept).build();
        *///?} else {
        return new class_4286(0,0,20,20,class_2561.method_43473(), selected) {
            @Override
            public void method_25306() {
                super.method_25306();
                onPress.accept(this,method_20372());
            }
        };
        //?}
    }

    public static List<Integer> parseIntRange(String s) {
        if (!s.contains(",")) return Collections.singletonList(Integer.parseInt(s));
        String[] numbers = s.split(",");
        List<Integer> range = new ArrayList<>();
        for (int i = 0; i < numbers.length; i++) {
            boolean closed;
            if ((closed = numbers[i].startsWith("[")) || numbers[i].startsWith("]")) {
                int start = Integer.parseInt(numbers[i].substring(1));
                i++;
                boolean endClosed;
                if (!(endClosed = numbers[i].endsWith("]")) && !numbers[i].endsWith("[")) {
                    FactoryAPI.LOGGER.warn("Incorrect integer interval syntax at ordinal {}, skipping this. \nInteger Range: {}",i-1,s);
                }else {
                    int end = Integer.parseInt(numbers[i].replace(endClosed ? "]" : "[",""));
                    IntStream.rangeClosed(start + (closed ? 0: -class_3532.method_17822(start)),end + (endClosed ? 0: -class_3532.method_17822(end))).forEach(range::add);
                }
            } else range.add(Integer.parseInt(numbers[i]));
        }
        return range;
    }

    public interface ElementType {
        ListMap<net.minecraft.class_2960, ElementType> map = new ListMap<>();

        ElementType CHILDREN = registerConditional("children", (definition, accessorFunction, name, e) -> parseAllElements(definition, accessorFunction, e, s -> e.get("applyPrefix").asBoolean(true) ? (name+"."+s) : s));
        ElementType ADD_BUTTON = registerConditional("add_button", (definition, accessorFunction, name, e) -> {
            List<WidgetAction.PressSupplier<class_339>> actions = parseActionsElement(definition, name, e);
            parseWidgetElements(definition, name, e);
            definition.addStatic(UIDefinition.createAfterInit(a -> a.putWidget(name, accessorFunction.apply(a).addChild(name, class_4185.method_46430(class_2561.method_43473(), b -> actions.forEach(c -> c.press(a, b, WidgetAction.Type.ENABLE))).method_46431()))));
        });
        ElementType ADD_CHECKBOX = registerConditional("add_checkbox", (definition, accessorFunction, name, e) -> {
            List<WidgetAction.PressSupplier<class_339>> actions = parseActionsElement(definition, name, e);
            parseWidgetElements(definition, name, e);
            parseElement(definition, name, e, "selected", ElementType::parseBoolean);
            definition.addStatic(UIDefinition.createAfterInit(a -> a.putWidget(name, accessorFunction.apply(a).addChild(name, createCheckbox(a.getBoolean(name + ".selected"), (c, b) -> {
                actions.forEach(c1 -> c1.press(a, c, c.method_20372() ? WidgetAction.Type.ENABLE : WidgetAction.Type.DISABLE));
            })))));
        });
        ElementType ADD_SLIDER = registerConditional("add_slider", (definition, accessorFunction, name, e) -> {
            List<WidgetAction.CycleEntry> entries = e.get("entries").asList(d-> new WidgetAction.CycleEntry(d.get("message").flatMap(DynamicUtil.getComponentCodec()::parse).result().orElse(class_2561.method_43473()), parseActionsElement(definition, name, d)));
            parseElement(definition, name, e, "initialIndex", ElementType::parseNumber);
            parseWidgetElements(definition, name, e);
            definition.addStatic(UIDefinition.createAfterInit(a -> {
                a.putWidget(name, accessorFunction.apply(a).addChild(name, new class_357(0, 0, 200, 20, class_2561.method_43473(), Math.min(entries.size() - 1, a.getInteger(name + "initialIndex", 0) / (entries.size() - 1d))) {
                    WidgetAction.CycleEntry entry = getActualEntry();

                    @Override
                    protected void method_25346() {
                        method_25355(entry.message());
                    }

                    private WidgetAction.CycleEntry getActualEntry() {
                        return entries.get((int) ((entries.size() - 1 ) * field_22753));
                    }

                    @Override
                    protected void method_25344() {
                        WidgetAction.CycleEntry oldEntry = entry;
                        entry = getActualEntry();
                        if (!entry.equals(oldEntry)) {
                            oldEntry.actions().forEach(action-> action.press(a, this, WidgetAction.Type.DISABLE));
                            entry.actions().forEach(action -> action.press(a, this, WidgetAction.Type.ENABLE));
                        }
                    }
                })).method_25346();
            }));
        });
        ElementType MODIFY_WIDGET = registerConditional("modify_widget", createIndexable(i -> (definition, accessorFunction, name, e) -> {
            List<WidgetAction.PressSupplier<class_339>> actions = parseActionsElement(definition, name, e);
            i.forEach(index -> parseWidgetElements(definition, name + (i.size() == 1 ? "" : "_" + index), e));
            definition.addStatic(UIDefinition.createAfterInit(a -> {
                Consumer<class_339> onPressOverride = actions.isEmpty() ? null : w-> actions.forEach(action-> action.press(a, w, WidgetAction.Type.ENABLE));
                Bearer<Integer> count = Bearer.of(0);
                a.getElements().put(name + ".index", count);
                for (Integer index : i)
                    if (a.getChildren().size() > index && a.getChildren().get(index) instanceof class_339 w) {
                        String suffixedName = name + (i.size() == 1 ? "" : "_" + index);
                        if (onPressOverride != null) a.putStaticElement(suffixedName+".onPressOverride", onPressOverride);
                        accessorFunction.apply(a).putWidget(suffixedName, w);
                        count.set(count.get() + 1);
                    }
            }));
        }));
        ElementType REMOVE_WIDGET = registerConditional("remove_widget", createIndexable(i -> (definition, accessorFunction, name, e) -> definition.addStatic(UIDefinition.createAfterInit(a -> {
            for (Integer index : i)
                if (a.getChildren().size() > index)
                    accessorFunction.apply(a).removeChild(a.getChildren().get(index));
        }))));
        ElementType PUT_NUMBER = registerConditional("put_number", (definition, accessorFunction, name, e) -> parseElement(definition, name, e, "value", (s, d) -> parseNumber(name, d)));
        ElementType PUT_COMPONENT = registerConditional("put_component", (definition, accessorFunction, name, e) -> parseElement(definition, name, e, "value", (s, d) -> parseComponentElement(name, d)));
        ElementType PUT_STRING = registerCodec("put_string", Codec.STRING);
        ElementType PUT_BOOLEAN = registerConditional("put_boolean", (definition, accessorFunction, name, e) -> parseElement(definition, name, e, "value", (s, d) -> parseBoolean(name, d)));
        ElementType PUT_RESOURCE_LOCATION = registerCodec("put_resource_location", net.minecraft.class_2960.field_25139);
        ElementType PUT_VEC3 = registerCodec("put_vec3", DynamicUtil.VEC3_OBJECT_CODEC);
        ElementType PUT_VEC2 = registerCodec("put_vec2", DynamicUtil.VEC2_CODEC);
        ElementType BLIT = registerConditional("blit", ElementType::parseBlitElements);
        ElementType BLIT_SPRITE = registerConditional("blit_sprite", ElementType::parseBlitSpriteElements);
        ElementType BLIT_CUSTOM_SPRITE = registerConditional("blit_custom_sprite", ElementType::parseBlitCustomSpriteElements);
        ElementType FILL = registerConditional("fill", ElementType::parseFillElements);
        ElementType FILL_GRADIENT = registerConditional("fill_gradient", ElementType::parseFillGradientElements);
        ElementType DRAW_STRING = registerConditional("draw_string", ElementType::parseDrawStringElements);
        ElementType DRAW_MULTILINE_STRING = registerConditional("draw_multiline_string", ElementType::parseDrawMultilineStringElements);
        ElementType RENDER_ITEM = registerConditional("render_item", ElementType::parseRenderItemElements);
        ElementType RENDER_ITEMS = registerConditional("render_items", ElementType::parseRenderItemsElements);
        ElementType COMPARE_ITEMS = registerConditional("compare_items", ((uiDefinition, accessorFunction, elementName, element) -> {
            parseElements(uiDefinition, elementName, element, ElementType::parseItemStackElement, "firstItem", "secondItem");
            parseElements(uiDefinition, elementName, element, ElementType::parseBoolean, "checkCount", "strict");
            uiDefinition.addStatic(UIDefinition.createBeforeInit(a -> a.getElements().put(elementName, () -> FactoryItemUtil.compareItems(a.getItemStack(elementName+".firstItem"), a.getItemStack(elementName+".secondItem"), a.getBoolean(elementName+".checkCount",true), a.getBoolean(elementName+".strict",true)))));
        }));
        ElementType CHANCE = registerConditional("chance", ((uiDefinition, accessorFunction, elementName, element) -> {
            class_5819 rand = class_5819.method_43047();
            parseElements(uiDefinition, elementName, element, ElementType::parseNumber, "min", "max");
            uiDefinition.addStatic(UIDefinition.createBeforeInit(a -> a.getElements().put(elementName, () -> rand.method_43051(a.getInteger(elementName+".min", 0), a.getInteger(elementName+".max", 0)))));
        }));

        static void parseWidgetElements(UIDefinition uiDefinition, String elementName, Dynamic<?> element) {
            parseElements(uiDefinition, elementName, element, ElementType::parseNumber, "x", "y", "width", "height", "order");
            parseElements(uiDefinition, elementName, element, (s, d) -> parseComponentElement(elementName, s, d), "message", "tooltip");
            parseElement(uiDefinition, elementName, element, "spriteOverride", net.minecraft.class_2960.field_25139);
            parseElement(uiDefinition, elementName, element, "highlightedSpriteOverride", net.minecraft.class_2960.field_25139);
            parseElement(uiDefinition, elementName, element, "isVisible", ElementType::parseBoolean);
        }

        static void parseFillElements(UIDefinition uiDefinition, Function<UIAccessor, UIAccessor> accessorFunction, String elementName, Dynamic<?> element) {
            parseElements(uiDefinition, elementName, element, ElementType::parseNumber, "x", "y", "width", "height", "color", "order");
            parseTranslationElements(uiDefinition, elementName, element);
            uiDefinition.addStatic(UIDefinition.createAfterInit(a -> accessorFunction.apply(a).addRenderable(elementName, (a.createModifiableRenderable(elementName, (guiGraphics, i, j, f) -> guiGraphics.method_25294(a.getInteger(elementName + ".x", 0), a.getInteger(elementName + ".y", 0), a.getInteger(elementName + ".x", 0) + a.getInteger(elementName + ".width", 0), a.getInteger(elementName + ".y", 0) + a.getInteger(elementName + ".height", 0), a.getInteger(elementName + ".color", 0xFFFFFFFF)))))));
        }

        static void parseFillGradientElements(UIDefinition uiDefinition, Function<UIAccessor, UIAccessor> accessorFunction, String elementName, Dynamic<?> element) {
            parseElements(uiDefinition, elementName, element, ElementType::parseNumber, "x", "y", "width", "height", "color", "secondColor", "order");
            parseTranslationElements(uiDefinition, elementName, element);
            uiDefinition.addStatic(UIDefinition.createAfterInit(a -> accessorFunction.apply(a).addRenderable(elementName, (a.createModifiableRenderable(elementName, (guiGraphics, i, j, f) -> guiGraphics.method_25296(a.getInteger(elementName + ".x", 0), a.getInteger(elementName + ".y", 0), a.getInteger(elementName + ".x", 0) + a.getInteger(elementName + ".width", 0), a.getInteger(elementName + ".y", 0) + a.getInteger(elementName + ".height", 0), a.getInteger(elementName + ".color", 0xFFFFFFFF), a.getInteger(elementName + ".secondColor", 0xFFFFFFFF)))))));
        }

        static void parseBlitElements(UIDefinition uiDefinition, Function<UIAccessor, UIAccessor> accessorFunction, String elementName, Dynamic<?> element) {
            parseElement(uiDefinition, elementName, element, "texture", net.minecraft.class_2960.field_25139);
            parseElements(uiDefinition, elementName, element, ElementType::parseNumber, "x", "y", "uvX", "uvY", "width", "height", "imageWidth", "imageHeight", "renderColor", "order", "amount");
            parseTranslationElements(uiDefinition, elementName, element);
            uiDefinition.addStatic(UIDefinition.createAfterInitWithAmount(elementName, a -> accessorFunction.apply(a).addRenderable(elementName, (a.createModifiableRenderable(elementName, (guiGraphics, i, j, f) -> a.getElement(elementName + ".texture", net.minecraft.class_2960.class).ifPresent(t -> FactoryGuiGraphics.of(guiGraphics).blit(t, a.getInteger(elementName + ".x", 0), a.getInteger(elementName + ".y", 0), a.getInteger(elementName + ".uvX", 0), a.getInteger(elementName + ".uvY", 0), a.getInteger(elementName + ".width", 0), a.getInteger(elementName + ".height", 0), a.getInteger(elementName + ".imageWidth", 256), a.getInteger(elementName + ".imageHeight", 256))))))));
        }

        static void parseTranslationElements(UIDefinition uiDefinition, String elementName, Dynamic<?> element) {
            parseElements(uiDefinition, elementName, element, ElementType::parseNumber,"translateX", "translateY", "translateZ", "scaleX", "scaleY", "scaleZ");
        }

        static void parseBlitSpriteElements(UIDefinition uiDefinition, Function<UIAccessor, UIAccessor> accessorFunction, String elementName, Dynamic<?> element) {
            parseElement(uiDefinition, elementName, element, "sprite", net.minecraft.class_2960.field_25139);
            parseElements(uiDefinition, elementName, element, ElementType::parseNumber, "x", "y", "width", "height", "renderColor", "order", "amount");
            parseTranslationElements(uiDefinition, elementName, element);
            uiDefinition.addStatic(UIDefinition.createAfterInitWithAmount(elementName, a -> accessorFunction.apply(a).addRenderable(elementName, (a.createModifiableRenderable(elementName, (guiGraphics, i, j, f) -> a.getElement(elementName + ".sprite", net.minecraft.class_2960.class).ifPresent(t -> FactoryGuiGraphics.of(guiGraphics).blitSprite(t, a.getInteger(elementName + ".x", 0), a.getInteger(elementName + ".y", 0), a.getInteger(elementName + ".width", 0), a.getInteger(elementName + ".height", 0))))))));
        }

        static void parseBlitCustomSpriteElements(UIDefinition uiDefinition, Function<UIAccessor, UIAccessor> accessorFunction, String elementName, Dynamic<?> element) {
            parseElement(uiDefinition, elementName, element, "sprite", net.minecraft.class_2960.field_25139);
            parseElements(uiDefinition, elementName, element, ElementType::parseNumber, "x", "y", "width", "height", "textureWidth", "textureHeight", "uvX", "uvY", "renderColor", "order", "amount");
            parseTranslationElements(uiDefinition, elementName, element);
            uiDefinition.addStatic(UIDefinition.createAfterInitWithAmount(elementName, a -> accessorFunction.apply(a).addRenderable(elementName, (a.createModifiableRenderable(elementName, (guiGraphics, i, j, f) -> a.getElement(elementName + ".sprite", net.minecraft.class_2960.class).ifPresent(t -> FactoryGuiGraphics.of(guiGraphics).blitSprite(t, a.getInteger(elementName + ".textureWidth", 0), a.getInteger(elementName + ".textureHeight", 0), a.getInteger(elementName + ".uvX", 0), a.getInteger(elementName + ".uvY", 0), a.getInteger(elementName + ".x", 0), a.getInteger(elementName + ".y", 0), a.getInteger(elementName + ".width", 0), a.getInteger(elementName + ".height", 0))))))));
        }

        static void parseTextElements(UIDefinition uiDefinition, String elementName, Dynamic<?> element) {
            parseElement(uiDefinition, elementName, element, "component", (s, d) -> parseComponentElement(elementName, s, d));
            parseElement(uiDefinition, elementName, element, "shadow", ElementType::parseBoolean);
            parseElements(uiDefinition, elementName, element, ElementType::parseNumber, "x", "y", "color", "order");
        }

        static void parseDrawStringElements(UIDefinition uiDefinition, Function<UIAccessor, UIAccessor> accessorFunction, String elementName, Dynamic<?> element) {
            parseTextElements(uiDefinition, elementName, element);
            parseTranslationElements(uiDefinition, elementName, element);
            uiDefinition.addStatic(UIDefinition.createAfterInit(a -> accessorFunction.apply(a).addRenderable(elementName, (a.createModifiableRenderable(elementName, (guiGraphics, i, j, f) -> a.getElement(elementName + ".component", class_2561.class).ifPresent(c -> guiGraphics./*? if >=26.1 {*//*text*//*?} else {*/method_51439/*?}*/(class_310.method_1551().field_1772, c, a.getInteger(elementName + ".x", 0), a.getInteger(elementName + ".y", 0), a.getInteger(elementName + ".color", 0xFFFFFFFF), a.getBoolean(elementName + ".shadow", true))))))));
        }

        static void parseDrawMultilineStringElements(UIDefinition uiDefinition, Function<UIAccessor, UIAccessor> accessorFunction, String elementName, Dynamic<?> element) {
            parseTextElements(uiDefinition, elementName, element);
            parseElements(uiDefinition, elementName, element, ElementType::parseNumber, "lineSpacing", "width");
            parseElement(uiDefinition, elementName, element, "centered", ElementType::parseBoolean);
            uiDefinition.addStatic(UIDefinition.createAfterInit(a -> {
                a.getElement(elementName+".component", class_2561.class).ifPresent(c-> {
                    int lineSpacing = a.getInteger(elementName+".lineSpacing", 12);
                    int width = a.getInteger(elementName+".width", 0);
                    AdvancedTextWidget advancedTextWidget = a.putLayoutElement(elementName, accessorFunction.apply(a).addChild(elementName, new AdvancedTextWidget(a).lineSpacing(lineSpacing).withLines(c,width).withColor(a.getInteger(elementName + ".color", 0xFFFFFFFF)).withShadow(a.getBoolean(elementName + ".shadow", true)).centered(a.getBoolean(elementName + ".centered", false))), i-> {}, i->{});
                    a.putStaticElement(elementName+".linesCount", advancedTextWidget.getLines().size());
                });
            }));
        }

        static void parseRenderItemsElements(UIDefinition uiDefinition, Function<UIAccessor, UIAccessor> accessorFunction, String elementName, Dynamic<?> element) {
            parseElements(uiDefinition, elementName, element, ElementType::parseBoolean,"isFake","allowDecorations");
            parseElement(uiDefinition, elementName, element, "items", (s, d) ->d.asListOpt(d1->DynamicUtil.getItemFromDynamic(d1, true)).result().map(l-> UIDefinition.createBeforeInit((a) -> a.putStaticElement(s,l.stream().map(ArbitrarySupplier::get).toArray(class_1799[]::new)))).orElse(null));
            parseElements(uiDefinition, elementName, element, ElementType::parseNumber, "x", "y", "order");
            parseTranslationElements(uiDefinition, elementName, element);
            uiDefinition.addStatic(UIDefinition.createAfterInit(a -> {
                UIAccessor accessor = accessorFunction.apply(a);
                Bearer<Integer> index = Bearer.of(0);
                a.putBearer( elementName + ".index",index);
                a.getElement(elementName + ".items", class_1799[].class).ifPresent(stacks-> {
                    accessor.putStaticElement(elementName + ".amount",stacks.length);
                    accessor.addRenderable(elementName, (a.createModifiableRenderable(elementName, (guiGraphics, i, j, f) -> {
                                class_1799 s = stacks[a.getInteger(elementName+".index",0)];
                                int x = a.getInteger(elementName + ".x", 0);
                                int y = a.getInteger(elementName + ".y", 0);
                                //? if >=26.1 {
                                /*if (a.getBoolean(elementName + ".isFake", false))
                                    guiGraphics.fakeItem(s, x, y);
                                else guiGraphics.item(s, x, y);
                                if (a.getBoolean(elementName + ".allowDecorations", true))
                                    guiGraphics.itemDecorations(Minecraft.getInstance().font, s, x, y);
                                *///?} else {
                                if (a.getBoolean(elementName + ".isFake", false))
                                    guiGraphics.method_51445(s, x, y);
                                else guiGraphics.method_51427(s, x, y);
                                if (a.getBoolean(elementName + ".allowDecorations", true))
                                    guiGraphics.method_51431(class_310.method_1551().field_1772, s, x, y);
                                //?}
                            }
                    )));
                });
            }));
        }

        static void parseRenderItemElements(UIDefinition uiDefinition, Function<UIAccessor, UIAccessor> accessorFunction, String elementName, Dynamic<?> element) {
            parseElements(uiDefinition, elementName, element, ElementType::parseBoolean,"isFake","allowDecorations");
            parseElement(uiDefinition, elementName, element, "item", (s,d) -> parseItemStackElement(s, d));
            parseElements(uiDefinition, elementName, element, ElementType::parseNumber, "x", "y", "order", "amount");
            parseTranslationElements(uiDefinition, elementName, element);
            uiDefinition.addStatic(UIDefinition.createAfterInit(a -> accessorFunction.apply(a).addRenderable(elementName, (a.createModifiableRenderable(elementName, (guiGraphics, i, j, f) -> a.getElement(elementName + ".item", class_1799.class).ifPresent(s-> {
                int x = a.getInteger(elementName + ".x", 0);
                int y = a.getInteger(elementName + ".y", 0);
                //? if >=26.1 {
                /*if (a.getBoolean(elementName + ".isFake", false))
                    guiGraphics.fakeItem(s, x, y);
                else guiGraphics.item(s, x, y);
                if (a.getBoolean(elementName + ".allowDecorations", true))
                    guiGraphics.itemDecorations(Minecraft.getInstance().font, s, x, y);
                *///?} else {
                if (a.getBoolean(elementName + ".isFake", false))
                     guiGraphics.method_51445(s, x, y);
                else guiGraphics.method_51427(s, x, y);
                if (a.getBoolean(elementName + ".allowDecorations", true))
                    guiGraphics.method_51431(class_310.method_1551().field_1772, s, x, y);
                //?}
            }))))));
        }

        static List<WidgetAction.PressSupplier<class_339>> parseActionsElement(UIDefinition uiDefinition, String elementName, Dynamic<?> element) {
            return element.get("actions").asMapOpt().result().map(m -> m.map(p -> {
                String actionName = elementName + ".actions." + p.getFirst().asString("");
                parseElement(uiDefinition, actionName, p.getSecond(), "applyCondition", ElementType::parseBoolean);
                return WidgetAction.CODEC.parse(p.getFirst()).result().flatMap(c -> c.press(a -> a.getBoolean(actionName + ".applyCondition", true), p.getSecond()));
            }).filter(Optional::isPresent).map(Optional::get).toList()).orElse(Collections.emptyList());
        }

        static ElementValue<class_1799> parseItemStackElement(String field, Dynamic<?> element) {
            ArbitrarySupplier<class_1799> stackSupplier = DynamicUtil.getItemFromDynamic(element, true);
            return new ElementValue<>(field, a -> stackSupplier.get());
        }

        @Deprecated
        static UIDefinition parseItemStackElement(String elementName, String field, Dynamic<?> element) {
            return parseItemStackElement(field, element);
        }

        static ElementValue<Number> parseNumber(String field, Dynamic<?> element) {
            Optional<Number> numberResult = element.asNumber().result();
            if (numberResult.isPresent()) return numberResult.map(n-> new ElementValue<>(field, a -> n)).orElse(null);
            else return element.asString().map(ExpressionEvaluator::of).map(e -> new ElementValue<>(field, e::evaluate)).result().orElse(null);
        }

        @Deprecated
        static UIDefinition parseNumberElement(String elementName, String field, Dynamic<?> element) {
            return parseNumber(field, element);
        }

        static ElementValue<Boolean> parseBooleanElementOrReference(String elementName, Dynamic<?> element) {
            return UIDefinitionManager.ElementType.<Boolean>parseElementReference(elementName, element).orElseGet(() -> parseBoolean(elementName, element));
        }

        static <T> ElementValue<Boolean> parseBoolean(String field, Dynamic<T> element) {
            Optional<Boolean> booleanResult = element.getOps().getBooleanValue(element.getValue()).result();
            if (booleanResult.isPresent()) return booleanResult.map(n -> new ElementValue<>(field, a -> n)).orElse(null);
            else return element.asString().map(BooleanExpressionEvaluator::of).map(e -> new ElementValue<>(field, e::evaluate)).result().orElse(null);
        }

        @Deprecated
        static <T> UIDefinition parseBooleanElement(String elementName, String field, Dynamic<T> element) {
            return parseBoolean(field, element);
        }

        static ElementValue<class_2561> parseExternalComponentElement(String elementName, String field, Dynamic<?> element) {
            return element.get("baseDir").flatMap(net.minecraft.class_2960.field_25139::parse).result().map(r-> {
                Map<String,class_2561> componentByLang = new HashMap<>();
                for (String s : class_310.method_1551().method_1526().method_4665().keySet()) {
                    net.minecraft.class_2960 location = r.method_48331("/" + s + ".txt");
                    Optional<class_3298> externalComponent = class_310.method_1551().method_1478().method_14486(location);
                    externalComponent.ifPresent(resource -> {
                        class_5250 c = DynamicUtil.getComponentCodec().parse(element).result().map(class_2561::method_27661).orElseGet(class_2561::method_43473);
                        try (BufferedReader reader = resource.method_43039()) {
                            reader.lines().forEach(l -> {
                                c.method_27693(l);
                                c.method_27693("\n");
                            });
                            componentByLang.put(s, c);
                        } catch (IOException e) {
                            FactoryAPI.LOGGER.warn("Failed to parse {}, this external component won't be loaded.", location, e);
                        }
                    });
                }
                return new ElementValue<>(field, a -> {
                    String selected = class_310.method_1551().method_1526().method_4669();
                    return componentByLang.containsKey(selected) ? componentByLang.get(selected) : componentByLang.get("en_us");
                });
            }).orElse(null);
        }

        static UIDefinition parseComponentElement(String elementName, String field, Dynamic<?> element) {
            UIDefinition externalComponentUIDefinition = parseExternalComponentElement(elementName, field, element);
            if (externalComponentUIDefinition != null) return externalComponentUIDefinition;
            return (element.get("allowVariables").asBoolean(false) ? DynamicUtil.getComponentCodec().parse(element).map(component -> UIDefinition.createBeforeInit(a -> {
                if (component.method_10851() instanceof class_2588 contents)
                    a.putComponent(field, class_2561.method_43469(contents.method_11022(), element.get("args").asStream().map(d1->d1.asString().result().map(k-> a.getElementValue(k, null, Object.class))).filter(Optional::isPresent).map(Optional::get).toArray(Object[]::new)).method_27696(component.method_10866()));
            })) : DynamicUtil.getComponentCodec().parse(element).map(c -> UIDefinition.createBeforeInit(a -> a.putComponent(field, c)))).result().orElse(null);
        }

        static UIDefinition parseComponentElement(String elementName, Dynamic<?> element) {
            return parseComponentElement(elementName, elementName, element);
        }

        static void parseElements(UIDefinition uiDefinition, String elementName, Dynamic<?> element, BiFunction<String, Dynamic<?>, UIDefinition> dynamicToDefinition, String... fields) {
            for (String field : fields) {
                parseElement(uiDefinition, elementName, element, field, dynamicToDefinition);
            }
        }

        static void parseElement(UIDefinition uiDefinition, String elementName, Dynamic<?> element, String field, Codec<?> codec) {
            parseElement(uiDefinition, elementName, element, field, (s, d) -> codec.parse(d).result().map(c -> UIDefinition.createBeforeInit(a -> a.putStaticElement(s, c))).orElse(null));
        }

        static void parseElement(UIDefinition uiDefinition, String elementName, Dynamic<?> element, String field, BiFunction<String, Dynamic<?>, UIDefinition> dynamicToDefinition) {
            element.get(field).result().map(d -> parseElementReference(elementName + "." + field, d).map(value -> (UIDefinition) value).orElseGet(() -> dynamicToDefinition.apply(elementName + "." + field, d))).ifPresent(uiDefinition::addStatic);
        }

        static <T> Optional<ElementValue<T>> parseElementReference(String field, Dynamic<?> element) {
            return element.get("reference").asString().result().map(s -> new ElementValue<>(field, a -> (T) a.getElement(s).get()));
        }

        static ElementType get(String id) {
            return get(net.minecraft.class_2960.method_12829(id));
        }

        static ElementType get(net.minecraft.class_2960 id) {
            return map.getOrDefault(id, PUT_NUMBER);
        }

        static net.minecraft.class_2960 getId(ElementType type) {
            return map.getKeyOrDefault(type, null);
        }

        void parse(UIDefinition uiDefinition, Function<UIAccessor, UIAccessor> accessorFunction, String elementName, Dynamic<?> element);

        default void parse(UIDefinition uiDefinition, String elementName, Dynamic<?> element) {
            parse(uiDefinition, a -> a, elementName, element);
        }

        static ElementType createIndexable(Function<List<Integer>, ElementType> parser) {
            return ((uiDefinition, accessorFunction, elementName, element) -> parser.apply(element.get("range").asString().result().map(UIDefinitionManager::parseIntRange).orElse(List.of(element.get("index").asInt(0)))).parse(uiDefinition, accessorFunction, elementName, element));
        }

        static ElementType createConditional(ElementType type) {
            return ((uiDefinition, accessorFunction, elementName, element) -> {
                Optional<ElementValue<Boolean>> applyCondition = element.get("applyCondition").map(e -> UIDefinitionManager.ElementType.parseBooleanElementOrReference(elementName+".applyCondition", e)).result();
                UIDefinition.Instance condDefinition = new UIDefinition.Instance(elementName, a -> applyCondition.isEmpty() || applyCondition.get().value().apply(a));
                type.parse(condDefinition, accessorFunction, elementName, element);
                handleDeprecatedDefinitionsAddition(condDefinition);
                uiDefinition.addStatic(condDefinition);
            });
        }

        static ElementType registerConditional(String path, ElementType type) {
            return register(FactoryAPI.createVanillaLocation(path), createConditional(type));
        }

        static <T> ElementType registerCodec(String path, Codec<T> codec) {
            return registerConditional(path, (definition, accessorFunction, name, e) -> parseElement(definition, name, e, "value", (s, d) -> codec.parse(d).result().map(r -> UIDefinition.createBeforeInit(a -> a.putStaticElement(name, r))).orElse(null)));
        }

        static ElementType register(String path, ElementType type) {
            return register(FactoryAPI.createVanillaLocation(path), type);
        }

        static ElementType register(net.minecraft.class_2960 id, ElementType type) {
            map.put(id, type);
            return type;
        }
    }

    public final ListMap<net.minecraft.class_2960, UIDefinition> map = new ListMap<>();
    public final List<UIDefinition> staticList = new ArrayList<>();

    public final void applyStatic(UIAccessor accessor) {
        accessor.getDefinitions().addAll(staticList);
    }

    public final void apply(UIAccessor accessor) {
        accessor.getDefinitions().addAll(map.values());
    }

    record UIDefinitionEntry(net.minecraft.class_2960 id, UIDefinition.Instance uiDefinition, int priority, boolean replace)
    {
    }

    @Override
    public void method_14491(class_3300 resourceManager) {
        map.clear();
        List<UIDefinitionEntry> list = new ArrayList<>();
        resourceManager.method_14488(UI_DEFINITIONS, r -> r.method_12832().endsWith(".json")).forEach((l, r) -> {
            try (BufferedReader bufferedReader = r.method_43039()) {
                Dynamic<JsonElement> dynamic = new Dynamic<>(JsonOps.INSTANCE, class_3518.method_15255(bufferedReader));
                list.add(new UIDefinitionEntry(l, fromDynamicWithTarget(l.toString(), dynamic), dynamic.get("priority").asInt(0), dynamic.get("replace").asBoolean(false)));
            } catch (IOException exception) {
                FactoryAPI.LOGGER.warn(exception.getMessage());
            }
        });
        list.sort(Comparator.comparingInt(UIDefinitionEntry::priority));
        for (UIDefinitionEntry uiDefinitionEntry : list) {
            if (map.containsKey(uiDefinitionEntry.id) && !uiDefinitionEntry.replace) {
                map.get(uiDefinitionEntry.id).getStaticDefinitions().addAll(uiDefinitionEntry.uiDefinition.getStaticDefinitions());
            } else
                map.put(uiDefinitionEntry.id, uiDefinitionEntry.uiDefinition);
        }
    }

    public static Class<?> getClassFromString(String uiDefinitionName, String s) {
        try {
            return Class.forName(FactoryAPIPlatform.getCurrentClassName(s));
        } catch (ClassNotFoundException e) {
            FactoryAPI.LOGGER.warn("Incorrect Class Name {} from UI Definition {}: {}", s, uiDefinitionName, e.getMessage());
            return null;
        }
    }

    public static <T> UIDefinition.Instance fromDynamic(String name, Dynamic<T> dynamic, Predicate<UIAccessor> extraCondition) {
        Optional<ElementValue<Boolean>> applyConditionDefinition = dynamic.get("applyCondition").map(d -> ElementType.parseBooleanElementOrReference("applyCondition", d)).result();
        UIDefinition.Instance uiDefinition = new UIDefinition.Instance(name, accessor -> {
            if (!extraCondition.test(accessor)) return false;
            return applyConditionDefinition.isEmpty() || applyConditionDefinition.get().value().apply(accessor);
        });
        parseAllElements(uiDefinition,a -> a, dynamic, s -> s);
        return uiDefinition;
    }

    public static <T> UIDefinition.Instance fromDynamic(String name, Dynamic<T> dynamic) {
        return fromDynamic(name, dynamic, a -> true);
    }

    public static <T> UIDefinition.Instance fromDynamicWithTarget(String name, Dynamic<T> dynamic) {
        String targetType = dynamic.get("targetType").asString("id");

        Class<?> targetClass = dynamic.get("targetUI").asString().map(s -> targetType.equals("id") ? NAMED_UI_TARGETS.get(net.minecraft.class_2960.method_12829(s)) : targetType.equals("class") ? getClassFromString(name, s) : null).result().orElse(null);
        class_2561 targetTitle = targetType.equals("screenTitle") ? dynamic.get("targetUI").flatMap(DynamicUtil.getComponentCodec()::parse).result().orElse(null) : null;

        String targetRange = dynamic.get("targetRange").asString("instance");
        return fromDynamic(name, dynamic, accessor -> (accessor.toString().equals(name) || targetClass != null && (targetRange.equals("instance") && targetClass.isInstance(accessor) || targetRange.equals("class") && targetClass == accessor.getClass())) || targetTitle != null && accessor.getScreen() != null && accessor.getScreen().method_25440().equals(targetTitle));
    }

    public static void parseAllElements(UIDefinition uiDefinition, Function<UIAccessor, UIAccessor> accessorFunction, Dynamic<?> dynamic, Function<String, String> nameModifier) {
        dynamic.get("elements").asMapOpt(Dynamic::asString, d -> d).result().ifPresentOrElse(m -> m.forEach((s,d) -> tryParseElement(uiDefinition, accessorFunction, s, d, nameModifier)), () -> dynamic.get("elements").asStream().forEach(d -> tryParseElement(uiDefinition, accessorFunction, d.get("name").asString(), d, nameModifier)));
        handleDeprecatedDefinitionsAddition(uiDefinition);
    }

    public static void tryParseElement(UIDefinition uiDefinition, Function<UIAccessor, UIAccessor> accessorFunction, DataResult<String> name, Dynamic<?> dynamic, Function<String, String> nameModifier) {
        name.result().ifPresent(s -> dynamic.get("type").asString().map(ElementType::get).result().ifPresentOrElse(p -> p.parse(uiDefinition, accessorFunction, nameModifier.apply(s), dynamic), () -> ArbitrarySupplier.of(ElementType.parseNumber(nameModifier.apply(s), dynamic)).ifPresent(uiDefinition::addStatic)));
    }

    @Deprecated
    private static void handleDeprecatedDefinitionsAddition(UIDefinition uiDefinition) {
        if (uiDefinition.getDefinitions().isEmpty()) return;
        uiDefinition.getStaticDefinitions().addAll(uiDefinition.getDefinitions());
        uiDefinition.getDefinitions().clear();
    }

    public void openDefaultScreenAndAddDefinition(Optional<net.minecraft.class_2960> defaultScreen, UIDefinition uiDefinition) {
        class_437 s = defaultScreen.map(DEFAULT_SCREENS_MAP::get).orElse(parent-> new class_437(class_2561.method_43473()) {}).apply(FactoryAPIClient.getScreen());
        UIAccessor.of(s).addStatic(uiDefinition);
        class_310.method_1551().method_1507(s);
    }
}

package wily.factoryapi.util;

import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import org.jetbrains.annotations.Nullable;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIPlatform;
import java.util.Objects;
import java.util.Optional;

//? if fabric {
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
//?} elif forge {
/*import net.minecraftforge.fluids.FluidStack;
*///?} elif neoforge {
/*import net.neoforged.neoforge.fluids.FluidStack;
*///?}
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2540;
import net.minecraft.class_2561;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_7923;

public class FluidInstance /*? if >=1.20.5 && !forge {*//*implements DataComponentHolder*//*?}*/ {
    private final class_3611 fluid;
    private int amount;
    //? if <1.20.5 || forge {
    private class_2487 tag;
    //?} else
    //private PatchedDataComponentMap components = new PatchedDataComponentMap(PatchedDataComponentMap.EMPTY);


    public static final Codec<FluidInstance> CODEC = RecordCodecBuilder.create(i-> i.group(class_7923.field_41173.method_39673().fieldOf("fluid").forGetter(FluidInstance::getFluid), Codec.INT.fieldOf("amount").forGetter(FluidInstance::getAmount), /*? if <1.20.5 || forge {*/ class_2487/*?} else {*/ /*DataComponentPatch*//*?}*/.field_25128.fieldOf(/*? if <1.20.5 || forge {*/ "nbt"/*?} else {*/ /*"components"*//*?}*/).forGetter(FluidInstance::/*? if <1.20.5 || forge {*/ getNonNullTag/*?} else {*//*getComponentsPatch*//*?}*/)).apply(i,FluidInstance::new));
    //? if >=1.20.5
    //public static final StreamCodec<RegistryFriendlyByteBuf,FluidInstance> STREAM_CODEC = StreamCodec.of(FluidInstance::encode, FluidInstance::decode);
    public static final FluidInstance EMPTY = new FluidInstance(class_3612.field_15906,0);


    public FluidInstance(class_3611 fluid, int amount){
        this.fluid = fluid;
        this.amount = amount;
    }
    public FluidInstance(class_3611 fluid, int amount, /*? if <1.20.5 || forge {*/ class_2487 tag/*?} else {*/ /*DataComponentPatch components*//*?}*/){
        this(fluid,amount);
        //? if <1.20.5 || forge {
        this.tag = tag.method_10553();
        //?} else
        //this.components = PatchedDataComponentMap.fromPatch(DataComponentMap.builder().build(),components);
    }

    public static FluidInstance empty() {
        return EMPTY;
    }

    public static FluidInstance create(FluidInstance fluidInstance, int amount){
        return create(fluidInstance.getFluid(),amount);
    }

    public static FluidInstance create(class_3611 fluid, int amount){
        return new FluidInstance(fluid,amount);
    }

    public static FluidInstance create(class_3611 fluid){
        return new FluidInstance(fluid,1000);
    }

    public static FluidInstance create(class_3611 fluid, long amount){
        return new FluidInstance(fluid,getMilliBucketsFluidAmount(amount));
    }

    //? if <1.20.5 || forge {
    public class_2487 getNonNullTag() {
        return getTag() == null ? new class_2487() : getTag();
    }
    //?}
    //? if <1.20.5 || forge {
    public class_2487 getTag() {
        return tag;
    }

    public void setTag(class_2487 tag) {
        if (getFluid() != class_3612.field_15906) this.tag = tag;
    }

    public class_2487 getOrCreateTag() {
        if (tag == null)
            setTag(new class_2487());
        return tag;
    }
    //?} else {
    /*@Override
    public DataComponentMap getComponents() {
        return components;
    }

    public DataComponentPatch getComponentsPatch() {
        return !this.isEmpty() ? components.asPatch() : DataComponentPatch.EMPTY;
    }

    public <T> T set(DataComponentType<T> type, @Nullable T component) {
        return this.components.set(type, component);
    }

    public <T> T remove(DataComponentType<? extends T> type) {
        return this.components.remove(type);
    }

    public void applyComponents(DataComponentPatch patch) {
        this.components.applyPatch(patch);
    }

    public void applyComponents(DataComponentMap components) {
        this.components.setAll(components);
    }

    *///?}

    public class_3611 getFluid(){
        return fluid;
    }

    public boolean isEmpty(){
        return getAmount() <= 0;
    }

    public int getAmount(){
        return getFluid() == class_3612.field_15906 ? 0 : amount;
    }

    public long getPlatformAmount(){
        return getPlatformFluidAmount(getAmount());
    }

    public void setAmount(int amount){
        if (getFluid() != class_3612.field_15906) this.amount = amount;
    }

    //? if fabric {
    public FluidVariant toVariant(){
        return FluidVariant.of(fluid,/*? if <1.20.5 {*/ tag/*?} else {*/ /*getComponentsPatch()*//*?}*/);
    }
    //?} else if neoforge || forge {
    /*private FluidStack stack;
    public FluidStack toStack(){
        if (this.isEmpty()) return FluidStack.EMPTY;
        if (stack == null) stack = new FluidStack(fluid,amount);
        stack.setAmount(amount);
        //? if <1.20.5 || forge {
        stack.setTag(getTag());
        //?} else
        //stack.applyComponents(getComponents());
        return stack;
    }
    *///?}
    public void setAmount(long amount){
        setAmount(getMilliBucketsFluidAmount(amount));
    }

    public static FluidInstance fromJson(JsonObject jsonObject){
        if (jsonObject != null) return CODEC.parse(JsonOps.INSTANCE,jsonObject).result().orElse(empty());
        return empty();
    }
    public static FluidInstance fromTag(class_2487 tag){
        return CODEC.parse(class_2509.field_11560,tag).result().orElseGet(()->{
            Optional<String> fluidId = /*? if fabric {*/CompoundTagUtil.getCompoundTag(tag,"fluidVariant").flatMap(c->CompoundTagUtil.getString(c,"fluid"))/*?} else {*//*CompoundTagUtil.getString(tag, "FluidName")*//*?}*/;
            if (fluidId.isPresent()){
                class_3611 fluid = FactoryAPIPlatform.getRegistryValue(FactoryAPI.createLocation(fluidId.get()), class_7923.field_41173);
                if (fluid == class_3612.field_15906) return FluidInstance.empty();
                return FluidInstance.create(fluid,getMilliBucketsFluidAmount(CompoundTagUtil.getLong(tag,/*? if fabric {*/"amount"/*?} else {*//*"Amount"*//*?}*/).orElse(0L)));
            }
            return empty();
        });
    }

    public static class_2487 toTag(FluidInstance stack){
        return CODEC.encodeStart(class_2509.field_11560,stack).result().map(t-> t instanceof class_2487 c ? c : null).orElse(new class_2487());
    }

    public static long getPlatformBucketFluidAmount(){
        return FactoryAPI.getLoader().isFabric() ? 81000L : 1000;
    }

    public static long getPlatformFluidAmount(int amount){
        return (long) ((amount / 1000F) * getPlatformBucketFluidAmount());
    }

    public static int getMilliBucketsFluidAmount(long amount){
        return (int) (((float)amount / getPlatformBucketFluidAmount()) * 1000);
    }

    public boolean isFluidEqual(FluidInstance resource) {
        return getFluid() == resource.getFluid();
    }

    public void grow(int amount) {
        setAmount(getAmount()+amount);
    }

    public void shrink(int amount) {
        setAmount(getAmount()-amount);
    }

    public FluidInstance withAmount(int amount) {
        setAmount(amount);
        return this;
    }

    public FluidInstance copy() {
        return new FluidInstance(getFluid(),getAmount());
    }

    public FluidInstance copyWithAmount(int maxDrain) {
        return copy().withAmount(maxDrain);
    }

    public class_2561 getName() {
        return getFluid().method_15785().method_15759().method_26204().method_9518();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj) || obj instanceof FluidInstance i && i.isFluidEqual(this) && i.getAmount() == getAmount() &&/*? if <1.20.5 || forge {*/  Objects.equals(tag, i.tag) /*?} else {*//*components.equals(i.components)*//*?}*/;
    }

    @Override
    public int hashCode() {
        return Objects.hash(fluid, amount, /*? if <1.20.5 || forge {*/  tag /*?} else {*//*components*//*?}*/);
    }

    public static void encode( /*? if <1.20.5 {*/class_2540/*?} else {*//*RegistryFriendlyByteBuf *//*?}*/ buf, FluidInstance instance){
        buf.writeInt(instance.getAmount());
        if (instance.isEmpty()) return;
        buf.method_10812(class_7923.field_41173.method_10221(instance.getFluid()));
        //? if <1.20.5 || forge {
        buf.method_10794(instance.getNonNullTag());
        //?} else
        //DataComponentPatch.STREAM_CODEC.encode(buf,instance.getComponentsPatch());
    }
    public static FluidInstance decode(/*? if <1.20.5 {*/class_2540/*?} else {*//*RegistryFriendlyByteBuf *//*?}*/ buf){
        int amount = buf.readInt();
        if (amount <= 0) return EMPTY;
        return new FluidInstance(FactoryAPIPlatform.getRegistryValue(buf.method_10810(),class_7923.field_41173), amount, /*? if <1.20.5 || forge {*/buf.method_10798()/*?} else {*//*DataComponentPatch.STREAM_CODEC.decode(buf)*//*?}*/);
    }
}

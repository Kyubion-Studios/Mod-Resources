//? if <=1.20.1 {
package wily.factoryapi.base.client;

import net.minecraft.class_7368;

public interface FactorySpriteContents {
    class_7368 metadata();
    void setMetadata(class_7368 metadata);
}
//?}

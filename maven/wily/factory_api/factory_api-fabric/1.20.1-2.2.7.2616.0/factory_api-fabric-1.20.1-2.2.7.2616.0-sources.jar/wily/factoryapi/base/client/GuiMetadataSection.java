//? if <=1.20.1 {
package wily.factoryapi.base.client;

import com.google.gson.JsonObject;
import com.mojang.serialization.*;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;
import net.minecraft.class_156;
import net.minecraft.class_5699;
import net.minecraft.class_7677;

public record GuiMetadataSection(GuiSpriteScaling scaling) {
    public static final GuiMetadataSection DEFAULT = new GuiMetadataSection(GuiSpriteScaling.DEFAULT);
    public static final Codec<GuiMetadataSection> CODEC = RecordCodecBuilder.create((instance) ->  instance.group(strictOptionalField(GuiSpriteScaling.CODEC, "scaling", GuiSpriteScaling.DEFAULT).forGetter(GuiMetadataSection::scaling)).apply(instance, GuiMetadataSection::new));
    public static final class_7677<GuiMetadataSection> TYPE = fromCodec("gui", CODEC);
    public static final List<class_7677<?>> DEFAULT_TYPES = new ArrayList<>(List.of(TYPE, MipmapMetadataSection.TYPE));


    public static <T> class_7677<T> fromCodec(String name, Codec<T> codec){
        return new class_7677<>() {
            @Override
            public String method_14420() {
                return name;
            }


            public T method_14421(JsonObject jsonObject) {
                return codec.parse(JsonOps.INSTANCE, jsonObject).result().orElse(null);
            }

            @Override
            public JsonObject method_45251(T object) {
                return class_156.method_47526(codec.encodeStart(JsonOps.INSTANCE, object), IllegalArgumentException::new).getAsJsonObject();
            }
        };
    }
    public static <A> MapCodec<Optional<A>> strictOptionalField(Codec<A> codec, String string) {
        return new StrictOptionalFieldCodec<>(string, codec);
    }

    public static <A> MapCodec<A> strictOptionalField(Codec<A> codec, String string, A object) {
        return strictOptionalField(codec, string).xmap((optional) -> optional.orElse(object), (object2) -> Objects.equals(object2, object) ? Optional.empty() : Optional.of(object2));
    }
    public static final class StrictOptionalFieldCodec<A> extends MapCodec<Optional<A>> {
        private final String name;
        private final Codec<A> elementCodec;

        public StrictOptionalFieldCodec(String string, Codec<A> codec) {
            this.name = string;
            this.elementCodec = codec;
        }

        public <T> DataResult<Optional<A>> decode(DynamicOps<T> dynamicOps, MapLike<T> mapLike) {
            T object = mapLike.get(this.name);
            return object == null ? DataResult.success(Optional.empty()) : this.elementCodec.parse(dynamicOps, object).map(Optional::of);
        }

        public <T> RecordBuilder<T> encode(Optional<A> optional, DynamicOps<T> dynamicOps, RecordBuilder<T> recordBuilder) {
            return optional.isPresent() ? recordBuilder.add(this.name, this.elementCodec.encodeStart(dynamicOps, optional.get())) : recordBuilder;
        }

        public <T> Stream<T> keys(DynamicOps<T> dynamicOps) {
            return Stream.of(dynamicOps.createString(this.name));
        }

        public boolean equals(Object object) {
            if (this == object) {
                return true;
            } else if (!(object instanceof StrictOptionalFieldCodec<?> o)) {
                return false;
            } else {
                return Objects.equals(this.name, o.name) && Objects.equals(this.elementCodec, o.elementCodec);
            }
        }

        public int hashCode() {
            return Objects.hash(this.name, this.elementCodec);
        }

        public String toString() {
            return "StrictOptionalFieldCodec[" + this.name + ": " + this.elementCodec + "]";
        }
    }
    static <T> Codec<T> validate(Codec<T> codec, Function<T, DataResult<T>> function) {
        if (codec instanceof MapCodec.MapCodecCodec<T> mapCodecCodec) {
            return class_5699.method_51699(mapCodecCodec.codec(), function).codec();
        }
        return codec.flatXmap(function, function);
    }
}
//?}
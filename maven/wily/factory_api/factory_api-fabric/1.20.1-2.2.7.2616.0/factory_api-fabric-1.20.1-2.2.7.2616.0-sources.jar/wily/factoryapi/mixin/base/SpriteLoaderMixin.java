package wily.factoryapi.mixin.base;

import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableSet;
import com.llamalad7.mixinextras.sugar.Local;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
//? if <=1.20.1 {
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import wily.factoryapi.base.client.FactorySpriteContents;
import wily.factoryapi.base.client.GuiMetadataSection;
//?}
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import wily.factoryapi.FactoryAPIClient;
import wily.factoryapi.base.client.MipmapMetadataSection;

import java.io.IOException;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executor;
import java.util.stream.Collectors;
import net.minecraft.class_2960;
import net.minecraft.class_3270;
import net.minecraft.class_3298;
import net.minecraft.class_7368;
import net.minecraft.class_7764;
import net.minecraft.class_7766;

@Mixin(class_7766.class)
public class SpriteLoaderMixin {

    @Shadow @Final private net.minecraft.class_2960 location;

    //? if <=1.20.1 {
    @Inject(method = "loadSprite", at = @At("RETURN"))
    private static void loadSprite(class_2960 resourceLocation, class_3298 resource, CallbackInfoReturnable<class_7764> cir) {
        if (cir.getReturnValue() != null) {
            try {
                class_7368 metadata = resource.method_14481();
                Map<class_3270<?>, Optional<?>> map = GuiMetadataSection.DEFAULT_TYPES.stream().collect(Collectors.toMap(t-> t, metadata::method_43041));
                ((FactorySpriteContents) cir.getReturnValue()).setMetadata(new class_7368() {
                    @Override
                    public <T> Optional<T> method_43041(class_3270<T> metadataSectionSerializer) {
                        return (Optional<T>) map.getOrDefault(metadataSectionSerializer, Optional.empty());
                    }
                });
            } catch (IOException e) {
            }
        }
    }
    //?} else if <1.21.9 {
    /*@Inject(method = "loadAndStitch(Lnet/minecraft/server/packs/resources/ResourceManager;Lnet/minecraft/resources/ResourceLocation;ILjava/util/concurrent/Executor;Ljava/util/Collection;)Ljava/util/concurrent/CompletableFuture;", at = @At(value = "HEAD"))
    public void loadAndStitch(CallbackInfoReturnable<CompletableFuture<SpriteLoader.Preparations>> cir, @Local(argsOnly = true) LocalRef<Collection<MetadataSectionType<?>>> types) {
        if (location.equals(FactoryAPIClient.BLOCK_ATLAS_ID))
            types.set(ImmutableSet.<MetadataSectionType<?>>builder().addAll(types.get()).add(MipmapMetadataSection.TYPE).build());
    }
    *///?} else {
    /*@Inject(method = "loadAndStitch", at = @At(value = "HEAD"))
    public void loadAndStitch(CallbackInfoReturnable<CompletableFuture<SpriteLoader.Preparations>> cir, @Local(argsOnly = true) LocalRef<Set<MetadataSectionType<?>>> types) {
        if (location.equals(FactoryAPIClient.BLOCK_ATLAS_ID))
            types.set(ImmutableSet.<MetadataSectionType<?>>builder().addAll(types.get()).add(MipmapMetadataSection.TYPE).build());
    }
    *///?}
}


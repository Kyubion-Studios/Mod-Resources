//? if <=1.20.1 {
package wily.factoryapi.base.client;

import java.util.Set;
import net.minecraft.class_1058;
import net.minecraft.class_1060;
import net.minecraft.class_1079;
import net.minecraft.class_2960;
import net.minecraft.class_3270;
import net.minecraft.class_4075;


public class GuiSpriteManager extends class_4075 {
    public static final Set<class_3270<?>> GUI_METADATA_SECTIONS = Set.of(class_1079.field_5337, GuiMetadataSection.TYPE);
    public static final Set<class_3270<?>> DEFAULT_METADATA_SECTIONS = Set.of(class_1079.field_5337);

    public GuiSpriteManager(class_1060 arg) {
        super(arg, new class_2960("textures/atlas/gui.png"), new class_2960("gui"));
    }

    @Override
    public class_1058 method_18667(class_2960 resourceLocation) {
        return super.method_18667(resourceLocation);
    }

    public GuiSpriteScaling getSpriteScaling(class_1058 arg) {
        return this.getMetadata(arg).scaling();
    }

    private GuiMetadataSection getMetadata(class_1058 arg) {
        return ((FactorySpriteContents)arg.method_45851()).metadata().method_43041(GuiMetadataSection.TYPE).orElse(GuiMetadataSection.DEFAULT);
    }

}
//?}
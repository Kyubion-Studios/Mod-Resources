package wily.factoryapi.base.client;

import com.mojang.blaze3d.systems.RenderSystem;
import com.mojang.blaze3d.vertex.*;
import org.joml.Matrix4f;
import wily.factoryapi.FactoryAPIClient;

import java.util.Map;
import net.minecraft.class_1058;
import net.minecraft.class_1059;
import net.minecraft.class_286;
import net.minecraft.class_287;
import net.minecraft.class_289;
import net.minecraft.class_290;
import net.minecraft.class_293;
import net.minecraft.class_4597;
import net.minecraft.class_757;

public interface FactoryGuiGraphics {
    net.minecraft.class_332 context();

    class_4597.class_4598 getBufferSource();
    void pushBufferSource(class_4597.class_4598 bufferSource);
    void popBufferSource();

    FactoryGuiMatrixStack pose();

    static FactoryGuiGraphics of(net.minecraft.class_332 guiGraphics) {
        return ((Accessor) guiGraphics).getFactoryGuiGraphics();
    }

    //? if >=1.21.9 {
    /*static TextureAtlas getSprites() {
        return Minecraft.getInstance().getAtlasManager().getAtlasOrThrow(AtlasIds.GUI);
    }
    *///?} else {
    static GuiSpriteManager getSprites() {
        return /*? if >1.20.1 {*/ /*Minecraft.getInstance().getGuiSprites()*//*?} else {*/FactoryAPIClient.sprites/*?}*/;
    }
    //?}

    void blit(net.minecraft.class_2960 texture, int x, int y, int uvX, int uvY, int width, int height);

    void blit(net.minecraft.class_2960 texture, int x, int y, int z, float uvX, float uvY, int width, int height, int textureWidth, int textureHeight);

    void blit(net.minecraft.class_2960 texture, int x, int xd, int y, int yd, float uvX, float uvY, int width, int height, int textureWidth, int textureHeight);

    void blit(net.minecraft.class_2960 texture, int x, int y, float uvX, float uvY, int width, int height, int textureWidth, int textureHeight);

    void blitSprite(net.minecraft.class_2960 id, int x, int y, int width, int height);

    void blitSprite(net.minecraft.class_2960 id, int x, int y, int z, int width, int height);

    void blitSprite(net.minecraft.class_2960 id, int textureWidth, int textureHeight, int uvX, int uvY, int x, int y, int z, int width, int height);

    void blit(int x, int y, int z, int width, int height, class_1058 textureAtlasSprite);

    default void blitSprite(net.minecraft.class_2960 id, int textureWidth, int textureHeight, int uvX, int uvY, int x, int y, int width, int height) {
        this.blitSprite(id, textureWidth, textureHeight, uvX, uvY, x, y,0, width, height);
    }

    //TODO -  Methods for drawing texts?

    void enableScissor(int x, int y, int xd, int yd, boolean matrixAffects);

    default void enableScissor(int x, int y, int xd, int yd) {
        enableScissor(x, y, xd, yd, true);
    }

    //? if <1.20.2 {
    default void blitNineSlicedSprite(class_1058 textureAtlasSprite, GuiSpriteScaling.NineSlice nineSlice, int x, int y, int z, int width, int height) {
        GuiSpriteScaling.NineSlice.Border border = nineSlice.border();
        int n = Math.min(border.left(), width / 2);
        int o = Math.min(border.right(), width / 2);
        int p = Math.min(border.top(), height / 2);
        int q = Math.min(border.bottom(), height / 2);
        if (width == nineSlice.width() && height == nineSlice.height()) {
            this.blitSprite(textureAtlasSprite, nineSlice.width(), nineSlice.height(), 0, 0, x, y, z, width, height);
        } else if (height == nineSlice.height()) {
            this.blitSprite(textureAtlasSprite, nineSlice.width(), nineSlice.height(), 0, 0, x, y, z, n, height);
            this.blitTiledSprite(textureAtlasSprite, x + n, y, z, width - o - n, height, n, 0, nineSlice.width() - o - n, nineSlice.height(), nineSlice.width(), nineSlice.height());
            this.blitSprite(textureAtlasSprite, nineSlice.width(), nineSlice.height(), nineSlice.width() - o, 0, x + width - o, y, z, o, height);
        } else if (width == nineSlice.width()) {
            this.blitSprite(textureAtlasSprite, nineSlice.width(), nineSlice.height(), 0, 0, x, y, z, width, p);
            this.blitTiledSprite(textureAtlasSprite, x, y + p, z, width, height - q - p, 0, p, nineSlice.width(), nineSlice.height() - q - p, nineSlice.width(), nineSlice.height());
            this.blitSprite(textureAtlasSprite, nineSlice.width(), nineSlice.height(), 0, nineSlice.height() - q, x, y + height - q, z, width, q);
        } else {
            this.blitSprite(textureAtlasSprite, nineSlice.width(), nineSlice.height(), 0, 0, x, y, z, n, p);
            this.blitTiledSprite(textureAtlasSprite, x + n, y, z, width - o - n, p, n, 0, nineSlice.width() - o - n, p, nineSlice.width(), nineSlice.height());
            this.blitSprite(textureAtlasSprite, nineSlice.width(), nineSlice.height(), nineSlice.width() - o, 0, x + width - o, y, z, o, p);
            this.blitSprite(textureAtlasSprite, nineSlice.width(), nineSlice.height(), 0, nineSlice.height() - q, x, y + height - q, z, n, q);
            this.blitTiledSprite(textureAtlasSprite, x + n, y + height - q, z, width - o - n, q, n, nineSlice.height() - q, nineSlice.width() - o - n, q, nineSlice.width(), nineSlice.height());
            this.blitSprite(textureAtlasSprite, nineSlice.width(), nineSlice.height(), nineSlice.width() - o, nineSlice.height() - q, x + width - o, y + height - q, z, o, q);
            this.blitTiledSprite(textureAtlasSprite, x, y + p, z, n, height - q - p, 0, p, n, nineSlice.height() - q - p, nineSlice.width(), nineSlice.height());
            this.blitTiledSprite(textureAtlasSprite, x + n, y + p, z, width - o - n, height - q - p, n, p, nineSlice.width() - o - n, nineSlice.height() - q - p, nineSlice.width(), nineSlice.height());
            this.blitTiledSprite(textureAtlasSprite, x + width - o, y + p, z, n, height - q - p, nineSlice.width() - o, p, o, nineSlice.height() - q - p, nineSlice.width(), nineSlice.height());
        }
    }

    void blitSprite(class_1058 textureAtlasSprite, int i, int j, int k, int l, int m, int n, int o, int p, int q);

    void blitSprite(class_1058 textureAtlasSprite, int i, int j, int k, int l, int m);
    //?}

    //? if <1.21.2 {
    default void blitTiledSprite(class_1058 textureAtlasSprite, int i, int j, int k, int l, int m, int n, int o, int p, int q, int r, int s) {
        if (l <= 0 || m <= 0 ) {
            return;
        }
        if (p <= 0 || q <= 0) {
            throw new IllegalArgumentException("Tiled sprite texture size must be positive, got " + p + "x" + q);
        }
        RenderSystem.setShaderTexture(0, textureAtlasSprite.method_45852());
        RenderSystem.setShader(class_757::method_34542);
        Matrix4f matrix4f = context().method_51448().method_23760().method_23761();

        //? if >=1.20.5 {
        /*BufferBuilder bufferBuilder = Tesselator.getInstance().begin(VertexFormat.Mode.QUADS, DefaultVertexFormat.POSITION_TEX);
        *///?} else {
        class_287 bufferBuilder = class_289.method_1348().method_1349();
        bufferBuilder.method_1328(class_293.class_5596.field_27382, class_290.field_1585);
        //?}

        for(int t = 0; t < l; t += p) {
            int u = Math.min(p, l - t);

            for(int v = 0; v < m; v += q) {
                int w = Math.min(q, m - v);
                addBlitSpriteQuad(textureAtlasSprite, bufferBuilder, matrix4f, r, s, n, o, i + t, j + v, k, u, w);
            }
        }
        class_286.method_43433(bufferBuilder./*? if <1.20.5 {*/method_1326/*?} else {*//*buildOrThrow*//*?}*/());
    }

    //? if <=1.20.1 {
    private void addBlitSpriteQuad(class_1058 textureAtlasSprite, class_287 bufferBuilder, Matrix4f matrix4f, int i, int j, int k, int l, int m, int n, int o, int p, int q) {
        addBlitQuad(bufferBuilder, matrix4f, m, m + p, n, n + q, o, textureAtlasSprite.method_4580((float)k / (float)i * 16), textureAtlasSprite.method_4580((float)(k + p) / (float)i * 16), textureAtlasSprite.method_4570((float)l / (float)j * 16), textureAtlasSprite.method_4570((float)(l + q) / (float)j * 16));
    }
    //?} else {
    /*private void addBlitSpriteQuad(TextureAtlasSprite textureAtlasSprite, BufferBuilder bufferBuilder, Matrix4f matrix4f, int i, int j, int k, int l, int m, int n, int o, int p, int q) {
        addBlitQuad(bufferBuilder, matrix4f, m, m + p, n, n + q, o, textureAtlasSprite.getU((float)k / (float)i), textureAtlasSprite.getU((float)(k + p) / (float)i), textureAtlasSprite.getV((float)l / (float)j), textureAtlasSprite.getV((float)(l + q) / (float)j));
    }
    *///?}

    private void addBlitQuad(class_287 bufferBuilder, Matrix4f matrix4f, int i, int j, int k, int l, int m, float f, float g, float h, float n) {
        //? if <1.20.5 {
        bufferBuilder.method_22918(matrix4f, (float)i, (float)k, (float)m).method_22913(f, h).method_1344();
        bufferBuilder.method_22918(matrix4f, (float)i, (float)l, (float)m).method_22913(f, n).method_1344();
        bufferBuilder.method_22918(matrix4f, (float)j, (float)l, (float)m).method_22913(g, n).method_1344();
        bufferBuilder.method_22918(matrix4f, (float)j, (float)k, (float)m).method_22913(g, h).method_1344();
        //?} else {
        /*bufferBuilder.addVertex(matrix4f, (float)i, (float)k, (float)m).setUv(f, h);
        bufferBuilder.addVertex(matrix4f, (float)i, (float)l, (float)m).setUv(f, n);
        bufferBuilder.addVertex(matrix4f, (float)j, (float)l, (float)m).setUv(g, n);
        bufferBuilder.addVertex(matrix4f, (float)j, (float)k, (float)m).setUv(g, h);
        *///?}
    }
    //?}

    //? if <1.21.6 {

    void setColor(int color, boolean changeBlend);

    void setColor(float r, float g, float b, float a, boolean changeBlend);

    default void setColor(int color) {
        setColor(color, false);
    }

    default void setColor(float r, float g, float b, float a) {
        setColor(r, g, b, a, false);
    }


    float[] getColor();

    default void clearColor(boolean changeBlend) {
        setColor(1.0f,1.0f,1.0f,1.0f, changeBlend);
    }

    default void clearColor() {
        clearColor(false);
    }

    //?}

    //? if >=1.21.2 {
    /*void setBlitColor(int color);

    void setBlitColor(float r, float g, float b, float a);

    int getBlitColor();

    default void clearBlitColor() {
        setBlitColor(1.0f,1.0f,1.0f,1.0f);
    }
    *///?}

    @Deprecated
    void disableDepthTest();

    @Deprecated
    void enableDepthTest();

    interface AtlasAccessor {
        static AtlasAccessor of(class_1059 atlas) {
            return (AtlasAccessor) atlas;
        }
        Map<net.minecraft.class_2960, class_1058> getTexturesByName();
    }

    interface Accessor {
        FactoryGuiGraphics getFactoryGuiGraphics();
    }

}

package wily.factoryapi.mixin.base;

import net.minecraft.class_1060;
import net.minecraft.class_3300;
import net.minecraft.class_3304;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
//? if <=1.20.1 {
import wily.factoryapi.FactoryAPIClient;
import wily.factoryapi.base.client.GuiSpriteManager;
//?}

@Mixin(class_1060.class)
public class TextureManagerMixin {
    //? if <=1.20.1 {
    @Inject(method = "<init>", at = @At("RETURN"))
    public void init(class_3300 arg, CallbackInfo ci){
        ((class_3304)arg).method_14477(FactoryAPIClient.sprites = new GuiSpriteManager((class_1060) (Object) this));
    }
    //?}
}

package wily.factoryapi.base.client;

import wily.factoryapi.base.ArbitrarySupplier;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.class_339;

public interface WidgetAccessor {
    static WidgetAccessor of(class_339 widget){
        return (WidgetAccessor) widget;
    }

    void setSpriteOverride(net.minecraft.class_2960 sprite);

    void setHighlightedSpriteOverride(net.minecraft.class_2960 sprite);

    net.minecraft.class_2960 getSpriteOverride();

    Consumer<class_339> getOnPressOverride();

    void setOnPressOverride(Consumer<class_339> onPressOverride);

    void setVisibility(ArbitrarySupplier<Boolean> supplier);

    //? if <=1.20.1
    void setHeight(int height);
}

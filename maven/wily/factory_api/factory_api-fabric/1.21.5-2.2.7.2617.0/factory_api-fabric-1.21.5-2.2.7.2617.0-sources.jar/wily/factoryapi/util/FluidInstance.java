package wily.factoryapi.util;

import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2561;
import net.minecraft.class_3611;
import net.minecraft.class_3612;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.minecraft.class_9322;
import net.minecraft.class_9323;
import net.minecraft.class_9326;
import net.minecraft.class_9331;
import net.minecraft.class_9335;
import net.minecraft.core.component.*;
import org.jetbrains.annotations.Nullable;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIPlatform;
import java.util.Objects;
import java.util.Optional;

//? if fabric {
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
//?} elif forge {
/*import net.minecraftforge.fluids.FluidStack;
*///?} elif neoforge {
/*import net.neoforged.neoforge.fluids.FluidStack;
*///?}

public class FluidInstance /*? if >=1.20.5 && !forge {*/implements class_9322/*?}*/ {
    private final class_3611 fluid;
    private int amount;
    //? if <1.20.5 || forge {
    /*private CompoundTag tag;
    *///?} else
    private class_9335 components = new class_9335(class_9335.field_49584);


    public static final Codec<FluidInstance> CODEC = RecordCodecBuilder.create(i-> i.group(class_7923.field_41173.method_39673().fieldOf("fluid").forGetter(FluidInstance::getFluid), Codec.INT.fieldOf("amount").forGetter(FluidInstance::getAmount), /*? if <1.20.5 || forge {*/ /*CompoundTag*//*?} else {*/ class_9326/*?}*/.field_49589.fieldOf(/*? if <1.20.5 || forge {*/ /*"nbt"*//*?} else {*/ "components"/*?}*/).forGetter(FluidInstance::/*? if <1.20.5 || forge {*/ /*getNonNullTag*//*?} else {*/getComponentsPatch/*?}*/)).apply(i,FluidInstance::new));
    //? if >=1.20.5
    public static final class_9139<class_9129,FluidInstance> STREAM_CODEC = class_9139.method_56437(FluidInstance::encode, FluidInstance::decode);
    public static final FluidInstance EMPTY = new FluidInstance(class_3612.field_15906,0);


    public FluidInstance(class_3611 fluid, int amount){
        this.fluid = fluid;
        this.amount = amount;
    }
    public FluidInstance(class_3611 fluid, int amount, /*? if <1.20.5 || forge {*/ /*CompoundTag tag*//*?} else {*/ class_9326 components/*?}*/){
        this(fluid,amount);
        //? if <1.20.5 || forge {
        /*this.tag = tag.copy();
        *///?} else
        this.components = class_9335.method_57935(class_9323.method_57827().method_57838(),components);
    }

    public static FluidInstance empty() {
        return EMPTY;
    }

    public static FluidInstance create(FluidInstance fluidInstance, int amount){
        return create(fluidInstance.getFluid(),amount);
    }

    public static FluidInstance create(class_3611 fluid, int amount){
        return new FluidInstance(fluid,amount);
    }

    public static FluidInstance create(class_3611 fluid){
        return new FluidInstance(fluid,1000);
    }

    public static FluidInstance create(class_3611 fluid, long amount){
        return new FluidInstance(fluid,getMilliBucketsFluidAmount(amount));
    }

    //? if <1.20.5 || forge {
    /*public CompoundTag getNonNullTag() {
        return getTag() == null ? new CompoundTag() : getTag();
    }
    *///?}
    //? if <1.20.5 || forge {
    /*public CompoundTag getTag() {
        return tag;
    }

    public void setTag(CompoundTag tag) {
        if (getFluid() != Fluids.EMPTY) this.tag = tag;
    }

    public CompoundTag getOrCreateTag() {
        if (tag == null)
            setTag(new CompoundTag());
        return tag;
    }
    *///?} else {
    @Override
    public class_9323 method_57353() {
        return components;
    }

    public class_9326 getComponentsPatch() {
        return !this.isEmpty() ? components.method_57940() : class_9326.field_49588;
    }

    public <T> T set(class_9331<T> type, @Nullable T component) {
        return this.components.method_57938(type, component);
    }

    public <T> T remove(class_9331<? extends T> type) {
        return this.components.method_57939(type);
    }

    public void applyComponents(class_9326 patch) {
        this.components.method_57936(patch);
    }

    public void applyComponents(class_9323 components) {
        this.components.method_57933(components);
    }

    //?}

    public class_3611 getFluid(){
        return fluid;
    }

    public boolean isEmpty(){
        return getAmount() <= 0;
    }

    public int getAmount(){
        return getFluid() == class_3612.field_15906 ? 0 : amount;
    }

    public long getPlatformAmount(){
        return getPlatformFluidAmount(getAmount());
    }

    public void setAmount(int amount){
        if (getFluid() != class_3612.field_15906) this.amount = amount;
    }

    //? if fabric {
    public FluidVariant toVariant(){
        return FluidVariant.of(fluid,/*? if <1.20.5 {*/ /*tag*//*?} else {*/ getComponentsPatch()/*?}*/);
    }
    //?} else if neoforge || forge {
    /*private FluidStack stack;
    public FluidStack toStack(){
        if (this.isEmpty()) return FluidStack.EMPTY;
        if (stack == null) stack = new FluidStack(fluid,amount);
        stack.setAmount(amount);
        //? if <1.20.5 || forge {
        /^stack.setTag(getTag());
        ^///?} else
        stack.applyComponents(getComponents());
        return stack;
    }
    *///?}
    public void setAmount(long amount){
        setAmount(getMilliBucketsFluidAmount(amount));
    }

    public static FluidInstance fromJson(JsonObject jsonObject){
        if (jsonObject != null) return CODEC.parse(JsonOps.INSTANCE,jsonObject).result().orElse(empty());
        return empty();
    }
    public static FluidInstance fromTag(class_2487 tag){
        return CODEC.parse(class_2509.field_11560,tag).result().orElseGet(()->{
            Optional<String> fluidId = /*? if fabric {*/CompoundTagUtil.getCompoundTag(tag,"fluidVariant").flatMap(c->CompoundTagUtil.getString(c,"fluid"))/*?} else {*//*CompoundTagUtil.getString(tag, "FluidName")*//*?}*/;
            if (fluidId.isPresent()){
                class_3611 fluid = FactoryAPIPlatform.getRegistryValue(FactoryAPI.createLocation(fluidId.get()), class_7923.field_41173);
                if (fluid == class_3612.field_15906) return FluidInstance.empty();
                return FluidInstance.create(fluid,getMilliBucketsFluidAmount(CompoundTagUtil.getLong(tag,/*? if fabric {*/"amount"/*?} else {*//*"Amount"*//*?}*/).orElse(0L)));
            }
            return empty();
        });
    }

    public static class_2487 toTag(FluidInstance stack){
        return CODEC.encodeStart(class_2509.field_11560,stack).result().map(t-> t instanceof class_2487 c ? c : null).orElse(new class_2487());
    }

    public static long getPlatformBucketFluidAmount(){
        return FactoryAPI.getLoader().isFabric() ? 81000L : 1000;
    }

    public static long getPlatformFluidAmount(int amount){
        return (long) ((amount / 1000F) * getPlatformBucketFluidAmount());
    }

    public static int getMilliBucketsFluidAmount(long amount){
        return (int) (((float)amount / getPlatformBucketFluidAmount()) * 1000);
    }

    public boolean isFluidEqual(FluidInstance resource) {
        return getFluid() == resource.getFluid();
    }

    public void grow(int amount) {
        setAmount(getAmount()+amount);
    }

    public void shrink(int amount) {
        setAmount(getAmount()-amount);
    }

    public FluidInstance withAmount(int amount) {
        setAmount(amount);
        return this;
    }

    public FluidInstance copy() {
        return new FluidInstance(getFluid(),getAmount());
    }

    public FluidInstance copyWithAmount(int maxDrain) {
        return copy().withAmount(maxDrain);
    }

    public class_2561 getName() {
        return getFluid().method_15785().method_15759().method_26204().method_9518();
    }

    @Override
    public boolean equals(Object obj) {
        return super.equals(obj) || obj instanceof FluidInstance i && i.isFluidEqual(this) && i.getAmount() == getAmount() &&/*? if <1.20.5 || forge {*/  /*Objects.equals(tag, i.tag) *//*?} else {*/components.equals(i.components)/*?}*/;
    }

    @Override
    public int hashCode() {
        return Objects.hash(fluid, amount, /*? if <1.20.5 || forge {*/  /*tag *//*?} else {*/components/*?}*/);
    }

    public static void encode( /*? if <1.20.5 {*//*FriendlyByteBuf*//*?} else {*/class_9129 /*?}*/ buf, FluidInstance instance){
        buf.method_53002(instance.getAmount());
        if (instance.isEmpty()) return;
        buf.method_10812(class_7923.field_41173.method_10221(instance.getFluid()));
        //? if <1.20.5 || forge {
        /*buf.writeNbt(instance.getNonNullTag());
        *///?} else
        class_9326.field_49590.encode(buf,instance.getComponentsPatch());
    }
    public static FluidInstance decode(/*? if <1.20.5 {*//*FriendlyByteBuf*//*?} else {*/class_9129 /*?}*/ buf){
        int amount = buf.readInt();
        if (amount <= 0) return EMPTY;
        return new FluidInstance(FactoryAPIPlatform.getRegistryValue(buf.method_10810(),class_7923.field_41173), amount, /*? if <1.20.5 || forge {*//*buf.readNbt()*//*?} else {*/class_9326.field_49590.decode(buf)/*?}*/);
    }
}

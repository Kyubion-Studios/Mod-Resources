package wily.factoryapi.util;

import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_1890;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_2561;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.nbt.*;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIPlatform;
import wily.factoryapi.init.FactoryRegistries;

import java.util.*;

public class FactoryItemUtil {
    //? if >=1.20.5 {
    /*public static final Codec<List<Item>> ITEM_COMPONENTS_CODEC = net.minecraft.resources.ResourceLocation.CODEC.xmap(r-> FactoryAPIPlatform.getRegistryValue(r,BuiltInRegistries.ITEM), BuiltInRegistries.ITEM::getKey).listOf();
    public static final StreamCodec<RegistryFriendlyByteBuf,List<Item>> ITEM_COMPONENTS_STREAM_CODEC = ByteBufCodecs.fromCodecWithRegistries(ITEM_COMPONENTS_CODEC);
    *///?}

    public static class_2487 getFromJson(JsonObject obj){
        return class_2487.field_25128.parse(JsonOps.INSTANCE,obj).result().orElseGet(class_2487::new);
    }

    public static List<class_1792> getItemComponents(class_1799 itemStack){
        //? if <1.20.5 {
        List<class_1792> list = new ArrayList<>();
        if (itemStack.method_7985() && !itemStack.method_7969().method_10554("Components",8).isEmpty())
            itemStack.method_7969().method_10554("Components",8).forEach(t->list.add(class_7923.field_41178.method_10223(new net.minecraft.class_2960(t.method_10714()))));
        return list;
        //?} else {
        /*return itemStack.getOrDefault(FactoryRegistries.ITEM_COMPONENTS_COMPONENT.get(),new ArrayList<>());
        *///?}
    }

    public static boolean equalItems(class_1799 itemStack, class_1799 itemStack1){
        //? if <1.20.5 {
        return class_1799.method_31577(itemStack,itemStack1);
        //?} else
        //return ItemStack.isSameItemSameComponents(itemStack,itemStack1);
    }

    public static boolean compareItems(class_1799 itemStack, class_1799 itemStack1, boolean checkCount) {
        return compareItems(itemStack, itemStack1, checkCount, true);
    }

    public static boolean compareItems(class_1799 itemStack, class_1799 itemStack1, boolean checkCount, boolean strict){
        if (strict) {
            if (checkCount) return class_1799.method_7973(itemStack, itemStack1);
            else return equalItems(itemStack, itemStack1);
        } else if (class_1799.method_7984(itemStack, itemStack1) && (!checkCount || itemStack.method_7947() == itemStack1.method_7947())){
            //? if <1.20.5 {
            return class_2512.method_10687(itemStack.method_7969(), itemStack1.method_7969(), true);
            //?} else {
            /*for (TypedDataComponent<?> component : itemStack1.getComponents()) {
                if (!Objects.equals(itemStack.get(component.type()),component.value())) return false;
            }
            *///?}
        }
        return false;
    }

    public static boolean hasCustomName(class_1799 stack){
        return /*? if <1.20.5 {*/stack.method_7938()/*?} else {*//*stack.has(DataComponents.CUSTOM_NAME)*//*?}*/;
    }

    public static void setCustomName(class_1799 stack, class_2561 name){
        //? if <1.20.5 {
        if (name == null) stack.method_7925();
        else stack.method_7977(name);
        //?} else {
        /*stack.set(DataComponents.CUSTOM_NAME,name);
        *///?}
    }

    public static int getEnchantmentLevel(class_1799 stack, /*? if >=1.21 {*/ /*ResourceKey<Enchantment> *//*?} else {*/class_1887/*?}*/ enchantment){
        return getEnchantmentLevel(stack, enchantment, FactoryAPI.currentServer.method_30611());
    }

    public static int getEnchantmentLevel(class_1799 stack, /*? if >=1.21 {*/ /*ResourceKey<Enchantment> *//*?} else {*/class_1887/*?}*/ enchantment, class_5455 registryAccess){
        return /*? if <1.21 {*/class_1890.method_8225(enchantment, stack)/*?} else {*//*FactoryAPIPlatform.getRegistryValue(registryAccess, enchantment).map(e->stack.getEnchantments().getLevel(e)).orElse(0)*//*?}*/;
    }

    public static class_6880<class_1792> getItemHolder(class_1799 stack) {
        return stack./*? if >=26.1 {*//*typeHolder*//*?} else {*/method_41409/*?}*/();
    }

}

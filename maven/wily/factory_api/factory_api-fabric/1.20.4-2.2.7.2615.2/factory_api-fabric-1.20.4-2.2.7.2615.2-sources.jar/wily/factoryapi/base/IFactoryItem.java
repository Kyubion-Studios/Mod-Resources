package wily.factoryapi.base;

import org.jetbrains.annotations.Nullable;
import wily.factoryapi.base.client.IFactoryItemClientExtension;

import java.util.function.Consumer;
import net.minecraft.class_1297;
import net.minecraft.class_1304;
import net.minecraft.class_1799;

public interface IFactoryItem {
    default <T extends IPlatformHandler> ArbitrarySupplier<T> getStorage(FactoryStorage<T> storage, class_1799 stack){
        return ()->null;
    }

    //? if <1.21.2 {
    default @Nullable String getArmorTexture(class_1799 stack, class_1297 entity, class_1304 slot) {
        net.minecraft.class_2960 texture = getArmorLocation(stack,entity,slot);
        return texture == null ? null : texture.toString();
    }
    //?}

    default @Nullable net.minecraft.class_2960 getArmorLocation(class_1799 stack, /*? if <1.21.2 {*/class_1297 entity, /*?}*/ class_1304 slot) {
        return /*? if <1.21.2 {*/null /*?} else if <1.21.4 {*/ /*stack.get(DataComponents.EQUIPPABLE).model().orElse(null)*//*?} else {*//*stack.get(DataComponents.EQUIPPABLE).assetId().map(ResourceKey::/^? if <1.21.11 {^/location/^?} else {^//^identifier^//^?}^/).orElse(null)*//*?}*/;
    }

    default void clientExtension(Consumer<IFactoryItemClientExtension> clientExtensionConsumer){
    }
}

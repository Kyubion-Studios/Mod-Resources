package wily.factoryapi;

//? if >=1.21 {
/*import com.mojang.serialization.MapCodec;
import net.minecraft.client.DeltaTracker;
*///?}
import com.mojang.serialization.JsonOps;
import wily.factoryapi.base.FactoryExtraMenuSupplier;
import wily.factoryapi.base.client.screen.FactoryConfigScreen;
import wily.factoryapi.base.network.*;
import wily.factoryapi.mixin.base.MenuScreensAccessor;
import wily.factoryapi.mixin.base.MenuTypeAccessor;
//? if fabric {
import wily.factoryapi.base.compat.client.FactoryAPIModMenuCompat;
//? if <1.21.6 {
import net.fabricmc.fabric.api.blockrenderlayer.v1.BlockRenderLayerMap;
//?} else if <26.1 {
/*import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
*///?}
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.model.loading.v1.ModelLoadingPlugin;
import net.fabricmc.fabric.api.transfer.v1.client.fluid.FluidVariantRendering;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.minecraft.class_1058;
import net.minecraft.class_1087;
import net.minecraft.class_1091;
import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1309;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1792;
import net.minecraft.class_1863;
import net.minecraft.class_1920;
import net.minecraft.class_1921;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_322;
import net.minecraft.class_326;
import net.minecraft.class_3264;
import net.minecraft.class_3611;
import net.minecraft.class_3695;
import net.minecraft.class_374;
import net.minecraft.class_3887;
import net.minecraft.class_3917;
import net.minecraft.class_3929;
import net.minecraft.class_3936;
import net.minecraft.class_437;
import net.minecraft.class_4608;
import net.minecraft.class_5455;
import net.minecraft.class_5599;
import net.minecraft.class_5601;
import net.minecraft.class_5607;
import net.minecraft.class_5617;
import net.minecraft.class_583;
import net.minecraft.class_746;
import net.minecraft.class_773;
import net.minecraft.class_897;
import net.minecraft.class_922;
import net.fabricmc.fabric.api.client.rendering.v1.*;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
//?} else if forge {
/*import net.minecraftforge.client.event.*;
import net.minecraftforge.client.extensions.common.IClientFluidTypeExtensions;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.event.TickEvent;
//? if <1.21.6 {
import net.minecraftforge.eventbus.api.EventPriority;
//?}
import net.minecraftforge.fml.event.lifecycle.FMLClientSetupEvent;
import net.minecraftforge.client.ConfigScreenHandler;
import net.minecraftforge.fml.ModList;
*///?} else if neoforge {
/*import net.neoforged.bus.api.EventPriority;
import net.neoforged.fml.event.lifecycle.FMLClientSetupEvent;
import net.neoforged.fml.ModList;
//? if <1.20.5 {
/^import net.neoforged.neoforge.event.TickEvent;
import net.neoforged.neoforge.client.ConfigScreenHandler;
^///?} else {
import net.neoforged.neoforge.client.extensions.common.RegisterClientExtensionsEvent;
import net.neoforged.neoforge.client.gui.IConfigScreenFactory;
//?}
import net.neoforged.neoforge.client.event.*;
import net.neoforged.neoforge.client.extensions.common.IClientFluidTypeExtensions;
import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
import net.neoforged.neoforge.common.NeoForge;
*///?}
import org.jetbrains.annotations.Nullable;
//? if <=1.20.1 {
/*import wily.factoryapi.base.client.GuiSpriteManager;
*///?}
import wily.factoryapi.base.IFactoryItem;
import wily.factoryapi.base.client.*;
import wily.factoryapi.base.config.FactoryConfig;
import wily.factoryapi.util.*;

import java.util.*;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.function.Supplier;


public class FactoryAPIClient {
    public static final net.minecraft.class_2960 BLOCK_ATLAS = FactoryAPI.createVanillaLocation("textures/atlas/blocks.png");
    public static final net.minecraft.class_2960 BLOCK_ATLAS_ID = FactoryAPI.createVanillaLocation("blocks");
    public static final SecureExecutor SECURE_EXECUTOR = new SecureExecutor() {
        @Override
        public boolean isSecure() {
            return class_310.method_1551().field_1724 != null;
        }
    };
    private static final Map<String, Function<class_437,class_437>> defaultConfigScreens = new HashMap<>();

    public static UIDefinitionManager uiDefinitionManager;

    public static final Map<net.minecraft.class_2960, ExtraModelId> extraModels = new HashMap<>();

    private static final Set<String> playerMods = new HashSet<>();

    //? if <=1.20.1 {
    /*public static GuiSpriteManager sprites;
    *///?}

    public interface PlayerEvent extends Consumer<class_746>{
        FactoryEvent<PlayerEvent> JOIN_EVENT = new FactoryEvent<>(e-> (s -> e.invokeAll(t-> t.accept(s))));
        FactoryEvent<PlayerEvent> DISCONNECTED_EVENT = new FactoryEvent<>(e-> (s -> e.invokeAll(t-> t.accept(s))));
    }

    //? if >=1.21 {
    /*public static DeltaTracker getDeltaTracker() {
        return Minecraft.getInstance()./^? if <1.21.2 {^/getTimer/^?} else {^//^getDeltaTracker^//^?}^/();
    }
    *///?}
    //? if <1.21.5 {
    public static class_1087 getExtraModel(net.minecraft.class_2960 resourceLocation) {
        return class_310.method_1551().method_1554().method_4742(extraModels.get(resourceLocation).modelId());
    }
    //?} else if <26.1 {
    /*public static BlockStateModel getExtraModel(net.minecraft.resources.ResourceLocation resourceLocation) {
        return Minecraft.getInstance().getBlockRenderer().getBlockModel(extraModels.get(resourceLocation).blockState());
    }
    *///?} else {
    /*public static BlockStateModel getExtraModel(net.minecraft.resources.ResourceLocation resourceLocation) {
        return Minecraft.getInstance().getModelManager().getBlockStateModelSet().get(extraModels.get(resourceLocation).blockState());
    }
    *///?}

    public static boolean hasAPIOnServer() {
        return hasModOnServer(FactoryAPI.MOD_ID);
    }

    public static boolean hasModOnServer(String id) {
        return playerMods.contains(id);
    }

    public static boolean hasLevel() {
        return class_310.method_1551().field_1687 != null;
    }

    public static class_5455 getRegistryAccess() {
        return class_310.method_1551().field_1687.method_30349();
    }

    public static class_3695 getProfiler() {
        return /*? if <1.21.2 {*/class_310.method_1551().method_16011/*?} else {*//*Profiler.get*//*?}*/();
    }

    public static /*? if <1.21.2 {*/class_374/*?} else {*//*ToastManager*//*?}*/getToasts() {
        return class_310.method_1551()./*? if <1.21.2 {*/method_1566/*?} else {*//*getToastManager*//*?}*/();
    }

    public static float getPartialTick() {
        return /*? if <1.20.5 {*/class_310.method_1551().method_1534()/*?} else {*//*FactoryAPIClient.getDeltaTracker().getRealtimeDeltaTicks()*//*?}*/;
    }

    public static float getGamePartialTick(boolean allowFrozen) {
        return /*? if <1.20.5 {*/(class_310.method_1551().method_1493() ? MinecraftAccessor.getInstance().getPausePartialTick() : /*? if >=1.20.3 {*/class_310.method_1551().field_1687 != null && class_310.method_1551().field_1687.method_54719().method_54751() || !allowFrozen ? class_310.method_1551().method_1488() : 1.0f/*?} else {*//*Minecraft.getInstance().getFrameTime()*//*?}*/)/*?} else {*/ /*FactoryAPIClient.getDeltaTracker().getGameTimeDeltaPartialTick(!allowFrozen)*//*?}*/;
    }

    //? if <1.21.2 {
    public static class_1863 getRecipeManager() {
        return class_310.method_1551().field_1687.method_8433();
    }
    //?}

    public static class_1937 getLevel() {
        return class_310.method_1551().field_1687;
    }

    public static long getWindow() {
        return class_310.method_1551().method_22683()./*? if >=1.21.9 {*//*handle()*//*?} else {*/method_4490()/*?}*/;
    }

    public static class_437 getScreen() {
        return class_310.method_1551().field_1755;
    }

    public static void init() {
        registerConfigScreen(FactoryAPIPlatform.getModInfo(FactoryAPI.MOD_ID), FactoryConfigScreen::createFactoryAPIConfigScreen);

        FactoryEvent.registerReloadListener(class_3264.field_14188, uiDefinitionManager = new UIDefinitionManager());
        setup(m->{
            FactoryOptions.CLIENT_STORAGE.load();
        });
        preTick(m-> SECURE_EXECUTOR.executeAll());
        FactoryGuiElement.HOTBAR.post().register(graphics -> UIAccessor.of(class_310.method_1551().field_1705).getChildrenRenderables().forEach(r -> {
            //? if >=26.1 {
            /*r.extractRenderState(graphics, 0, 0, getPartialTick());
            *///?} else {
            r.method_25394(graphics, 0, 0, getPartialTick());
            //?}
        }));
        PlayerEvent.JOIN_EVENT.register(l->{
            DynamicUtil.REGISTRY_OPS_CACHE.invalidateAll();
            DynamicUtil.DYNAMIC_ITEMS_CACHE.asMap().keySet().forEach(DynamicUtil.DYNAMIC_ITEMS_CACHE::refresh);
        });
        PlayerEvent.DISCONNECTED_EVENT.register(l->{
            DynamicUtil.REGISTRY_OPS_CACHE.invalidateAll();
            DynamicUtil.DYNAMIC_ITEMS_CACHE.asMap().keySet().forEach(DynamicUtil.DYNAMIC_ITEMS_CACHE::refresh);
            if (hasAPIOnServer()) FactoryConfig.COMMON_STORAGES.values().forEach(c -> {
                if (!c.isServerOnly() && c.allowSync()) c.load();
            });
            playerMods.clear();
            //? if >=1.21.2 {
            /*CommonRecipeManager.clearRecipes();
            *///?}
        });
        FactoryEvent.serverStopped(server -> {
            FactoryConfig.COMMON_STORAGES.values().forEach(c -> {
                if (c.isServerOnly()) c.resetAndUnload();
            });
        });
        //? if fabric {
        //? if >=1.21.9 {
        /*IFactoryItemClientExtension.map.forEach((i,c)-> ArmorRenderer.register((matrices, vertexConsumers, stack, entity, slot, light, contextModel)-> vertexConsumers.submitModel(c.getHumanoidArmorModel(entity,stack,slot,contextModel), entity, matrices, /^?if <1.21.11 {^/RenderType/^?} else {^//^RenderTypes^//^?}^/.entityCutout(((IFactoryItem) i).getArmorLocation(stack, slot)), light, OverlayTexture.NO_OVERLAY, 0xFFFFFF, null), i));
        *///?} else {
        IFactoryItemClientExtension.map.forEach((i,c)-> ArmorRenderer.register((matrices, vertexConsumers, stack, entity, slot, light, contextModel)-> c.getHumanoidArmorModel(entity,stack,slot,contextModel).method_2828(matrices,vertexConsumers.getBuffer(class_1921.method_23576(((IFactoryItem) i).getArmorLocation(stack,/*? if <1.21.2 {*/ entity, /*?}*/slot))), light, class_4608.field_21444/*? if <=1.20.6 {*/, 1.0F,1.0F,1.0F, 1.0F/*?}*/),i));
        //?}
        if (FactoryAPI.isModLoaded("modmenu")) FactoryAPIModMenuCompat.init();
        //?} else if neoforge && >=1.20.5 {
        /*FactoryAPIPlatform.getModEventBus().addListener(RegisterClientExtensionsEvent.class,r->IFactoryItemClientExtension.map.forEach((i,c)->r.registerItem(new IClientItemExtensions() {
            @Override
            //? if <1.21.2 {
            /^public HumanoidModel<?> getHumanoidArmorModel(LivingEntity livingEntity, ItemStack itemStack, EquipmentSlot equipmentSlot, HumanoidModel<?> original) {
                return c.getHumanoidArmorModel(livingEntity, itemStack, equipmentSlot, original);
            }
            ^///?} else {
            public Model getHumanoidArmorModel(ItemStack itemStack, /^? if <1.21.4 {^/ /^EquipmentModel.LayerType^//^?} else {^/EquipmentClientInfo.LayerType/^?}^/ layerType, Model original) {
                return c.getHumanoidArmorModel(itemStack, layerType, original);
            }
            //?}
        }, i)));
        *///?}
        //? if >=1.21.4 {
        /*IFactoryItemClientExtension.map.forEach(((item, iFactoryItemClientExtension) -> {
            IFactoryBlockEntityWLRenderer renderer = iFactoryItemClientExtension.getCustomRenderer();
            if (renderer == null) return;
            SpecialModelRenderersAccessor.getIdMapper().put(BuiltInRegistries.ITEM.getKey(item), renderer.createUnbakedCodec());
        }));
        *///?}
    }

    public static final FactoryEvent<Consumer<class_310>> STOPPING = new FactoryEvent<>(e-> m-> e.invokeAll(l->l.accept(m)));
    public static final FactoryEvent<Consumer<class_310>> RESIZE_DISPLAY = new FactoryEvent<>(e-> m-> e.invokeAll(l->l.accept(m)));

    //? if fabric {
    public static <T extends CommonNetwork.Payload> void registerPayload(CommonNetwork.Identifier<T> id) {
        //? <1.20.5 {
        ClientPlayNetworking.registerGlobalReceiver(id.location(), (m, l, b, s) -> id.decode(b).applyClient());
        //?} else {
        /*ClientPlayNetworking.registerGlobalReceiver(id.type(), (payload, context) -> payload.applyClient());
        *///?}
    }
    //?} else if forge || neoforge {
    /*public static void registerReloadListener(PreparableReloadListener reloadListener) {
        //? if >=1.21.4 && neoforge {
        /^FactoryAPIPlatform.getModEventBus().addListener(EventPriority.NORMAL, false, AddClientReloadListenersEvent.class, e-> e.addListener(FactoryAPI.createLocation(reloadListener.getName()), reloadListener));
        ^///?} else {
        ((ReloadableResourceManager)Minecraft.getInstance().getResourceManager()).registerReloadListener(reloadListener);
        //?}
    }
    *///?}

    public static <T extends class_1703> void handleExtraMenu(SecureExecutor executor, class_1657 player, class_3917<T> menuType, OpenExtraMenuPayload payload) {
        var menu = ((MenuTypeAccessor)menuType).getConstructor() instanceof FactoryExtraMenuSupplier<?> supplier ? (T) supplier.create(payload.menuId(), player.method_31548(), payload.extra()) : menuType.method_17434(payload.menuId(), player.method_31548());
        player.field_7512 = menu;
        executor.execute(()-> class_310.method_1551().method_1507(MenuScreensAccessor.getConstructor(menuType).create(menu, player.method_31548(), payload.component())));
    }

    public static void setup(Consumer<class_310> listener) {
        //? if fabric {
        ClientLifecycleEvents.CLIENT_STARTED.register(listener::accept);
        //?} elif (forge && <1.21.6) || neoforge {
        /*FactoryAPIPlatform.getModEventBus().addListener(EventPriority.NORMAL, false, FMLClientSetupEvent.class, e-> listener.accept(Minecraft.getInstance()));
        *///?} else if forge {
        /*FMLClientSetupEvent.getBus(FactoryAPIPlatform.getModEventBus()).addListener(e-> listener.accept(Minecraft.getInstance()));
        *///?} else
        /*throw new AssertionError();*/
    }

    public static void preTick(Consumer<class_310> listener) {
        //? if fabric {
        ClientTickEvents.START_CLIENT_TICK.register(listener::accept);
        //?} elif forge && <1.21.6 {
        /*MinecraftForge.EVENT_BUS.addListener(EventPriority.NORMAL, false, /^? if <1.21 {^//^TickEvent.ClientTickEvent^//^?} else {^/TickEvent.ClientTickEvent.Pre/^?}^/.class, e-> {
            if (e.phase == TickEvent.Phase.START) listener.accept(Minecraft.getInstance());
        });
        *///?} elif forge {
        /*TickEvent.ClientTickEvent.Pre.BUS.addListener(p-> listener.accept(Minecraft.getInstance()));
        *///?} elif neoforge {
        /*NeoForge.EVENT_BUS.addListener(/^? if <1.20.5 {^/ /^TickEvent.ClientTickEvent.class^//^?} else {^/ClientTickEvent.Pre.class/^?}^/, e-> {
            /^? if <1.20.5 {^//^if (e.phase == TickEvent.Phase.START)^//^?}^/ listener.accept(Minecraft.getInstance());
        });
         *///?} else
        /*throw new AssertionError();*/
    }

    public static void postTick(Consumer<class_310> listener) {
        //? if fabric {
        ClientTickEvents.END_CLIENT_TICK.register(listener::accept);
        //?} elif forge && <1.21.6 {
        /*MinecraftForge.EVENT_BUS.addListener(EventPriority.NORMAL, false, /^? if <1.21 {^//^TickEvent.ClientTickEvent^//^?} else {^/TickEvent.ClientTickEvent.Post/^?}^/.class, e-> {
            if (e.phase == TickEvent.Phase.END)  listener.accept(Minecraft.getInstance());
        });
        *///?} elif forge {
        /*TickEvent.ClientTickEvent.Post.BUS.addListener(p-> listener.accept(Minecraft.getInstance()));
        *///?} elif neoforge {
        /*NeoForge.EVENT_BUS.addListener(/^? if <1.20.5 {^/ /^TickEvent.ClientTickEvent.class^//^?} else {^/ClientTickEvent.Post.class/^?}^/, e-> {
            /^? if <1.20.5 {^//^if (e.phase == TickEvent.Phase.END)^//^?}^/ listener.accept(Minecraft.getInstance());
        });
         *///?} else
        /*throw new AssertionError();*/
    }

    public static class_1058 getFluidStillTexture(class_3611 fluid) {
        //? if >=26.1 {
        /*return Minecraft.getInstance().getModelManager().getFluidStateModelSet().get(fluid.defaultFluidState()).stillMaterial().sprite();
        *///?} else if fabric {
        return FluidVariantRendering.getSprite(FluidVariant.of(fluid));
        //?} elif (forge || neoforge) && <1.21.9 {
        /*return Minecraft.getInstance().getTextureAtlas(BLOCK_ATLAS).apply(IClientFluidTypeExtensions.of(fluid).getStillTexture());
        *///?} else if forge || neoforge {
        /*return Minecraft.getInstance().getAtlasManager().getAtlasOrThrow(BLOCK_ATLAS_ID).getSprite(IClientFluidTypeExtensions.of(fluid).getStillTexture());
        *///?} else
        /*throw new AssertionError();*/
    }

    public static class_1058 getFluidFlowingTexture(class_3611 fluid) {
        //? if >=26.1 {
        /*return Minecraft.getInstance().getModelManager().getFluidStateModelSet().get(fluid.defaultFluidState()).flowingMaterial().sprite();
        *///?} else if fabric {
        return FluidVariantRendering.getSprites(FluidVariant.of(fluid))[1];
        //?} elif (forge || neoforge) && <1.21.9 {
        /*return Minecraft.getInstance().getTextureAtlas(BLOCK_ATLAS).apply(IClientFluidTypeExtensions.of(fluid).getFlowingTexture());
        *///?} else if forge || neoforge {
        /*return Minecraft.getInstance().getAtlasManager().getAtlasOrThrow(BLOCK_ATLAS_ID).getSprite(IClientFluidTypeExtensions.of(fluid).getFlowingTexture());
        *///?} else
        /*throw new AssertionError();*/
    }

    public static int getFluidColor(class_3611 fluid, class_1920 view, class_2338 pos) {
        //? if >=26.1 {
        /*return Minecraft.getInstance().getModelManager().getFluidStateModelSet().get(fluid.defaultFluidState()).tintSource().colorInWorld(fluid.defaultFluidState().createLegacyBlock(), view, pos);
        *///?} else if fabric {
        return FluidVariantRendering.getColor(FluidVariant.of(fluid),view,pos);
        //?} elif (forge || neoforge) && <26.1 {
        /*return IClientFluidTypeExtensions.of(fluid).getTintColor(fluid.defaultFluidState(),view,pos);
        *///?} else
        /*throw new AssertionError();*/
    }

    public static int getFluidColor(FluidInstance fluid) {
        //? if >=26.1 {
        /*return Minecraft.getInstance().getModelManager().getFluidStateModelSet().get(fluid.getFluid().defaultFluidState()).tintSource().color(fluid.getFluid().defaultFluidState().createLegacyBlock());
        *///?} else if fabric {
        return FluidVariantRendering.getColor(fluid.toVariant(), null, null);
         //?} elif forge || neoforge {
        /*return IClientFluidTypeExtensions.of(fluid.getFluid()).getTintColor(fluid.toStack());
        *///?} else
        /*throw new AssertionError();*/
    }

    public static void registerKeyMapping(Consumer<Consumer<class_304>> registry) {
        //? if fabric && >=26.1 {
        /*registry.accept(net.fabricmc.fabric.api.client.keymapping.v1.KeyMappingHelper::registerKeyMapping);
        *///?} else if fabric {
        registry.accept(net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper::registerKeyBinding);
        //?} elif (forge && <1.21.6) || neoforge {
        /*FactoryAPIPlatform.getModEventBus().addListener(EventPriority.NORMAL, false, RegisterKeyMappingsEvent.class, e->registry.accept(e::register));
        *///?} elif forge && <1.21.9 {
        /*RegisterKeyMappingsEvent.getBus(FactoryAPIPlatform.getModEventBus()).addListener(e->registry.accept(e::register));
        *///?} elif forge {
        /*RegisterKeyMappingsEvent.BUS.addListener(e->registry.accept(e::register));
        *///?} else
        /*throw new AssertionError();*/
    }

    public static class_1657 getClientPlayer() {
        return class_310.method_1551().field_1724;
    }

    public static class_437 getConfigScreen(ModInfo mod, class_437 screen) {
        if (defaultConfigScreens.containsKey(mod.getId())) return defaultConfigScreens.get(mod.getId()).apply(screen);
        //? if fabric {
        return FactoryAPI.isModLoaded("modmenu") ? FactoryAPIModMenuCompat.getConfigScreen(mod.getId(),screen) : null;
        //?} else if forge || (neoforge && <1.20.5) {
        /*return ModList/^? if <26.1 || neoforge {^/.get()/^?}^/.getModContainerById(mod.getId()).flatMap(c-> ConfigScreenHandler.getScreenFactoryFor(c.getModInfo())).map(s-> s.apply(Minecraft.getInstance(), screen)).orElse(null);
        *///?} else if neoforge {
        /*return ModList.get().getModContainerById(mod.getId()).flatMap(m-> IConfigScreenFactory.getForMod(m.getModInfo()).map(s -> s.createScreen(m, screen))).orElse(null);
         *///?} else
        //throw new AssertionError();
    }

    public static void registerDefaultConfigScreen(String modId, Function<class_437,class_437> configScreenFactory) {
        defaultConfigScreens.put(modId, configScreenFactory);
    }

    public static void registerConfigScreen(ModInfo mod, Function<class_437,class_437> configScreenFactory) {
        registerDefaultConfigScreen(mod.getId(), configScreenFactory);
        //? if fabric {
        if (FactoryAPI.isModLoaded("modmenu")) setup(m-> FactoryAPIModMenuCompat.registerConfigScreen(mod.getId(), configScreenFactory));
         //?} else if forge || (neoforge && <1.20.5) {
        /*ModList/^? if <26.1 || neoforge {^/.get()/^?}^/.getModContainerById(mod.getId()).ifPresent(c->c.registerExtensionPoint(ConfigScreenHandler.ConfigScreenFactory.class, ()-> new ConfigScreenHandler.ConfigScreenFactory((m,s)->configScreenFactory.apply(s))));
        *///?} else if neoforge {
        /*ModList.get().getModContainerById(mod.getId()).ifPresent(c->c.registerExtensionPoint(IConfigScreenFactory.class, (m,s)-> configScreenFactory.apply(s)));
         *///?}
    }

    public interface MenuScreenRegister{
        <H extends class_1703, S extends class_437 & class_3936<H>> void register(class_3917<? extends H> type, class_3929.class_3930<H, S> factory);
    }

    public static void registerMenuScreen(Consumer<MenuScreenRegister> registry) {
        //? if fabric {
        registry.accept(class_3929::method_17542);
        //?} elif forge || (<1.20.4 && neoforge) {
        /*setup(m-> registry.accept(MenuScreens::register));
        *///?} elif neoforge {
        /*FactoryAPIPlatform.getModEventBus().addListener(RegisterMenuScreensEvent.class, e->registry.accept(e::register));
        *///?} else
        //throw new AssertionError();
    }

    public static void registerBlockColor(Consumer<BiConsumer</*? if >=26.1 {*//*List<BlockTintSource>*//*?} else {*/class_322/*?}*/, class_2248>> registry) {
        //? if fabric && >=26.1 {
        /*registry.accept(BlockColorRegistry::register);
        *///?} else if fabric {
        registry.accept(ColorProviderRegistry.BLOCK::register);
        //?} elif (forge && <1.21.6) || neoforge {
        /*FactoryAPIPlatform.getModEventBus().addListener(EventPriority.NORMAL, false, RegisterColorHandlersEvent./^? if >=26.1 {^/BlockTintSources/^?} else {^//^Block^//^?}^/.class, e->registry.accept(e::register));
        *///?} elif forge && <1.21.9 {
        /*RegisterColorHandlersEvent.Block.getBus(FactoryAPIPlatform.getModEventBus()).addListener(e-> registry.accept(e::register));
        *///?} elif forge {
        /*RegisterColorHandlersEvent.Block.BUS.addListener(e-> registry.accept(e::register));
        *///?} else
        /*throw new AssertionError();*/
    }

    //? if <1.21.4 {
    public static void registerItemColor(Consumer<BiConsumer<class_326, class_1792>> registry) {
        //? if fabric {
        registry.accept(ColorProviderRegistry.ITEM::register);
        //?} elif forge || neoforge {
        /*FactoryAPIPlatform.getModEventBus().addListener(EventPriority.NORMAL, false, RegisterColorHandlersEvent.Item.class, e->registry.accept(e::register));
        *///?} else
        /*throw new AssertionError();*/
    }
    //?}

    // This is done automatically since 26.1 :)
    //? if <26.1 {
    public static void registerRenderType(/*? if <1.21.6 {*/class_1921/*?} else {*//*ChunkSectionLayer*//*?}*/ renderType, class_2248... blocks) {
        //? if fabric {
        BlockRenderLayerMap/*? if <1.21.6 {*/.INSTANCE/*?}*/.putBlocks(renderType,blocks);
        //?} elif forge || neoforge {
        /*for (Block block : blocks) {
            ItemBlockRenderTypes.setRenderLayer(block,renderType);
        }
        *///?} else
        /*throw new AssertionError();*/
    }

    public static void registerRenderType(/*? if <1.21.6 {*/class_1921/*?} else {*//*ChunkSectionLayer*//*?}*/ renderType, class_3611... fluids) {
        //? if fabric {
        BlockRenderLayerMap/*? if <1.21.6 {*/.INSTANCE/*?}*/.putFluids(renderType,fluids);
        //?} elif forge || neoforge {
        /*for (Fluid fluid : fluids) {
            ItemBlockRenderTypes.setRenderLayer(fluid,renderType);
        }
        *///?} else
        /*throw new AssertionError();*/
    }
    //?}

    public record ExtraModelId(class_2689<class_2248,class_2680> stateDefinition, class_2680 blockState, net.minecraft.class_2960 id/*? if <1.21.5 {*/, class_1091 modelId/*?}*/) {
        public static ExtraModelId create(net.minecraft.class_2960 id) {
            class_2689<class_2248,class_2680> stateDefinition = new class_2689.class_2690<class_2248, class_2680>(class_2246.field_10124).method_11668(class_2248::method_9564, class_2680::new);
            return new ExtraModelId(stateDefinition, stateDefinition.method_11664(), id/*? if <1.21.5 {*/, class_773.method_3336(id, stateDefinition.method_11664())/*?}*/);
        }
    }

    public static void registerExtraModels(Consumer<Consumer<net.minecraft.class_2960>> registry) {
        registry.accept(id-> extraModels.put(id, ExtraModelId.create(id)));
    }

    public static <T extends class_1297> void registerEntityRenderer(Supplier<? extends class_1299<? extends T>> type, class_5617<T> provider) {
        //? if fabric {
        EntityRendererRegistry.register(type.get(), provider);
        //?} else if (forge && <1.21.6) || neoforge {
        /*FactoryAPIPlatform.getModEventBus().addListener(EventPriority.NORMAL, false, EntityRenderersEvent.RegisterRenderers.class, e-> e.registerEntityRenderer(type.get(),provider));
        *///?} elif forge && <1.21.9 {
        /*EntityRenderersEvent.RegisterRenderers.getBus(FactoryAPIPlatform.getModEventBus()).addListener(e-> e.registerEntityRenderer(type.get(),provider));
        *///?} elif forge {
        /*EntityRenderersEvent.RegisterRenderers.BUS.addListener(e-> e.registerEntityRenderer(type.get(),provider));
        *///?} else
        /*throw new AssertionError();*/
    }

    public static void registerLayerDefinition(class_5601 location, Supplier<class_5607> definition) {
        //? if fabric && >=26.1 {
        /*ModelLayerRegistry.registerModelLayer(location, definition::get);
        *///?} else if fabric {
        EntityModelLayerRegistry.registerModelLayer(location, definition::get);
         //?} else if (forge && <1.21.6) || neoforge {
        /*FactoryAPIPlatform.getModEventBus().addListener(EventPriority.NORMAL, false, EntityRenderersEvent.RegisterLayerDefinitions.class, e-> e.registerLayerDefinition(location,definition));
        *///?} else if forge && <1.21.10 {
        /*EntityRenderersEvent.RegisterLayerDefinitions.getBus(FactoryAPIPlatform.getModEventBus()).addListener(e-> e.registerLayerDefinition(location,definition));
        *///?} else if forge {
        /*EntityRenderersEvent.RegisterLayerDefinitions.BUS.addListener(e-> e.registerLayerDefinition(location,definition));
        *///?}
        /*throw new AssertionError();*/
    }

    public interface FactoryRenderLayerRegistry {
        class_897<?/*? if >=1.21.2 {*//*, ? *//*?}*/> getEntityRenderer(class_1299<? extends class_1309> entityType);
        class_5599 getEntityModelSet();
        <T extends  /*? if >=1.21.2 {*/ /*LivingEntityRenderState, S extends *//*?}*/class_1309,M extends class_583<T>> void register(class_922</*? if >=1.21.2 {*/ /*S, *//*?}*/T, M> renderer, class_3887<T, M> renderLayer);
    }

    public static void registerRenderLayer(Consumer<FactoryRenderLayerRegistry> registry) {
        //? if fabric {
        /*? if >=26.1 {*//*LivingEntityRenderLayerRegistrationCallback*//*?} else {*/LivingEntityFeatureRendererRegistrationCallback/*?}*/.EVENT.register((a, b, c, d)-> registry.accept(new FactoryRenderLayerRegistry() {
            @Override
            public class_897<?/*? if >=1.21.2 {*//*, ? *//*?}*/> getEntityRenderer(class_1299<? extends class_1309> entityType) {
                return b;
            }

            @Override
            public class_5599 getEntityModelSet() {
                return d.method_32170();
            }

            public <T extends  /*? if >=1.21.2 {*/ /*LivingEntityRenderState, S extends *//*?}*/class_1309,M extends class_583<T>> void register(class_922</*? if >=1.21.2 {*/ /*S, *//*?}*/T, M> renderer, class_3887<T, M> renderLayer) {
                c.register(renderLayer);
            }

            }));
         //?} else if (forge && <1.21.6) || neoforge {
        /*FactoryAPIPlatform.getModEventBus().addListener(EventPriority.NORMAL, false, EntityRenderersEvent.AddLayers.class, e-> registry.accept(new FactoryRenderLayerRegistry() {
            @Override
            public EntityRenderer<?/^? if >=1.21.2 {^/, ? /^?}^/> getEntityRenderer(EntityType<? extends LivingEntity> entityType) {
                return e./^? if >=1.20.2 && forge {^/getEntityRenderer/^?} else {^//^getRenderer^//^?}^/(entityType);
            }

            @Override
            public EntityModelSet getEntityModelSet() {
                return e.getEntityModels();
            }

            @Override
            public <T extends  /^? if >=1.21.2 {^/ LivingEntityRenderState, S extends /^?}^/LivingEntity,M extends EntityModel<T>> void register(LivingEntityRenderer</^? if >=1.21.2 {^/ S, /^?}^/T, M> renderer, RenderLayer<T, M> renderLayer) {
                renderer.addLayer(renderLayer);
            }
        }));
        *///?} elif forge && <1.21.9 {
        /*EntityRenderersEvent.AddLayers.getBus(FactoryAPIPlatform.getModEventBus()).addListener(e-> registry.accept(new FactoryRenderLayerRegistry() {
            @Override
            public EntityRenderer<?, ?> getEntityRenderer(EntityType<? extends LivingEntity> entityType) {
                return e.getEntityRenderer(entityType);
            }

            @Override
            public EntityModelSet getEntityModelSet() {
                return e.getEntityModels();
            }

            @Override
            public <T extends LivingEntityRenderState, S extends LivingEntity, M extends EntityModel<T>> void register(LivingEntityRenderer< S, T, M> renderer, RenderLayer<T, M> renderLayer) {
                renderer.addLayer(renderLayer);
            }
        }));
        *///?} elif forge {
        /*EntityRenderersEvent.AddLayers.BUS.addListener(e-> registry.accept(new FactoryRenderLayerRegistry() {
            @Override
            public EntityRenderer<?, ?> getEntityRenderer(EntityType<? extends LivingEntity> entityType) {
                return e.getEntityRenderer(entityType);
            }

            @Override
            public EntityModelSet getEntityModelSet() {
                return e.getEntityModels();
            }

            @Override
            public <T extends LivingEntityRenderState, S extends LivingEntity, M extends EntityModel<T>> void register(LivingEntityRenderer< S, T, M> renderer, RenderLayer<T, M> renderLayer) {
                renderer.addLayer(renderLayer);
            }
        }));
        *///?} else
        /*throw new AssertionError();*/

    }

    public static void handleHelloPayload(HelloPayload payload) {
        playerMods.addAll(payload.modIds());
    }
}

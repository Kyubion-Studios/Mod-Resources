//? if <1.21.2 {
package wily.factoryapi.mixin.base;

import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_2960;
import net.minecraft.class_3956;
import net.minecraft.class_8786;
import net.minecraft.world.item.crafting.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

import java.util.Collection;
import java.util.Map;

@Mixin(class_1863.class)
public interface RecipeManagerAccessor {
    @Invoker("byType")
    <R extends class_1860<?>> /*? if <1.20.5 {*/ Map<class_2960, /*? if >1.20.1 {*/class_8786<R>/*?} else {*//*R*//*?}*/>/*?} else {*//*Collection<RecipeHolder<R>>*//*?}*/ getRecipeByType(class_3956<R> recipeType);
}
//?}
/*
 * Copyright (c) Forge Development LLC and contributors
 * SPDX-License-Identifier: LGPL-2.1-only
 */

package wily.factoryapi.base;

import com.mojang.brigadier.exceptions.CommandSyntaxException;
import com.mojang.datafixers.util.Either;
import com.mojang.serialization.Codec;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.base.network.CommonNetwork;
import wily.factoryapi.util.FactoryItemUtil;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_2487;
import net.minecraft.class_2512;
import net.minecraft.class_6880;
import net.minecraft.class_6885;
import net.minecraft.class_6898;
import net.minecraft.class_7923;
import net.minecraft.class_7924;

/**
 * Ingredient that matches the given items, performing either a {@link StackIngredient#isStrict() strict} or a partial NBT test.
 * <p>
 * Strict NBT ingredients will only match items that have <b>exactly</b> the provided tag, while partial ones will
 * match if the item's tags contain all the elements of the provided one, while allowing for additional elements to exist.
 */
public class StackIngredient extends class_1856 implements FactoryIngredient {
    public static final MapCodec<StackIngredient> CODEC = RecordCodecBuilder.mapCodec(
            builder -> builder.group(
                            class_6898.method_40388(class_7924.field_41197, class_7923.field_41178.method_40294(),false).fieldOf("items").forGetter(StackIngredient::values),
                            /*? if >=1.20.5 {*//*/^? if >1.21.4 {^//^DataComponentExactPredicate^//^?} else {^/DataComponentPredicate/^?}^/*//*?} else {*/class_2487/*?}*/.field_25128.fieldOf(/*? if >=1.20.5 {*//*"components"*//*?} else {*/"nbt"/*?}*/).forGetter(StackIngredient::/*? if >=1.20.5 {*//*components*//*?} else {*/getTag/*?}*/),
                            Codec.BOOL.optionalFieldOf("strict", false).forGetter(StackIngredient::isStrict),
                            Codec.INT.optionalFieldOf("count", 1).forGetter(StackIngredient::getCount))
                    .apply(builder, StackIngredient::new));
    //? if >=1.20.5 {
    /*public static final StreamCodec<RegistryFriendlyByteBuf, StackIngredient> STREAM_CODEC = ByteBufCodecs.fromCodecWithRegistries(CODEC.codec());
    *///?}
    public static final CommonNetwork.Identifier<StackIngredient> ID = CommonNetwork.Identifier.create(FactoryAPI.createModLocation("stack_ingredient"),StackIngredient::decode);
    private final class_6885<class_1792> values;
    //? if >=1.20.5 {
    /*private final /^? if >1.21.4 {^//^DataComponentExactPredicate^//^?} else {^/DataComponentPredicate/^?}^/ components;
    *///?} else {
    private final class_2487 tag;
    //?}
    private final boolean strict;
    protected final class_1799[] stacks;
    private final int count;

    public StackIngredient(class_6885<class_1792> values, /*? if >=1.20.5 {*/ /*/^? if >1.21.4 {^//^DataComponentExactPredicate^//^?} else {^/DataComponentPredicate/^?}^/ components*//*?} else {*/class_2487 tag/*?}*/, boolean strict, int count) {
        super(/*? if <1.21.2 {*/Stream.empty() /*?} else {*//*values*//*?}*/);
        this.values = values;
        //? if >=1.20.5 {
        /*this.components = components;
        *///?} else {
        this.tag = tag;
        //?}
        this.strict = strict;
        this.stacks = values.method_40239().map(i ->{
            class_1799 stack = new class_1799(i, count);
            //? if >=1.20.5 {
            /*stack.applyComponents(components.asPatch());
            *///?} else
            stack.method_7980(tag);
            return stack;
        }).filter(i -> !i.method_7960()).toArray(class_1799[]::new);
        this.count = count;
    }

    @Override
    public boolean method_8093(class_1799 stack) {
        if (strict) {
            for (class_1799 stack2 : this.stacks) {
                if (FactoryItemUtil.equalItems(stack, stack2)) return true;
            }
            return false;
        } else {
            return this.values.method_40241(FactoryItemUtil.getItemHolder(stack)) && /*? if >=1.20.5 {*/ /*this.components.test(stack) *//*?} else {*/ class_2512.method_10687(tag, stack.method_7969(), true) /*?}*/;
        }
    }

    //? if <1.21.2 {

    @Override
    public boolean method_8103() {
        return stacks.length == 0;
    }
    @Override
    public class_1799[] method_8105() {
        return stacks;
    }
    //?}

    public class_6885<class_1792> values() {
        return values;
    }

    public class_1799[] getStacks() {
        return stacks;
    }

    //? if >=1.20.5 {
    /*public /^? if >1.21.4 {^//^DataComponentExactPredicate^//^?} else {^/DataComponentPredicate/^?}^/ components() {
        return components;
    }
    *///?} else {
    public class_2487 getTag(){
        return tag;
    }
    //?}

    public boolean isStrict() {
        return strict;
    }
    /**
     * Creates a new ingredient matching the given item stack and the item stack count
     */
    public static StackIngredient of(boolean strict, class_1799 stack) {
        return of(strict,stack,stack.method_7947());
    }

    /**
     * Creates a new ingredient matching the given item stack
     */
    public static StackIngredient of(boolean strict, class_1799 stack, int count) {
        //? if >=1.20.5 {
        /*return of(strict, stack.getComponents(), count, stack.getItem());
         *///?} else {
        return new StackIngredient(class_6885.method_40246(stack.method_41409()), stack.method_7969(), strict, count);
        //?}
    }
    //? if >=1.20.5 {
    /*/^*
     * Creates a new ingredient matching any item from the list, containing the given components
     ^/
    public static <T> StackIngredient of(boolean strict, DataComponentType<? super T> type, T value, int count, ItemLike... items) {
        return of(strict, /^? if >1.21.4 {^//^DataComponentExactPredicate^//^?} else {^/DataComponentPredicate/^?}^/.builder().expect(type, value).build(), count, items);
    }

    /^*
     * Creates a new ingredient matching any item from the list, containing the given components
     ^/
    public static <T> StackIngredient of(boolean strict, Supplier<? extends DataComponentType<? super T>> type, T value, int count, ItemLike... items) {
        return of(strict, type.get(), value, count, items);
    }

    /^*
     * Creates a new ingredient matching any item from the list, containing the given components
     ^/
    public static StackIngredient of(boolean strict, DataComponentMap map, int count, ItemLike... items) {
        return of(strict, /^? if >1.21.4 {^//^DataComponentExactPredicate^//^?} else {^/DataComponentPredicate/^?}^/.allOf(map), count,items);
    }

    /^*
     * Creates a new ingredient matching any item from the list, containing the given components
     ^/
    @SafeVarargs
    public static StackIngredient of(boolean strict, DataComponentMap map, int count, Holder<Item>... items) {
        return of(strict, /^? if >1.21.4 {^//^DataComponentExactPredicate^//^?} else {^/DataComponentPredicate/^?}^/.allOf(map), count,items);
    }

    /^*
     * Creates a new ingredient matching any item from the list, containing the given components
     ^/
    public static StackIngredient of(boolean strict, DataComponentMap map, HolderSet<Item> items, int count) {
        return of(strict, /^? if >1.21.4 {^//^DataComponentExactPredicate^//^?} else {^/DataComponentPredicate/^?}^/.allOf(map), items, count);
    }

    /^*
     * Creates a new ingredient matching any item from the list, containing the given components
     ^/
    @SafeVarargs
    public static StackIngredient of(boolean strict, /^? if >1.21.4 {^//^DataComponentExactPredicate^//^?} else {^/DataComponentPredicate/^?}^/ predicate, int count, Holder<Item>... items) {
        return of(strict, predicate, HolderSet.direct(items), count);
    }

    /^*
     * Creates a new ingredient matching any item from the list, containing the given components
     ^/
    public static StackIngredient of(boolean strict, /^? if >1.21.4 {^//^DataComponentExactPredicate^//^?} else {^/DataComponentPredicate/^?}^/ predicate, int count, ItemLike... items) {
        return of(strict, predicate, HolderSet.direct(Arrays.stream(items).map(ItemLike::asItem).map(Item::builtInRegistryHolder).toList()), count);
    }

    /^*
     * Creates a new ingredient matching any item from the list, containing the given components
     ^/
    public static StackIngredient of(boolean strict, /^? if >1.21.4 {^//^DataComponentExactPredicate^//^?} else {^/DataComponentPredicate/^?}^/ predicate, HolderSet<Item> items, int count) {
        return new StackIngredient(items, predicate, strict,count);
    }
    *///?}

    @Override
    public int getCount() {
        return count;
    }

    @Override
    public CommonNetwork.Identifier<? extends CommonNetwork.Payload> identifier() {
        return ID;
    }

    @Override
    public void encode(CommonNetwork.PlayBuf buf) {
        //? if <1.20.5 {
        buf.get().method_34062(values.method_40239().toList(),(b,i)->b.method_42065(class_7923.field_41178,i.comp_349()));
        buf.get().method_10794(tag);
        buf.get().method_52964(isStrict());
        buf.get().method_52997(getCount());
        //?} else
        //STREAM_CODEC.encode(buf.get(),this);
    }
    public static StackIngredient decode(CommonNetwork.PlayBuf buf){
        //? if <1.20.5 {
        return new StackIngredient(class_6885.method_40242((List<class_6880<class_1792>>) buf.get().method_34068(ArrayList::new,(b)->b.method_42064(class_7923.field_41178.method_40295()))), buf.get().method_10798(), buf.get().readBoolean(), buf.get().readByte());
        //?} else
        //return STREAM_CODEC.decode(buf.get());
    }
}

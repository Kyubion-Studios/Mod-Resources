package wily.factoryapi.mixin.base;

import com.mojang.authlib.exceptions.AuthenticationException;
import com.mojang.authlib.minecraft.MinecraftSessionService;
import com.mojang.authlib.minecraft.UserApiService;
//? if >=1.20.3 {
import com.mojang.authlib.yggdrasil.ProfileResult;
//?}
import com.mojang.authlib.yggdrasil.YggdrasilAuthenticationService;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wily.factoryapi.FactoryAPIClient;
import wily.factoryapi.base.client.MinecraftAccessor;
import wily.factoryapi.base.client.UIAccessor;

import java.net.Proxy;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_156;
import net.minecraft.class_310;
import net.minecraft.class_320;
import net.minecraft.class_329;
import net.minecraft.class_4008;
import net.minecraft.class_4341;
import net.minecraft.class_437;
import net.minecraft.class_638;
import net.minecraft.class_6628;
import net.minecraft.class_7569;
import net.minecraft.class_7574;
import net.minecraft.class_7578;
import net.minecraft.class_7853;

@Mixin(class_310.class)
public abstract class MinecraftMixin implements MinecraftAccessor {
    @Shadow @Nullable public class_638 level;

    @Shadow @Final public class_329 gui;

    @Mutable
    @Shadow @Final private class_320 user;


    @Mutable
    @Shadow @Final private class_7853 profileKeyPairManager;

    @Mutable
    @Shadow @Final private UserApiService userApiService;

    //? if >=1.20.3 {
    @Mutable
    @Shadow @Final private CompletableFuture<ProfileResult> profileFuture;
    @Mutable
    @Shadow @Final private CompletableFuture<UserApiService.UserProperties> userPropertiesFuture;
    //?}

    //? if <1.21.9 {
    @Shadow @Final private YggdrasilAuthenticationService authenticationService;
    //?} else {
    /*@Shadow @Final private Proxy proxy;
    @Shadow @Final private boolean offlineDeveloperMode;
    *///?}

    @Mutable
    @Shadow @Final private class_6628 telemetryManager;

    @Shadow @Final private static Logger LOGGER;

    @Shadow private class_7574 reportingContext;

    @Mutable
    @Shadow @Final private class_7578 realmsDataFetcher;

    @Shadow @Final private class_4008 splashManager;

    //? if >=26.1 {
    /*@Inject(method = "resizeGui",at = @At("RETURN"))
    public void resizeGui(CallbackInfo ci) {
        if (this.level != null) {
            UIAccessor.of(gui).reloadUI();
            FactoryAPIClient.RESIZE_DISPLAY.invoker.accept(Minecraft.getInstance());
        }
    }
    *///?} else {
    @Inject(method = "resizeDisplay",at = @At("RETURN"))
    public void resizeDisplay(CallbackInfo ci) {
        if (this.level != null) {
            UIAccessor.of(gui).reloadUI();
            FactoryAPIClient.RESIZE_DISPLAY.invoker.accept(class_310.method_1551());
        }
    }
    //?}

    @Inject(method = "setScreen",at = @At("RETURN"))
    public void setScreen(class_437 screen, CallbackInfo ci) {
        if (this.level != null) {
            UIAccessor.of(gui).reloadUI();
        }
    }
    @Inject(method = "stop",at = @At("RETURN"))
    public void stop(CallbackInfo ci) {
        FactoryAPIClient.STOPPING.invoker.accept(class_310.method_1551());
    }

    //? if <1.20.5 {
    @Accessor
    public abstract float getPausePartialTick();
    //?}

    //? if <=1.20.1 {
    /*@Unique boolean gameLoaded = false;
    @Inject(method = "onGameLoadFinished",at = @At("RETURN"))
    public void onGameLoadFinished(CallbackInfo ci) {
      gameLoaded = true;
    }
    *///?}

    @Override
    public boolean hasGameLoaded() {
        return /*? if <=1.20.1 {*//*gameLoaded*//*?} else {*/class_310.method_1551().method_53466()/*?}*/;
    }

    //? if <1.21.2 {
    @Inject(method = "tick",at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;wrapScreenError(Ljava/lang/Runnable;Ljava/lang/String;Ljava/lang/String;)V"))
    public void beforeScreenTick(CallbackInfo ci) {
        if (class_310.method_1551().field_1755 == null) return;
        UIAccessor accessor = UIAccessor.of(class_310.method_1551().field_1755);
        class_437.method_25412(accessor::beforeTick, "Ticking screen before tick", class_310.method_1551().field_1755.getClass().getCanonicalName());
    }

    @Inject(method = "tick",at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;wrapScreenError(Ljava/lang/Runnable;Ljava/lang/String;Ljava/lang/String;)V", shift = At.Shift.AFTER))
    public void afterScreenTick(CallbackInfo ci) {
        if (class_310.method_1551().field_1755 == null) return;
        UIAccessor accessor = UIAccessor.of(class_310.method_1551().field_1755);
        class_437.method_25412(accessor::afterTick, "Ticking screen after tick", class_310.method_1551().field_1755.getClass().getCanonicalName());
    }
    //?} else {
    /*@Inject(method = "tick",at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;tick()V"))
    public void beforeScreenTick(CallbackInfo ci) {
        if (FactoryAPIClient.getScreen() != null) UIAccessor.of(FactoryAPIClient.getScreen()).beforeTick();
    }

    @Inject(method = "tick",at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/screens/Screen;tick()V", shift = At.Shift.AFTER))
    public void afterScreenTick(CallbackInfo ci) {
        if (FactoryAPIClient.getScreen() != null) UIAccessor.of(FactoryAPIClient.getScreen()).afterTick();
    }
    *///?}

    @Override
    public boolean setUser(class_320 user) {
        if (user == null) {
            LOGGER.warn("Something went wrong, the User cannot be set to null");
            return false;
        }
        this.user = splashManager.field_18934 = user;
        //? if >=1.21.9 {
        /*MinecraftSessionService session = Minecraft.getInstance().services().sessionService();
        YggdrasilAuthenticationService authenticationService = this.offlineDeveloperMode
                ? YggdrasilAuthenticationService.createOffline(this.proxy)
                : new YggdrasilAuthenticationService(this.proxy);
        *///?} else {
        MinecraftSessionService session = class_310.method_1551().method_1495();
        boolean offlineDeveloperMode = user.method_35718() != class_320.class_321.field_34962;
        //?}
        //? if >=1.20.3 {
        this.profileFuture = CompletableFuture.supplyAsync(() -> session.fetchProfile(user.method_44717(), true), class_156.method_55473());
        this.userApiService = offlineDeveloperMode ? UserApiService.OFFLINE : authenticationService.createUserApiService(user.method_1674());
        this.userPropertiesFuture = CompletableFuture.supplyAsync(() -> {
            try {
                return userApiService.fetchProperties();
            } catch (AuthenticationException var2) {
                LOGGER.error("Failed to fetch user properties", var2);
                return UserApiService.OFFLINE_PROPERTIES;
            }
        }, class_156.method_55473());
        //?} else {
        /*try {
            this.userApiService = authenticationService.createUserApiService(user.getAccessToken());
        } catch (AuthenticationException var4) {
            AuthenticationException authenticationException = var4;
            LOGGER.error("Failed to verify authentication", authenticationException);
            this.userApiService = UserApiService.OFFLINE;
        }
        *///?}
        this.profileKeyPairManager = class_7853.method_46532(userApiService, user, class_310.method_1551().field_1697.toPath());
        this.telemetryManager = new class_6628(class_310.method_1551(), userApiService, user);
        this.reportingContext = class_7574.method_44599(class_7569.method_44586(), userApiService);
        this.realmsDataFetcher = new class_7578(/*? if >1.21.4 {*//*RealmsClient.getOrCreate()*//*?} else {*/class_4341.method_20989(class_310.method_1551())/*?}*/);
        //? if >=1.20.3
        RealmsAvailabilityAccessor.setFuture(null);
        return true;
    }
}

package wily.factoryapi.base.network;

import com.mojang.serialization.Dynamic;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIPlatform;
import wily.factoryapi.base.config.FactoryConfig;

import java.util.Map;
import java.util.function.Supplier;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_3222;

public record CommonConfigSyncPayload(CommonNetwork.Identifier<CommonConfigSyncPayload> identifier, net.minecraft.class_2960 commonConfigStorage, class_2487 configTag) implements CommonNetwork.Payload {
    public static final CommonNetwork.Identifier<CommonConfigSyncPayload> ID_S2C = CommonNetwork.Identifier.create(FactoryAPI.createModLocation("common_config_sync_s2c"),CommonConfigSyncPayload::createS2C);
    public static final CommonNetwork.Identifier<CommonConfigSyncPayload> ID_C2S = CommonNetwork.Identifier.create(FactoryAPI.createModLocation("common_config_sync_c2s"),CommonConfigSyncPayload::createC2S);

    public static CommonConfigSyncPayload of(CommonNetwork.Identifier<CommonConfigSyncPayload> identifier, FactoryConfig.StorageHandler handler) {
        return new CommonConfigSyncPayload(identifier, FactoryConfig.COMMON_STORAGES.getKey(handler), (class_2487)handler.encodeConfigs(class_2509.field_11560));
    }

    public static CommonConfigSyncPayload of(CommonNetwork.Identifier<CommonConfigSyncPayload> identifier, FactoryConfig.StorageHandler handler, FactoryConfig<?> config) {
        return new CommonConfigSyncPayload(identifier, FactoryConfig.COMMON_STORAGES.getKey(handler), (class_2487)handler.encodeConfigs(Map.of(config.getKey(), config), class_2509.field_11560));
    }

    public CommonConfigSyncPayload(CommonNetwork.Identifier<CommonConfigSyncPayload> identifier, CommonNetwork.PlayBuf playBuf) {
        this(identifier, playBuf.get().method_10810(), playBuf.get().method_10798());
    }

    public static CommonConfigSyncPayload createS2C(CommonNetwork.PlayBuf playBuf) {
        return new CommonConfigSyncPayload(ID_S2C, playBuf);
    }

    public static CommonConfigSyncPayload createC2S(CommonNetwork.PlayBuf playBuf) {
        return new CommonConfigSyncPayload(ID_C2S, playBuf);
    }

    @Override
    public void apply(Context context) {
        FactoryConfig.StorageHandler handler = FactoryConfig.COMMON_STORAGES.get(commonConfigStorage);
        if (handler == null) return;
        handler.decodeConfigs(new Dynamic<>(class_2509.field_11560, configTag));
        if (!context.isClient() && context.player() instanceof class_3222 sp && sp/*? if >=1.21.11 {*//*.permissions().hasPermission*//*?} else {*/.method_5687/*?}*/(/*? if >=1.21.11 {*//*new Permission.HasCommandLevel(PermissionLevel.GAMEMASTERS)*//*?} else {*/2/*?}*/)){
            CommonNetwork.sendToPlayers(FactoryAPIPlatform.getEntityServer(sp).method_3760().method_14571(), new CommonConfigSyncPayload(ID_S2C, commonConfigStorage, configTag));
            handler.save();
        }
    }

    @Override
    public void encode(CommonNetwork.PlayBuf playBuf) {
        playBuf.get().method_10812(commonConfigStorage);
        playBuf.get().method_10794(configTag);
    }

}

//? if fabric {
package wily.factoryapi.mixin.base.fabric;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3558;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import wily.factoryapi.base.IFactoryBlock;

@Mixin(class_3558.class)
public class LightEngineMixin {
    //? if <1.21.2 {
    @Inject(method = ("hasDifferentLightProperties"), at = @At("RETURN"), cancellable = true)
    private static void injectLuminance(class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_2680 blockState2, CallbackInfoReturnable<Boolean> info){
        if (blockState.method_26204() instanceof IFactoryBlock || blockState2.method_26204() instanceof IFactoryBlock){
            info.setReturnValue(info.getReturnValue() || IFactoryBlock.getBlockLuminance(blockState2,blockGetter,blockPos) != IFactoryBlock.getBlockLuminance(blockState,blockGetter,blockPos));
        }
    }
    //?}
}
//?}
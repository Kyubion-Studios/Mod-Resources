package wily.factoryapi.base;

import wily.factoryapi.init.FactoryRegistries;

//? if <1.20.5
import static net.minecraft.class_1747.field_30849;

import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2487;

public class SimpleItemCraftyStorage implements ICraftyEnergyStorage {
    private static final String KEY = "energy";

    private int capacity;
    private final int maxOutput;

    private final int maxInput;

    class_1799 container;
    TransportState transportState;
    final boolean isBlockItem;

    public final FactoryCapacityTier supportableTier;

    public FactoryCapacityTier storedTier = FactoryCapacityTier.BASIC;
    public SimpleItemCraftyStorage(class_1799 stack, int initialEnergy, int capacity, int maxOutput, int maxInput, TransportState transportState, FactoryCapacityTier supportableTier, boolean isBlockItem){
        this.supportableTier = supportableTier;
        this.isBlockItem = isBlockItem;
        this.capacity = capacity;
        this.container = stack;
        //? if <1.20.5 {
        class_2487 tag = stack.method_7948();
        if (isBlockItem) tag = tag.method_10562(field_30849);
        if (tag.method_10562("CYEnergy").method_33133()){
            class_2487 storage = new class_2487();
            storage.method_10569(KEY,initialEnergy);
            storage.method_10569("supportedTier",supportableTier.ordinal());
            storage.method_10569("tier",storedTier.ordinal());
            tag.method_10566("CYEnergy", storage);
            if (isBlockItem) stack.method_7948().method_10566(field_30849, tag);
        }
        //?}
        this.transportState = transportState;
        this.maxOutput = maxOutput;
        this.maxInput = maxInput;
    }
    public SimpleItemCraftyStorage(class_1799 stack, int capacity, TransportState transportState, FactoryCapacityTier supportableTier){
        this(stack,0,capacity,capacity,capacity, transportState,supportableTier,stack.method_7909() instanceof class_1747);
    }
    //? if <1.20.5 {
    private class_2487 getEnergyCompound(){
        class_2487 tag = container.method_7948();
        if (isBlockItem) tag = tag.method_10562(field_30849);
        return tag.method_10562("CYEnergy");
    }
    //?}
    @Override
    public CraftyTransaction receiveEnergy(CraftyTransaction transaction, boolean simulate) {
        if (transaction.isEmpty()) return  CraftyTransaction.EMPTY;
        int energyReceived = Math.min(getMaxReceive(), transaction.energy);
        int energy = getEnergyStored();
        if (!simulate) {
            if (supportableTier.supportTier(transaction.tier)) setStoredTier(transaction.tier);
            else {
                return CraftyTransaction.EMPTY;
            }
            energy += energyReceived;
            setEnergyStored(energy);

        }

        return new CraftyTransaction(energyReceived, transaction.tier);
    }

    public CraftyTransaction consumeEnergy(CraftyTransaction transaction, boolean simulate) {
        if (transaction.isEmpty()) return  CraftyTransaction.EMPTY;
        int energy = getEnergyStored();
        int energyExtracted = Math.min(energy, Math.min(getMaxConsume(), transaction.energy));

        if (!simulate) {
            if (!storedTier.supportTier(transaction.tier)) energyExtracted = storedTier.convertEnergyTo(energyExtracted,transaction.tier);
            energy -= energyExtracted;
            setEnergyStored(energy);
        }

        return new CraftyTransaction(energyExtracted, transaction.tier);
    }

    @Override
    public FactoryCapacityTier getSupportedTier() {
        return /*? if <1.20.5 {*/ FactoryCapacityTier.values()[getEnergyCompound().method_10550("tier")]/*?} else {*/ /*container.getOrDefault(FactoryRegistries.ENERGY_TIER_COMPONENT.get(), supportableTier)*//*?}*/;
    }

    @Override
    public FactoryCapacityTier getStoredTier() {
        return /*? if <1.20.5 {*/ FactoryCapacityTier.values()[getEnergyCompound().method_10550("tier")]/*?} else {*/ /*container.getOrDefault(FactoryRegistries.STORED_ENERGY_TIER_COMPONENT.get(), FactoryCapacityTier.BASIC)*//*?}*/;
    }

    @Override
    public int getEnergyStored() {
        return /*? if <1.20.5 {*/ getEnergyCompound().method_10550(KEY)/*?} else {*/ /*container.getOrDefault(FactoryRegistries.ENERGY_COMPONENT.get(), 0)*//*?}*/;
    }

    public void setEnergyStored(int energy) {
        //? if <1.20.5 {
        class_2487 tag = getEnergyCompound();
        tag.method_10569(KEY,energy);
        //?} else {
        /*container.set(FactoryRegistries.ENERGY_COMPONENT.get(),energy);
        *///?}
    }

    public void setStoredTier(FactoryCapacityTier tier){
        //? if <1.20.5 {
        class_2487 tag = getEnergyCompound();
        tag.method_10569("tier",tier.ordinal());
        //?} else {
        /*container.set(FactoryRegistries.STORED_ENERGY_TIER_COMPONENT.get(),tier);
        *///?}
    }

    @Override
    public void setSupportedTier(FactoryCapacityTier tier) {
        //? if <1.20.5 {
        class_2487 tag = getEnergyCompound();
        tag.method_10569("supportedTier",tier.ordinal());
        //?} else {
        /*container.set(FactoryRegistries.ENERGY_TIER_COMPONENT.get(),tier);
        *///?}
    }

    @Override
    public int getMaxEnergyStored() {
        return capacity;
    }


    @Override
    public class_2487 serializeTag() {
        return /*? if <1.20.5 {*/ getEnergyCompound()/*?} else {*/ /*new CompoundTag()*//*?}*/;
    }

    @Override
    public void deserializeTag(class_2487 nbt) {
        //? if <1.20.5
        this.container.method_7980(nbt);
    }


    public int getMaxConsume(){
        return Math.min(getEnergyStored(),maxOutput);
    }

    @Override
    public int getMaxReceive() {
        return Math.min(getEnergySpace(),maxInput);
    }

    @Override
    public TransportState getTransport() {
        return transportState;
    }
}

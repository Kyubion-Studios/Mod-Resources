package wily.factoryapi.mixin.base;

import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import wily.factoryapi.base.FactoryIngredient;
import wily.factoryapi.base.network.CommonNetwork;

import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;
import net.minecraft.class_1799;
import net.minecraft.class_1856;

@Mixin(class_1856.class)
public abstract class IngredientMixin implements FactoryIngredient {
    //? if >=1.21.2 {

    /*@Mutable
    @Shadow @Final public static StreamCodec<RegistryFriendlyByteBuf, Optional<Ingredient>> OPTIONAL_CONTENTS_STREAM_CODEC;
    @Unique
    private ItemStack[] stacks;
    *///?} else
    @Shadow public abstract class_1799[] getItems();

    @Override
    public CommonNetwork.Identifier<? extends CommonNetwork.Payload> identifier() {
        return FactoryIngredient.DEFAULT_ID;
    }

    @Unique
    private class_1856 self(){
        return (class_1856) (Object) this;
    }

    @Override
    public class_1799[] getStacks() {
        //? if >=1.21.2 {
        /*return stacks == null ? stacks = self().items()/^? if <1.21.4 {^/.stream()/^?}^/.map(ItemStack::new).toArray(ItemStack[]::new) : stacks;
        *///?} else
        return getItems();
    }

    @Override
    public void encode(CommonNetwork.PlayBuf buf) {
        //? if >=1.20.5 {
        /*Ingredient.CONTENTS_STREAM_CODEC.encode(buf.get(),(Ingredient) (Object) this);
        *///?} else
        ((class_1856)(Object) this).method_8088(buf.get());
    }

    @Override
    public int getCount() {
        return 1;
    }

    //? if >=1.21.2 && forge {
    /*@Redirect(method = "<clinit>", at = @At(value = "FIELD", target = "Lnet/minecraft/world/item/crafting/Ingredient;OPTIONAL_CONTENTS_STREAM_CODEC:Lnet/minecraft/network/codec/StreamCodec;"))
    private static void fixOptionalIngredientStreamCodec(StreamCodec<RegistryFriendlyByteBuf, Optional<Ingredient>> value){
        OPTIONAL_CONTENTS_STREAM_CODEC = StreamCodec.of((b, o)-> b.writeOptional(o,(b1,i)->Ingredient.CONTENTS_STREAM_CODEC.encode(b,i)), b-> b.readOptional(b1->Ingredient.CONTENTS_STREAM_CODEC.decode(b)));
    }
    *///?}
}

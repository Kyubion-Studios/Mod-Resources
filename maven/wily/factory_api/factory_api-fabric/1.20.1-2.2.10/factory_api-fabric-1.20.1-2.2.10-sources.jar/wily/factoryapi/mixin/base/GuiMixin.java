package wily.factoryapi.mixin.base;

import com.llamalad7.mixinextras.injector.wrapoperation.Operation;
import com.llamalad7.mixinextras.injector.wrapoperation.WrapOperation;
import com.llamalad7.mixinextras.sugar.Share;
import com.llamalad7.mixinextras.sugar.ref.LocalRef;
import org.jetbrains.annotations.Nullable;
import org.objectweb.asm.Opcodes;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.Redirect;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wily.factoryapi.base.ArbitrarySupplier;
import wily.factoryapi.base.Bearer;
import wily.factoryapi.base.client.GuiAccessor;
import wily.factoryapi.base.client.UIAccessor;
import wily.factoryapi.base.client.UIDefinition;
import wily.factoryapi.util.FactoryGuiElement;
import wily.factoryapi.util.VariablesMap;
//? if >=1.21 {
/*import net.minecraft.client.DeltaTracker;
*///?}

import java.util.*;
import net.minecraft.class_1297;
import net.minecraft.class_1316;
import net.minecraft.class_1799;
import net.minecraft.class_2561;
import net.minecraft.class_266;
import net.minecraft.class_329;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_365;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_5244;

@Mixin(/*? if <26.2 {*/class_329/*?} else {*//*Hud*//*?}*/.class)
public abstract class GuiMixin implements UIAccessor, GuiAccessor {
    @Shadow private int overlayMessageTime;

    @Shadow @Nullable private class_2561 overlayMessageString;

    @Unique private final List<class_4068> renderables = new ArrayList<>();
    @Unique private final VariablesMap<String, ArbitrarySupplier<?>> elements = new VariablesMap<>();
    @Unique private final List<UIDefinition> definitions = new ArrayList<>();
    @Unique private final List<UIDefinition> staticDefinitions = new ArrayList<>();
    @Override
    public @Nullable class_437 getScreen() {
        return null;
    }

    @Override
    public boolean initialized() {
        return true;
    }

    @Override
    public List<UIDefinition> getDefinitions() {
        return definitions;
    }

    @Override
    public List<UIDefinition> getStaticDefinitions() {
        return staticDefinitions;
    }

    @Override
    public List<class_364> getChildren() {
        return Collections.emptyList();
    }

    @Override
    public List<class_4068> getChildrenRenderables() {
        return renderables;
    }

    @Override
    public <T extends class_364> T removeChild(T listener) {
        if (listener instanceof class_4068 r) renderables.remove(r);
        return listener;
    }

    @Override
    public <T extends class_364> T addChild(int renderableIndex, T listener, boolean isRenderable, boolean isNarratable) {
        if (listener instanceof class_4068 r) addRenderable(renderableIndex,r);
        return listener;
    }

    @Override
    public void beforeInit(UIAccessor accessor) {
        UIAccessor.super.beforeInit(accessor);
        putSupplierComponent("overlayMessage.component", ()->overlayMessageString == null ? class_5244.field_39003 : overlayMessageString);
        getElements().put("overlayMessage.time", Bearer.of(()->overlayMessageTime, i-> overlayMessageTime = i));
    }

    @Override
    public VariablesMap<String, ArbitrarySupplier<?>> getElements() {
        return elements;
    }

    @Inject(method = "tick()V", at = @At("HEAD"))
    public void beforeTick(CallbackInfo ci) {
        beforeTick();
    }

    @Inject(method = "tick()V", at = @At("RETURN"))
    public void afterTick(CallbackInfo ci) {
        afterTick();
    }

    //? if >=26.1 {
    /*@Inject(method = "extractVignette", at = @At("HEAD"), cancellable = true)
    public void renderVignette(GuiGraphicsExtractor guiGraphics, Entity entity, CallbackInfo ci) {
        FactoryGuiElement.VIGNETTE.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = "extractVignette", at = @At("RETURN"))
    public void renderVignetteReturn(GuiGraphicsExtractor guiGraphics, Entity entity, CallbackInfo ci) {
        FactoryGuiElement.VIGNETTE.finalizeMixin(guiGraphics, this);
    }

    @Inject(method = "extractCrosshair", at = @At("HEAD"), cancellable = true)
    public void extractCrosshair(GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        FactoryGuiElement.CROSSHAIR.prepareMixin(guiGraphics, this, ci);
    }
    @Inject(method = "extractCrosshair", at = @At("RETURN"))
    public void extractCrosshairReturn(GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        FactoryGuiElement.CROSSHAIR.finalizeMixin(guiGraphics, this);
    }

    @Inject(method = "extractEffects", at = @At("HEAD"), cancellable = true)
    public void extractEffects(GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        FactoryGuiElement.EFFECTS.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = "extractEffects", at = @At("RETURN"))
    public void extractEffectsReturn(GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        FactoryGuiElement.EFFECTS.finalizeMixin(guiGraphics, this);
    }

    @Inject(method = "extractItemHotbar", at = @At("HEAD"), cancellable = true)
    public void extractItemHotbar(GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        FactoryGuiElement.HOTBAR.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = "extractItemHotbar", at = @At("RETURN"))
    public void extractItemHotbarReturn(GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        FactoryGuiElement.HOTBAR.finalizeMixin(guiGraphics, this);
    }

    @Inject(method = "displayScoreboardSidebar", at = @At("HEAD"), cancellable = true)
    private void displayScoreboardSidebar(GuiGraphicsExtractor guiGraphics, Objective objective, CallbackInfo ci) {
        FactoryGuiElement.SCOREBOARD.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = "displayScoreboardSidebar", at = @At("RETURN"))
    private void displayScoreboardSidebarReturn(GuiGraphicsExtractor guiGraphics, Objective objective, CallbackInfo ci) {
        FactoryGuiElement.SCOREBOARD.finalizeMixin(guiGraphics, this);
    }

    @Inject(method = "extractPlayerHealth", at = @At("HEAD"), cancellable = true)
    public void extractHealth(GuiGraphicsExtractor guiGraphics, CallbackInfo ci) {
        FactoryGuiElement.PLAYER_HEALTH.prepareMixin(guiGraphics, this, ci);
    }
    @Inject(method = "extractPlayerHealth", at = @At("RETURN"))
    public void extractHealthReturn(GuiGraphicsExtractor guiGraphics, CallbackInfo ci) {
        FactoryGuiElement.PLAYER_HEALTH.finalizeMixin(guiGraphics, this);
    }
    @Inject(method = "extractVehicleHealth", at = @At("HEAD"), cancellable = true)
    public void extractVehicleHealth(GuiGraphicsExtractor guiGraphics, CallbackInfo ci) {
        FactoryGuiElement.VEHICLE_HEALTH.prepareMixin(guiGraphics, this, ci);
    }
    @Inject(method = "extractVehicleHealth", at = @At("RETURN"))
    public void extractVehicleHealthReturn(GuiGraphicsExtractor guiGraphics, CallbackInfo ci) {
        FactoryGuiElement.VEHICLE_HEALTH.finalizeMixin(guiGraphics, this);
    }
    *///?} else {
    @Inject(method = "renderVignette", at = @At("HEAD"), cancellable = true)
    public void renderVignette(class_332 guiGraphics, class_1297 entity, CallbackInfo ci) {
        FactoryGuiElement.VIGNETTE.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = "renderVignette", at = @At("RETURN"))
    public void renderVignetteReturn(class_332 guiGraphics, class_1297 entity, CallbackInfo ci) {
        FactoryGuiElement.VIGNETTE.finalizeMixin(guiGraphics, this);
    }

    @Inject(method = "renderCrosshair", at = @At("HEAD"), cancellable = true)
    public void renderCrosshair(class_332 guiGraphics/*? if >=1.21 {*//*, DeltaTracker deltaTracker*//*?}*/, CallbackInfo ci) {
        FactoryGuiElement.CROSSHAIR.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = "renderCrosshair", at = @At("RETURN"))
    public void renderCrosshairReturn(class_332 guiGraphics/*? if >=1.21 {*//*, DeltaTracker deltaTracker*//*?}*/, CallbackInfo ci) {
        FactoryGuiElement.CROSSHAIR.finalizeMixin(guiGraphics, this);
    }

    @Inject(method = "renderEffects", at = @At("HEAD"), cancellable = true)
    public void renderEffects(class_332 guiGraphics/*? if >=1.21 {*//*, DeltaTracker deltaTracker*//*?}*/, CallbackInfo ci) {
        FactoryGuiElement.EFFECTS.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = "renderEffects", at = @At("RETURN"))
    public void renderEffectsReturn(class_332 guiGraphics/*? if >=1.21 {*//*, DeltaTracker deltaTracker*//*?}*/, CallbackInfo ci) {
        FactoryGuiElement.EFFECTS.finalizeMixin(guiGraphics, this);
    }

    @Inject(method = /*? if >=1.20.5 {*//*"renderItemHotbar"*//*?} else {*/"renderHotbar"/*?}*/, at = @At("HEAD"), cancellable = true)
    public void renderHotbar(/*? if <1.20.5 {*/float f, /*?}*/class_332 guiGraphics/*? if >=1.20.5 {*//*, DeltaTracker deltaTracker*//*?}*/, CallbackInfo ci) {
        FactoryGuiElement.HOTBAR.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = /*? if >=1.20.5 {*//*"renderItemHotbar"*//*?} else {*/"renderHotbar"/*?}*/, at = @At("RETURN"))
    public void renderHotbarReturn(/*? if <1.20.5 {*/float f, /*?}*/class_332 guiGraphics/*? if >=1.21 {*//*, DeltaTracker deltaTracker*//*?}*/, CallbackInfo ci) {
        FactoryGuiElement.HOTBAR.finalizeMixin(guiGraphics, this);
    }

    @Inject(method = "displayScoreboardSidebar", at = @At("HEAD"), cancellable = true)
    private void displayScoreboardSidebar(class_332 guiGraphics, class_266 objective, CallbackInfo ci) {
        FactoryGuiElement.SCOREBOARD.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = "displayScoreboardSidebar", at = @At("RETURN"))
    private void displayScoreboardSidebarReturn(class_332 guiGraphics, class_266 objective, CallbackInfo ci) {
        FactoryGuiElement.SCOREBOARD.finalizeMixin(guiGraphics, this);
    }

    @Inject(method = "renderPlayerHealth", at = @At("HEAD"), cancellable = true)
    public void renderHealth(class_332 guiGraphics, CallbackInfo ci) {
        FactoryGuiElement.PLAYER_HEALTH.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = "renderPlayerHealth", at = @At("RETURN"))
    public void renderHealthReturn(class_332 guiGraphics, CallbackInfo ci) {
        FactoryGuiElement.PLAYER_HEALTH.finalizeMixin(guiGraphics, this);
    }

    @Inject(method = "renderVehicleHealth", at = @At("HEAD"), cancellable = true)
    public void renderVehicleHealth(class_332 guiGraphics, CallbackInfo ci) {
        FactoryGuiElement.VEHICLE_HEALTH.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = "renderVehicleHealth", at = @At("RETURN"))
    public void renderVehicleHealthReturn(class_332 guiGraphics, CallbackInfo ci) {
        FactoryGuiElement.VEHICLE_HEALTH.finalizeMixin(guiGraphics, this);
    }
    //?}

    //? if >=26.1 {
    /*@Inject(method = "extractOverlayMessage", at = @At(value = "HEAD"), cancellable = true)
    public void renderOverlayMessage(GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        FactoryGuiElement.OVERLAY_MESSAGE.prepareMixin(guiGraphics, this, ci);
    }
    @Inject(method = "extractOverlayMessage", at = @At(value = "RETURN"))
    public void renderOverlayMessageReturn(GuiGraphicsExtractor guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        FactoryGuiElement.OVERLAY_MESSAGE.finalizeMixin(guiGraphics, this);
    }
    *///?} else if >=1.20.5 {
    /*@Inject(method = "renderOverlayMessage", at = @At(value = "HEAD"), cancellable = true)
    public void renderOverlayMessage(GuiGraphics guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        FactoryGuiElement.OVERLAY_MESSAGE.prepareMixin(guiGraphics, this, ci);
    }
    @Inject(method = "renderOverlayMessage", at = @At(value = "RETURN"))
    public void renderOverlayMessageReturn(GuiGraphics guiGraphics, DeltaTracker deltaTracker, CallbackInfo ci) {
        FactoryGuiElement.OVERLAY_MESSAGE.finalizeMixin(guiGraphics, this);
    }
    *///?} else if fabric {

    @Redirect(method = "render", at = @At(value = "FIELD", target = "Lnet/minecraft/client/gui/Gui;overlayMessageTime:I", ordinal = 0, opcode = Opcodes.GETFIELD))
    public int renderOverlayMessage(class_329 instance) {
        if (!FactoryGuiElement.OVERLAY_MESSAGE.isVisible(this)) return 0;
        return overlayMessageTime;
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;pushPose()V", ordinal = 0))
    public void renderOverlayMessage(class_332 guiGraphics, float f, CallbackInfo ci) {
        if (FactoryGuiElement.OVERLAY_MESSAGE.isVisible(this)) FactoryGuiElement.OVERLAY_MESSAGE.prepareRender(guiGraphics, this);
    }

    @Inject(method = "render", at = @At(value = "INVOKE", target = "Lcom/mojang/blaze3d/vertex/PoseStack;popPose()V", ordinal = 0, shift = At.Shift.AFTER))
    public void renderOverlayMessageReturn(class_332 guiGraphics, float f, CallbackInfo ci) {
        FactoryGuiElement.OVERLAY_MESSAGE.finalizeMixin(guiGraphics, this);
    }
    //?}
    //? if >=1.20.5 && neoforge && <26.1 {
    /*@Inject(method = {"renderHealthLevel","renderArmorLevel","renderFoodLevel","renderAirLevel"}, at = @At("HEAD"), cancellable = true, remap = false)
    public void renderNeoForgeHealth(GuiGraphics guiGraphics, CallbackInfo ci) {
       FactoryGuiElement.PLAYER_HEALTH.prepareMixin(guiGraphics, this, ci);
    }
    @Inject(method = {"renderHealthLevel","renderArmorLevel","renderFoodLevel","renderAirLevel"}, at = @At("RETURN"), remap = false)
    public void renderNeoForgeHealthReturn(GuiGraphics guiGraphics, CallbackInfo ci) {
        FactoryGuiElement.PLAYER_HEALTH.finalizeMixin(guiGraphics, this);
    }
    *///?}
    //? if >=26.1 && neoforge {
    /*@Inject(method = {"extractHealthLevel","extractArmorLevel","extractFoodLevel","extractAirLevel"}, at = @At("HEAD"), cancellable = true, remap = false)
    public void extractNeoForgeHealth(GuiGraphicsExtractor guiGraphics, CallbackInfo ci) {
        FactoryGuiElement.PLAYER_HEALTH.prepareMixin(guiGraphics, this, ci);
    }
    @Inject(method = {"extractHealthLevel","extractArmorLevel","extractFoodLevel","extractAirLevel"}, at = @At("RETURN"), remap = false)
    public void extractNeoForgeHealthReturn(GuiGraphicsExtractor guiGraphics, CallbackInfo ci) {
        FactoryGuiElement.PLAYER_HEALTH.finalizeMixin(guiGraphics, this);
    }
    *///?}

    //? if >=1.21.6 {
    /*//? if !neoforge {
    @WrapOperation(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/contextualbar/" + /^? if <26.2 {^/"ContextualBarRenderer"/^?} else {^//^"ContextualBar"^//^?}^/ + ";extractBackground(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/DeltaTracker;)V"))
    public void renderExperienceBar(/^? if <26.2 {^/ContextualBarRenderer/^?} else {^//^ContextualBar^//^?}^/ instance, net.minecraft.client.gui.GuiGraphics graphics, DeltaTracker deltaTracker, Operation<Void> original, @Share("cli") LocalRef<CallbackInfo> ci, @Share("fge") LocalRef<FactoryGuiElement> elementLocalRef) {
        ci.set(new CallbackInfo("renderContextualBar", true));
        elementLocalRef.set(switch (instance) {
            case /^? if <26.2 {^/ExperienceBarRenderer/^?} else {^//^ExperienceBar^//^?}^/ ignored -> FactoryGuiElement.EXPERIENCE_BAR;
            case /^? if <26.2 {^/LocatorBarRenderer/^?} else {^//^LocatorBar^//^?}^/ ignored -> FactoryGuiElement.LOCATOR_BAR;
            case /^? if <26.2 {^/JumpableVehicleBarRenderer/^?} else {^//^JumpableVehicleBar^//^?}^/ ignored -> FactoryGuiElement.JUMP_METER;
            default -> null;
        });
        FactoryGuiElement factoryGuiElement = elementLocalRef.get();
        if (factoryGuiElement != null) factoryGuiElement.prepareMixin(graphics, this, ci.get());
        if (!ci.get().isCancelled()) original.call(instance, graphics, deltaTracker);
    }

    @WrapOperation(method = "renderHotbarAndDecorations", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/contextualbar/" + /^? if <26.2 {^/"ContextualBarRenderer"/^?} else {^//^"ContextualBar"^//^?}^/ + ";extractRenderState(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/DeltaTracker;)V"))
    public void renderExperienceBarReturn(/^? if <26.2 {^/ContextualBarRenderer/^?} else {^//^ContextualBar^//^?}^/ instance, net.minecraft.client.gui.GuiGraphics graphics, DeltaTracker deltaTracker, Operation<Void> original, @Share("cli") LocalRef<CallbackInfo> ci, @Share("fge") LocalRef<FactoryGuiElement> elementLocalRef) {
        if (!ci.get().isCancelled()) original.call(instance, graphics, deltaTracker);
        FactoryGuiElement factoryGuiElement = elementLocalRef.get();
        if (factoryGuiElement != null) factoryGuiElement.finalizeMixin(graphics, this);
    }
    //?} else {
    /^// Thank you so much /s
    @Unique
    final ThreadLocal<CallbackInfo> ci = new ThreadLocal<>();
    @Unique
    final ThreadLocal<FactoryGuiElement> fge = new ThreadLocal<>();
    @WrapOperation(method = "renderContextualInfoBarBackground", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/contextualbar/" + /^¹? if <26.2 {¹^/"ContextualBarRenderer"/^¹?} else {¹^//^¹"ContextualBar"¹^//^¹?}¹^/ + ";extractBackground(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/DeltaTracker;)V"))
    public void renderExperienceBar(/^¹? if <26.2 {¹^/ContextualBarRenderer/^¹?} else {¹^//^¹ContextualBar¹^//^¹?}¹^/ instance, net.minecraft.client.gui.GuiGraphics graphics, DeltaTracker deltaTracker, Operation<Void> original) {
        ci.set(new CallbackInfo("renderContextualBar", true));
        fge.set(switch (instance) {
            case /^¹? if <26.2 {¹^/ExperienceBarRenderer/^¹?} else {¹^//^¹ExperienceBar¹^//^¹?}¹^/ ignored -> FactoryGuiElement.EXPERIENCE_BAR;
            case /^¹? if <26.2 {¹^/LocatorBarRenderer/^¹?} else {¹^//^¹LocatorBar¹^//^¹?}¹^/ ignored -> FactoryGuiElement.LOCATOR_BAR;
            case /^¹? if <26.2 {¹^/JumpableVehicleBarRenderer/^¹?} else {¹^//^¹JumpableVehicleBar¹^//^¹?}¹^/ ignored -> FactoryGuiElement.JUMP_METER;
            default -> null;
        });
        FactoryGuiElement factoryGuiElement = fge.get();
        if (factoryGuiElement != null) factoryGuiElement.prepareMixin(graphics, this, ci.get());
        if (!ci.get().isCancelled()) original.call(instance, graphics, deltaTracker);
    }

    @WrapOperation(method = "renderContextualInfoBar", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/contextualbar/" + /^¹? if <26.2 {¹^/"ContextualBarRenderer"/^¹?} else {¹^//^¹"ContextualBar"¹^//^¹?}¹^/ + ";extractRenderState(Lnet/minecraft/client/gui/GuiGraphics;Lnet/minecraft/client/DeltaTracker;)V"))
    public void renderExperienceBarReturn(/^¹? if <26.2 {¹^/ContextualBarRenderer/^¹?} else {¹^//^¹ContextualBar¹^//^¹?}¹^/ instance, net.minecraft.client.gui.GuiGraphics graphics, DeltaTracker deltaTracker, Operation<Void> original) {
        if (!ci.get().isCancelled()) original.call(instance, graphics, deltaTracker);
        FactoryGuiElement factoryGuiElement = fge.get();
        if (factoryGuiElement != null) factoryGuiElement.finalizeMixin(graphics, this);
        fge.remove();ci.remove();
    }
    ^///?}
    *///?} else {
    @Inject(method = "renderExperienceBar", at = @At("HEAD"), cancellable = true)
    public void renderExperienceBar(class_332 guiGraphics, int i, CallbackInfo ci) {
        FactoryGuiElement.EXPERIENCE_BAR.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = "renderExperienceBar", at = @At("RETURN"))
    public void renderExperienceBarReturn(class_332 guiGraphics, int i, CallbackInfo ci) {
        FactoryGuiElement.EXPERIENCE_BAR.finalizeMixin(guiGraphics, this);
    }

    @Inject(method = "renderJumpMeter", at = @At("HEAD"), cancellable = true)
    public void renderJumpMeter(class_1316 playerRideableJumping, class_332 guiGraphics, int i, CallbackInfo ci) {
        FactoryGuiElement.JUMP_METER.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = "renderJumpMeter", at = @At("RETURN"))
    public void renderJumpMeterReturn(class_1316 playerRideableJumping, class_332 guiGraphics, int i, CallbackInfo ci) {
        FactoryGuiElement.JUMP_METER.finalizeMixin(guiGraphics, this);
    }
    //?}

    @Inject(method = /*? if neoforge && >=26.1 {*//*"extractSelectedItemName(Lnet/minecraft/client/gui/GuiGraphics;I)V"*//*?} else if forge || neoforge {*/ /*"renderSelectedItemName(Lnet/minecraft/client/gui/GuiGraphics;I)V" *//*?} else if >=26.1 {*//*"extractSelectedItemName"*//*?} else  {*/"renderSelectedItemName"/*?}*/, at = @At("HEAD"), cancellable = true/*? if forge || neoforge {*//*, remap = false*//*?}*/)
    public void extractSelectedItemName(net.minecraft.class_332 guiGraphics, /*? if forge || neoforge {*/ /*int shift, *//*?}*/ CallbackInfo ci) {
        FactoryGuiElement.SELECTED_ITEM_NAME.prepareMixin(guiGraphics, this, ci);
    }

    @Inject(method = /*? if neoforge && >=26.1 {*//*"extractSelectedItemName(Lnet/minecraft/client/gui/GuiGraphics;I)V"*//*?} else if forge || neoforge {*/ /*"renderSelectedItemName(Lnet/minecraft/client/gui/GuiGraphics;I)V" *//*?} else if >=26.1 {*//*"extractSelectedItemName"*//*?} else  {*/"renderSelectedItemName"/*?}*/, at = @At("RETURN")/*? if forge || neoforge {*//*, remap = false*//*?}*/)
    public void extractSelectedItemNameReturn(net.minecraft.class_332 guiGraphics, /*? if forge || neoforge {*/ /*int shift, *//*?}*/ CallbackInfo ci) {
        FactoryGuiElement.SELECTED_ITEM_NAME.finalizeMixin(guiGraphics, this);
    }

    @Accessor
    public abstract class_365 getSpectatorGui();

    @Accessor
    public abstract class_1799 getLastToolHighlight();

    @Accessor
    public abstract int getToolHighlightTimer();
}

package wily.factoryapi.base.client.drawable;

//?}
import org.jetbrains.annotations.Nullable;
import wily.factoryapi.base.client.FactoryGuiGraphics;
import wily.factoryapi.util.FactoryScreenUtil;

import java.awt.*;
import java.util.function.BiConsumer;
import net.minecraft.class_11909;
import net.minecraft.class_364;
import net.minecraft.class_8030;

public abstract class AbstractDrawableButton<D extends AbstractDrawableButton<D>> extends DrawableCustomWidth<D> implements class_364 {
    public @Nullable Boolean selected;
    protected BiConsumer<D,Integer> onPress = (b,i)->{};
    public IFactoryDrawableType selection;

    protected boolean hoverSelection = true;
    public Color color;
    public float grave = 1.5F;

    public AbstractDrawableButton(int x, int y,  IFactoryDrawableType buttonImage){
        super(buttonImage,x,y);
    }
    public D onPress(BiConsumer<D,Integer> onPress){
        this.onPress = onPress;
        return (D) this;
    }

    public D grave(float grave){
        this.grave = grave;
        return (D) this;
    }
    public D color(Color color){
        this.color = color;
        return (D) this;
    }
    public D icon(IFactoryDrawableType icon){
        return overlay(icon);
    }
    public D select(Boolean selected){
        this.selected = selected;
        return (D) this;
    }
    public D selection(IFactoryDrawableType selection){
        this.selection = selection;
        return (D) this;
    }
    public D selection(Direction direction){
        return selection(adjacentImage(direction));
    }
    public D withWidth(Integer width){
        this.customWidth = width != null ? Math.max(4,width) : null;
        return (D) this;
    }
    public D disableHoverSelection(){
        this.hoverSelection = false;
        return (D) this;
    }

    @Override
    public boolean method_25405(double d, double e) {
        return inMouseLimit(d,e);
    }

    //? if >=1.21.9 {
    @Override
    public boolean method_25402(class_11909 mouseButtonEvent, boolean bl) {
        return handleClick(mouseButtonEvent.comp_4798(), mouseButtonEvent.comp_4799(), mouseButtonEvent.method_74245());
    }

    @Override
    public boolean method_25406(class_11909 mouseButtonEvent) {
        return  handleRelease(mouseButtonEvent.comp_4798(), mouseButtonEvent.comp_4799(), mouseButtonEvent.method_74245());
    }

    @Override
    public boolean method_25403(class_11909 mouseButtonEvent, double d, double e) {
        return handleDragging(mouseButtonEvent.comp_4798(), mouseButtonEvent.comp_4799(), mouseButtonEvent.method_74245(), d, e);
    }

    //?} else {
    /*@Override
    public boolean mouseClicked(double d, double e, int i) {
        return handleClick(d, e, i);
    }

    @Override
    public boolean mouseReleased(double d, double e, int i) {
        return handleRelease(d, e, i);
    }

    @Override
    public boolean mouseDragged(double mouseX, double mouseY, int i, double f, double g) {
        return handleDragging(mouseX, mouseY, i, f, g);
    }
    *///?}

    public boolean handleClick(double d, double e, int i) {
        if (inMouseLimit(d,e) && visible.get()) {
            FactoryScreenUtil.playButtonDownSound(grave);
            if (selected != null) selected = !selected;
            onPress.accept((D) this,i);
            return true;
        }
        return false;
    }

    public boolean handleRelease(double d, double e, int i) {
        return false;
    }

    public boolean handleDragging(double mouseX, double mouseY, int i, double dx, double dy) {
        return false;
    }

    public boolean inMouseLimit(double mouseX, double mouseY) {
        return FactoryScreenUtil.isMouseOver(mouseX,mouseY,method_3321(),method_3322(),width(),height());
    }

    @Override
    public void draw(net.minecraft.class_332 graphics) {
        this.draw(graphics,method_3321(),method_3322());
    }

    @Override
    public void draw(net.minecraft.class_332 graphics, int x, int y) {
        if (color != null)
            //? if <1.21.6 {
            /*FactoryGuiGraphics.of(graphics).setColor(color.getRed() / 255F, color.getGreen() / 255F, color.getBlue() / 255F, 1.0F);
            *///?} else
            FactoryGuiGraphics.of(graphics).setBlitColor(color.getRed() / 255F, color.getGreen() / 255F, color.getBlue() / 255F, 1F);
        super.draw(graphics, x, y);
        if (color != null)
            //? if <1.21.6 {
            /*FactoryGuiGraphics.of(graphics).clearColor();
            *///?} else
            FactoryGuiGraphics.of(graphics).clearBlitColor();
        if (isSelected() || hovered && hoverSelection) {
            if (selection != null) selection.draw(graphics, x, y);
            else {
                //? if >=1.21.9 && <1.21.11 {
                graphics.method_73198(x, y, width(), height(), -1);
                //?} else if >=26.1 {
                /*graphics.outline(x, y, width(), height(), -1);
                *///?} else {
                /*graphics.renderOutline(x, y, width(), height(), -1);
                *///?}
            }
        }
    }

    public class_8030 method_48202() {
        return FactoryScreenUtil.rect2iToRectangle(this);
    }

    public boolean isSelected(){
        return selected == Boolean.TRUE;
    }

    public void method_25365(boolean bl) {
        if (bl) selected = true;
    }

    public boolean method_25370() {
        return false;
    }
}

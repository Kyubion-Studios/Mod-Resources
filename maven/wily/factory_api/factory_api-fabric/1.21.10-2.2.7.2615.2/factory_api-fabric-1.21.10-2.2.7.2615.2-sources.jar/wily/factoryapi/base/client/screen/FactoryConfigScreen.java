package wily.factoryapi.base.client.screen;

import com.google.common.collect.ImmutableList;
import org.jetbrains.annotations.Nullable;
import wily.factoryapi.base.client.FactoryOptions;
import wily.factoryapi.base.client.FactoryConfigWidgets;
import wily.factoryapi.base.config.FactoryCommonOptions;
import wily.factoryapi.base.config.FactoryConfig;

import java.util.ArrayList;
import java.util.List;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_4185;
import net.minecraft.class_4265;
import net.minecraft.class_437;
import net.minecraft.class_5244;
import net.minecraft.class_6379;

public class FactoryConfigScreen extends class_437 {
    public static final class_2561 TITLE = class_2561.method_43471("options.factory_api.title");
    protected final List<class_339> optionWidgets = new ArrayList<>();

    public static final List<FactoryConfig<?>> CONFIGS = new ArrayList<>(List.of(FactoryOptions.NEAREST_MIPMAP_SCALING, FactoryOptions.RANDOM_BLOCK_ROTATIONS, FactoryOptions.MANUAL_MIPMAP, FactoryOptions.UI_DEFINITION_LOGGING, FactoryCommonOptions.EXPRESSION_FAIL_LOGGING));
    public final class_437 parent;
    private ConfigList list;

    public FactoryConfigScreen(class_437 screen, List<FactoryConfig<?>> configs, class_2561 title) {
        super(title);
        parent = screen;
        for (FactoryConfig<?>  config : configs) {
            if (config.getStorageAccess().allowSync() && !config.getStorageAccess().allowClientSync(class_310.method_1551().field_1724)) continue;
            class_339 widget = FactoryConfigWidgets.createWidget( config, 0, 0, 150, b-> config.sync());
            if (widget != null) optionWidgets.add(widget);
        }
    }

    public static FactoryConfigScreen createFactoryAPIConfigScreen(class_437 parent){
        return new FactoryConfigScreen(parent, CONFIGS, TITLE);
    }

    protected void method_25426() {
        this.list = this.method_37063(new ConfigList(this.field_22787, this.field_22789, this.field_22790 - 64, 32, 25, this));
        list.addSmall(optionWidgets);
        this.method_37063(class_4185.method_46430(class_5244.field_24334, (button) -> method_25419()).method_46434(this.field_22789 / 2 - 100, this.field_22790 - 27, 200, 20).method_46431());
        super.method_25426();
    }

    //? if >=26.1 {
    /*@Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a) {
        super.extractRenderState(graphics, mouseX, mouseY, a);
        graphics.text(this.font, this.title, this.width / 2, 20, 0xFFFFFFFF);
    }
    *///?} else {
    public void method_25394(class_332 guiGraphics, int i, int j, float f) {
        //? if <=1.20.1
        /*renderBackground(guiGraphics);*/
        super.method_25394(guiGraphics, i, j, f);
        guiGraphics.method_27534(this.field_22793, this.field_22785, this.field_22789 / 2, 20, 0xFFFFFFFF);
    }
    //?}

    @Override
    public void method_25419() {
        field_22787.method_1507(parent);
    }

    public static class ConfigList extends class_4265<ConfigList.Entry>{
        private final class_437 screen;

        public ConfigList(class_310 minecraft, int screenWidth, int listHeight, int k, int l, class_437 screen) {
            super(minecraft, screenWidth,  /*? if <=1.20.2 {*//*listHeight + k * 2, k, listHeight + k, l*//*?} else {*/listHeight, k, l/*?}*/);
            this.screen = screen;
        }

        public void addSmall(List<class_339> list) {
            for (int i = 0; i < list.size(); i += 2) {
                this.addSmall(list.get(i), i < list.size() - 1 ? list.get(i + 1) : null);
            }
        }

        public void addSmall(class_339 arg, @Nullable class_339 arg2) {
            this.method_25321(Entry.small(arg, arg2, this.screen));
        }

        @Override
        public int method_25322() {
            return 310;
        }

        public static class Entry extends class_4265.class_4266<Entry> {
            private final List<class_339> children;
            private final class_437 screen;

            Entry(List<class_339> list, class_437 arg) {
                this.children = ImmutableList.copyOf(list);
                this.screen = arg;
            }

            public static Entry big(List<class_339> list, class_437 arg) {
                return new Entry(list, arg);
            }

            public static Entry small(class_339 arg, @Nullable class_339 arg2, class_437 arg3) {
                return arg2 == null ? new Entry(ImmutableList.of(arg), arg3) : new Entry(ImmutableList.of(arg, arg2), arg3);
            }
            //? if >=26.1 {
            /*@Override
            public void extractContent(GuiGraphicsExtractor graphics, int mouseX, int mouseY, boolean hovered, float a) {
                extractContent(graphics, mouseX, mouseY, hovered, a, getContentY());
            }
            *///?} else if >=1.21.9 {
            @Override
            public void method_25343(class_332 guiGraphics, int i, int j, boolean bl, float f) {
                renderContent(guiGraphics, i, j, bl, f, method_73382());
            }
            //?} else {
            /*@Override
            public void render(GuiGraphics arg, int i, int j, int k, int l, int m, int n, int o, boolean bl, float f) {
                renderContent(arg, n, o, bl, f, j);
            }
            *///?}

            //? if >=26.1 {
            /*public void extractContent(GuiGraphicsExtractor graphics, int i, int j, boolean bl, float f, int contentY) {
                int p = 0;
                int q = this.screen.width / 2 - 155;

                for (AbstractWidget abstractWidget : this.children) {
                    abstractWidget.setPosition(q + p, contentY);
                    abstractWidget.extractRenderState(graphics, i, j, f);
                    p += 160;
                }
            }
            *///?} else {
            public void renderContent(class_332 guiGraphics, int i, int j, boolean bl, float f, int contentY) {
                int p = 0;
                int q = this.screen.field_22789 / 2 - 155;

                for (class_339 abstractWidget : this.children) {
                    abstractWidget.method_48229(q + p, contentY);
                    abstractWidget.method_25394(guiGraphics, i, j, f);
                    p += 160;
                }
            }
            //?}

            @Override
            public List<? extends class_364> method_25396() {
                return this.children;
            }

            @Override
            public List<? extends class_6379> method_37025() {
                return this.children;
            }
        }
    }
}

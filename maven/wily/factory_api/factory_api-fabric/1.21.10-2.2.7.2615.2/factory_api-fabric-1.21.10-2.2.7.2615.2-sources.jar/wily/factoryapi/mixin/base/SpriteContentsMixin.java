package wily.factoryapi.mixin.base;

import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.base.client.FactoryOptions;
import wily.factoryapi.base.client.MipmapMetadataSection;

import java.io.IOException;
import java.util.Map;
import java.util.Optional;
//? if <=1.20.1
/*import wily.factoryapi.base.client.FactorySpriteContents;*/
import net.minecraft.class_1011;
import net.minecraft.class_7677;
import net.minecraft.class_7764;

@Mixin(class_7764.class)
public abstract class SpriteContentsMixin /*? if <=1.20.1 {*/ /*implements FactorySpriteContents *//*?}*/{
    //? if <=1.20.1 {
    /*ResourceMetadata metadata = ResourceMetadata.EMPTY;
    @Override
    public ResourceMetadata metadata() {
        return metadata;
    }

    @Override
    public void setMetadata(ResourceMetadata metadata) {
        this.metadata = metadata;
    }
    *///?} else if <1.21.9 {
    /*@Shadow public abstract ResourceMetadata metadata();
    *///?} else {
    @Shadow public abstract <T> Optional<T> getAdditionalMetadata(class_7677<T> par1);
    //?}

    @Shadow class_1011[] byMipLevel;

    @Shadow public abstract net.minecraft.class_2960 name();


    @Inject(method = "increaseMipLevel", at = @At("RETURN"))
    public void increaseMipLevel(int i, CallbackInfo ci) {
        if (!FactoryOptions.MANUAL_MIPMAP.get()) return;

        //? if >=1.21.9 {
        MipmapMetadataSection manualMipmap = getAdditionalMetadata(MipmapMetadataSection.TYPE).orElseGet(()->MipmapMetadataSection.createFallback((class_7764) (Object) this, i));
        //?} else {
        /*MipmapMetadataSection manualMipmap = metadata().getSection(MipmapMetadataSection.TYPE).orElseGet(()->MipmapMetadataSection.createFallback((SpriteContents) (Object) this, i));
        *///?}
        class_1011 original = byMipLevel[0];
        for (Map.Entry<Integer, MipmapMetadataSection.Level> entry : manualMipmap.levels().entrySet()) {
            if (entry.getKey() > i) break;
            class_1011 image = entry.getValue().image();
            int divisor = (int) Math.pow(2, entry.getKey());
            int width = original.method_4307() / divisor;
            int height = original.method_4323() / divisor;
            if (image == null) {
                FactoryAPI.LOGGER.error("Failed to replace generated mipmap from texture {}: {} failed to load", name(), entry.getValue().texture());
            } else if (image.method_4307() != width || image.method_4323() != height) {
                FactoryAPI.LOGGER.error("Failed to replace generated mipmap from texture {}: {} has an incorrect size, it should be {}x{}", name(), entry.getValue().texture(), width, height);
            } else byMipLevel[entry.getKey()] = image;
        }
    }
}

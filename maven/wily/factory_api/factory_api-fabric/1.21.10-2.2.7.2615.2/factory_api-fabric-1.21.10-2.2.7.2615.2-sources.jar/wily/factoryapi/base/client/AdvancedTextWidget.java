package wily.factoryapi.base.client;

import wily.factoryapi.mixin.base.BakedSheetGlyphAccessor;
import wily.factoryapi.base.Bearer;
import wily.factoryapi.mixin.base.FontAccessor;
import wily.factoryapi.util.FactoryScreenUtil;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_11768;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_3532;
import net.minecraft.class_364;
import net.minecraft.class_5481;
import net.minecraft.class_6379;
import net.minecraft.class_6382;
import net.minecraft.class_8030;

public class AdvancedTextWidget extends SimpleLayoutRenderable implements class_364, class_6379 {
    private final UIAccessor accessor;
    private List<class_5481> lines = Collections.emptyList();
    private int[] widthPerLine = new int[0];
    private int[] heightPerLine = new int[0];
    private int lineSpacing = 12;
    private boolean centered = false;
    private int color = 0xFFFFFFFF;
    private boolean shadow = true;
    private boolean multipleHeights = true;

    public AdvancedTextWidget(UIAccessor accessor){
        this.accessor = accessor;
    }

    public AdvancedTextWidget withLines(List<class_5481> lines){
        if (lines != null) {
            this.lines = lines;
            processLines();
        }
        return this;
    }

    public static int romanToInteger(String roman) {
        char[] chars = roman.toCharArray();
        int result = 0;
        int lastValue = 0;
        byte lastSignal = 1;
        for (int i = chars.length - 1; i >= 0; i--) {
            char c = chars[i];

            int v = switch (c) {
                case 'I' -> 1;
                case 'X' -> 10;
                case 'L' -> 50;
                case 'C' -> 100;
                case 'D' -> 500;
                case 'M' -> 1000;
                default -> throw new IllegalStateException("Unexpected value: " + c);
            };

            if (v < lastValue || lastSignal < 0) {
                result -= v;
                lastSignal = -1;
            }

            if (v == lastValue)
                result += lastSignal * v;
            else if (v > lastValue) {
                result += v;
                lastSignal = 1;
            }

            lastValue = v;
        }

        return result;
    }

    public void processLines(){
        height = 0;
        widthPerLine = new int[lines.size()];
        heightPerLine = new int[lines.size()];
        for (int i = 0; i < lines.size(); i++) {
            class_5481 sequence = lines.get(i);
            widthPerLine[i] = class_310.method_1551().field_1772.method_30880(sequence);
            heightPerLine[i] = multipleHeights ? Math.max(lineSpacing, Math.max(getLineHeight(sequence) - 9, 0) + lineSpacing) : lineSpacing;
            height+= heightPerLine[i];
        }
    }

    public AdvancedTextWidget withLines(class_2561 component, int width){
        return withWidth(width).withLines(class_310.method_1551().field_1772.method_1728(component, width));
    }

    public static int getLineHeight(class_5481 sequence){
        Bearer<Integer> bearer = Bearer.of(0);
        sequence.accept((n, style, pos)->{
            FontAccessor fontAccessor = (FontAccessor) class_310.method_1551().field_1772;
            //? if >=1.21.9 {
            class_11768 glyph = fontAccessor.getBakedGlyph(pos, style);
            if (glyph instanceof BakedSheetGlyphAccessor sheetGlyph) {
                int height = Math.round(sheetGlyph.getBottom() - sheetGlyph.getTop());
                if (height > bearer.get()) bearer.set(height);
            } else if (glyph.method_73398().getAdvance() > bearer.get()) bearer.set(Math.round(glyph.method_73398().getAdvance()));
            //?} else {
            /*fontAccessor.getDefaultFontSet(style.getFont()).getGlyphInfo(pos, fontAccessor.getFilterFishyGlyphs()).bake(sheetGlyphInfo-> {
                int height = Math.round(sheetGlyphInfo.getPixelHeight() / sheetGlyphInfo.getOversample());
                if (height > bearer.get()) bearer.set(height);
                return null;
            });
            *///?}
            return true;
        });
        return bearer.get();
    }

    public AdvancedTextWidget lineSpacing(int lineSpacing){
        this.lineSpacing = lineSpacing;
        return this;
    }

    public AdvancedTextWidget centered(boolean centered){
        this.centered = centered;
        return this;
    }

    public AdvancedTextWidget multipleHeights(boolean multipleHeights){
        this.multipleHeights = multipleHeights;
        return this;
    }

    public AdvancedTextWidget withPos(int x, int y){
        method_48229(x, y);
        return this;
    }

    public AdvancedTextWidget withWidth(int width){
        this.width = width;
        return this;
    }

    public AdvancedTextWidget withColor(int color){
        this.color = color;
        return this;
    }

    public AdvancedTextWidget withShadow(boolean shadow){
        this.shadow = shadow;
        return this;
    }

    public List<class_5481> getLines(){
        return lines;
    }

    //? if >=26.1 {
    /*@Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a) {
        int actualHeight = getY();
        for (int i1 = 0; i1 < lines.size(); i1++) {
            int lineHeight = heightPerLine[i1];
            graphics.text(Minecraft.getInstance().font, lines.get(i1), getX() + (centered ? (width - widthPerLine[i1]) / 2 : 0), actualHeight + (lineHeight - lineSpacing) / 2, color, shadow);
            actualHeight += lineHeight;
        }
    }
    *///?} else {
    @Override
    public void method_25394(class_332 guiGraphics, int i, int j, float f) {
        int actualHeight = method_46427();
        for (int i1 = 0; i1 < lines.size(); i1++) {
            int lineHeight = heightPerLine[i1];
            guiGraphics.method_51430(class_310.method_1551().field_1772, lines.get(i1), method_46426() + (centered ? (width - widthPerLine[i1]) / 2 : 0), actualHeight + (lineHeight - lineSpacing) / 2, color, shadow);
            actualHeight += lineHeight;
        }
    }
    //?}

    //? if >=1.21.9 {
    @Override
    public boolean method_25402(class_11909 mouseButtonEvent, boolean bl) {
        if (handleComponentsClicked(mouseButtonEvent.comp_4798(), mouseButtonEvent.comp_4799(), mouseButtonEvent.method_74245()))
            return true;
        return class_364.super.method_25402(mouseButtonEvent, bl);
    }
    //?} else {
    /*@Override
    public boolean mouseClicked(double d, double e, int i) {
        if (handleComponentsClicked(d, e, i))
            return true;
        return GuiEventListener.super.mouseClicked(d, e, i);
    }
    *///?}

    public boolean handleComponentsClicked(double d, double e, int i) {
        if (accessor.getScreen() != null && method_25405(d,e)){
            if (i == 0) {
                int actualHeight = method_46427();
                for (int i1 = 0; i1 < lines.size(); i1++) {
                    int lineHeight = heightPerLine[i1];
                    if (e >= actualHeight && e < actualHeight + lineHeight){
                        //? if >=1.21.11 {
                        /*ActiveTextCollector.ClickableStyleFinder clickableStyleFinder = new ActiveTextCollector.ClickableStyleFinder(Minecraft.getInstance().font, (int) d, (int) e);
                        clickableStyleFinder.accept(0, Mth.floor(d - getX()), lines.get(i1)); // TODO WHAT WHAT WHAT WHAT WHAT
                        Style style = clickableStyleFinder.result();
                        if (style != null) ScreenAccessor.callDefaultHandleGameClickEvent(style.getClickEvent(), Minecraft.getInstance(), accessor.getScreen());
                        *///?} else {
                        accessor.getScreen().method_25430(class_310.method_1551().field_1772.method_27527().method_30876(lines.get(i1), class_3532.method_15357(d - method_46426())));
                        //?}
                        return true;
                    }
                    actualHeight += lineHeight;
                }
            }
            return false;
        }
        return false;
    }

    @Override
    public boolean method_25405(double d, double e) {
        return FactoryScreenUtil.isMouseOver(d, e, method_46426(), method_46427(), method_25368(), method_25364());
    }

    @Override
    public void method_25365(boolean bl) {
    }

    @Override
    public boolean method_25370() {
        return false;
    }

    @Override
    public class_8030 method_48202() {
        return super.method_48202();
    }

    @Override
    public class_6380 method_37018() {
        return class_6380.field_33784;
    }

    @Override
    public void method_37020(class_6382 arg) {
    }
}

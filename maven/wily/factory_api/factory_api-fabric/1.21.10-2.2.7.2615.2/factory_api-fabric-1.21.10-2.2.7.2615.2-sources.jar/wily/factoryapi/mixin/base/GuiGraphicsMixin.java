package wily.factoryapi.mixin.base;

import com.mojang.blaze3d.systems.RenderSystem;
//? if >=1.21.6 {
//? if >=1.21.11 {
/*import com.mojang.blaze3d.textures.GpuSampler;
*///?}
import com.mojang.blaze3d.textures.GpuTextureView;
import com.mojang.blaze3d.pipeline.RenderPipeline;
import org.joml.Matrix3x2f;
import org.joml.Matrix3x2fStack;
import org.joml.Matrix4f;
import org.joml.Vector3f;
import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.ModifyArg;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wily.factoryapi.base.client.FactoryGuiGraphics;
import wily.factoryapi.base.client.FactoryGuiMatrixStack;
import wily.factoryapi.util.ColorUtil;
import wily.factoryapi.util.FactoryScreenUtil;
//? if <=1.20.1 {
/*import wily.factoryapi.base.client.GuiSpriteScaling;
*///?}
import java.util.function.Function;
import net.minecraft.class_1044;
import net.minecraft.class_1058;
import net.minecraft.class_10799;
import net.minecraft.class_11246;
import net.minecraft.class_310;
import net.minecraft.class_4597;
import net.minecraft.class_8030;

@Mixin(net.minecraft.class_332.class)
public abstract class GuiGraphicsMixin implements FactoryGuiGraphics.Accessor {
    //? if >=1.21.2 {
    @Unique private int blitColor = -1;


    //? if <1.21.6 {
    
    /*@Unique private Function<ResourceLocation,RenderType> renderingOverride = RenderType::guiTextured;
    *///?} else {
    @Unique
    private RenderPipeline renderingOverride = class_10799.field_56883;
    //?}
    //?}
    //? if <1.21.6 {
    /*@Mutable
    @Shadow @Final private MultiBufferSource.BufferSource bufferSource;

    @Shadow protected abstract void applyScissor(ScreenRectangle arg);

    *///?}

    @Shadow @Final private net.minecraft.class_332.class_8214 scissorStack;
    @Shadow @Final private class_310 minecraft;

    //? if >=1.21.6 {
    //? if >=26.1 {
    /*@Shadow protected abstract void innerBlit(RenderPipeline pipeline, GpuTextureView textureView, GpuSampler sampler, int x0, int y0, int x1, int y1, float u0, float u1, float v0, float v1, int color);
    *///?} else {
    @Shadow protected abstract void submitBlit(RenderPipeline pipeline, GpuTextureView textureView, /*?if >=1.21.11 {*//*GpuSampler sampler, *//*?}*/ int x0, int y0, int x1, int y1, float u0, float u1, float v0, float v1, int color);
    //?}
    @Shadow @Final public class_11246 guiRenderState;
    @Shadow public abstract Matrix3x2fStack pose();
    //?}

    @Unique
    private class_4597.class_4598 lastBufferSource;

    //? if <=1.20.1
    /*@Shadow abstract void innerBlit(ResourceLocation resourceLocation, int i, int j, int k, int l, int m, float f, float g, float h, float n);*/

    @Unique
    private final FactoryGuiGraphics factoryGuiGraphics = new FactoryGuiGraphics() {
        final FactoryGuiMatrixStack pose = FactoryGuiMatrixStack.of(context().method_51448());

        @Override
        public net.minecraft.class_332 context() {
            return (net.minecraft.class_332) (Object)GuiGraphicsMixin.this;
        }


        public void disableDepthTest() {
            FactoryScreenUtil.disableDepthTest();
            //? if >=1.21.2 && <1.21.6 {
            /*renderingOverride = RenderType::guiTexturedOverlay;
            *///?}
        }

        public void enableDepthTest() {
            FactoryScreenUtil.enableDepthTest();
            //? if >=1.21.2 && <1.21.6 {
            /*renderingOverride = RenderType::guiTextured;
            *///?}
        }

        @Override
        public void blit(net.minecraft.class_2960 texture, int x, int y, int uvX, int uvY, int width, int height) {
            //? if <1.21.2 {
            /*context().blit(texture, x, y, uvX, uvY, width, height);
             *///?} else {
            context().method_25290(renderingOverride, texture, x, y, uvX, uvY, width, height, 256, 256);
            //?}
        }

        @Override
        public void blit(net.minecraft.class_2960 texture, int x, int y, int z, float uvX, float uvY, int width, int height, int textureWidth, int textureHeight) {
            //? if <1.21.2 {
            /*context().blit(texture, x, y, z, uvX, uvY, width, height, textureWidth, textureHeight);
            *///?} else {
            innerBlit(renderingOverride, texture, x, x + width, y, y + height, 0, (uvX + 0.0F) / (float)textureWidth, (uvX + (float)width) / (float)textureWidth, (uvY + 0.0F) / (float)textureHeight, (uvY + (float)height) / (float)textureHeight, blitColor);
            //?}
        }

        @Override
        public void blit(net.minecraft.class_2960 texture, int x, int xd, int y, int yd, float uvX, float uvY, int width, int height, int textureWidth, int textureHeight) {
            //? if <1.21.2 {
            /*context().blit(texture, x, xd, y, yd, uvX, uvY, width, height, textureWidth, textureHeight);
            *///?} else {
            innerBlit(renderingOverride, texture, x, xd, y, yd, 0, (uvX + 0.0F) / (float)textureWidth, (uvX + (float)width) / (float)textureWidth, (uvY + 0.0F) / (float)textureHeight, (uvY + (float)height) / (float)textureHeight, blitColor);
            //?}
        }

        @Override
        public void blit(net.minecraft.class_2960 texture, int x, int y, float uvX, float uvY, int width, int height, int textureWidth, int textureHeight) {
            //? if <1.21.2 {
            /*context().blit(texture, x, y, uvX, uvY, width, height, textureWidth, textureHeight);
            *///?} else
            context().method_25290(renderingOverride, texture, x, y, uvX, uvY, width, height, textureWidth, textureHeight);
        }


        public void blitSprite(net.minecraft.class_2960 resourceLocation, int x, int y, int width, int height) {
            //? if <1.20.2 {
            /*this.blitSprite(resourceLocation, x, y, 0, width, height);
             *///?} else if <1.21.2 {
            /*context().blitSprite(resourceLocation, x, y, width, height);
             *///?} else
            context().method_52707(renderingOverride, resourceLocation, x, y, width, height,blitColor);
        }

        public void blitSprite(net.minecraft.class_2960 resourceLocation, int x, int y, int z, int width, int height) {
        //? if <1.20.2 {
        /*TextureAtlasSprite textureAtlasSprite = FactoryGuiGraphics.getSprites().getSprite(resourceLocation);
        GuiSpriteScaling guiSpriteScaling = FactoryGuiGraphics.getSprites().getSpriteScaling(textureAtlasSprite);
        if (guiSpriteScaling instanceof GuiSpriteScaling.Stretch) {
            this.blitSprite(textureAtlasSprite, x, y, z, width, height);
        } else if (guiSpriteScaling instanceof GuiSpriteScaling.Tile tile) {
            this.blitTiledSprite(textureAtlasSprite, x, y, z, width, height, 0, 0, tile.width(), tile.height(), tile.width(), tile.height());
        } else if (guiSpriteScaling instanceof GuiSpriteScaling.NineSlice nineSlice) {
            this.blitNineSlicedSprite(textureAtlasSprite, nineSlice, x, y, z, width, height);
        }
        *///?} else if <1.21.2 {
            /*context().blitSprite(resourceLocation, x, y, z, width, height);
             *///?} else {
            if (z != 0) {
                FactoryGuiMatrixStack.of(context().method_51448()).pushPose();
                FactoryGuiMatrixStack.of(context().method_51448()).translate(0, z,0);
            }
            context().method_52707(renderingOverride, resourceLocation, x, y, width, height, blitColor);
            if (z != 0) FactoryGuiMatrixStack.of(context().method_51448()).popPose();
            //?}
        }

        @Override
        public void blitSprite(net.minecraft.class_2960 resourceLocation, int textureWidth, int textureHeight, int uvX, int uvY, int x, int y, int z, int width, int height) {
            //? if <=1.20.1 {
            /*TextureAtlasSprite textureAtlasSprite = FactoryGuiGraphics.getSprites().getSprite(resourceLocation);
            GuiSpriteScaling guiSpriteScaling = FactoryGuiGraphics.getSprites().getSpriteScaling(textureAtlasSprite);
            if (guiSpriteScaling instanceof GuiSpriteScaling.Stretch) {
                this.blitSprite(textureAtlasSprite, textureWidth, textureHeight, uvX, uvY, x, y, z, width, height);
            } else {
                this.blitSprite(textureAtlasSprite, x, y, z, width, height);
            }
            *///?} else if <1.21.2 {
            /*context().blitSprite(resourceLocation, textureWidth, textureHeight, uvX, uvY, x, y, z, width, height);
            *///?} else {
            if (z != 0) {
                FactoryGuiMatrixStack.of(context().method_51448()).pushPose();
                FactoryGuiMatrixStack.of(context().method_51448()).translate(0, z, 0);
            }
            context().method_70846(renderingOverride, resourceLocation, textureWidth, textureHeight, uvX, uvY, x, y, width, height);
            if (z != 0) FactoryGuiMatrixStack.of(context().method_51448()).popPose();
            //?}
        }

        @Override
        public void blit(int x, int y, int z, int width, int height, class_1058 textureAtlasSprite) {
            //? if <=1.20.1 {
            /*blitSprite(textureAtlasSprite, x, y, z, width, height);
            *///?} else if <1.21.2 {
            /*context().blit(x, y, z, width, height, textureAtlasSprite);
            *///?} else {
            if (z != 0) {
                FactoryGuiMatrixStack.of(context().method_51448()).pushPose();
                FactoryGuiMatrixStack.of(context().method_51448()).translate(0,z,0);
            }
            context().method_52709(renderingOverride, textureAtlasSprite, x, y, width, height);
            if (z != 0) FactoryGuiMatrixStack.of(context().method_51448()).popPose();
            //?}
        }

        @Override
        public void enableScissor(int x, int y, int xd, int yd, boolean matrixAffects) {
            //? if <1.21.4 {
            /*if (matrixAffects) {
                Matrix4f matrix4f = FactoryGuiMatrixStack.of(context().pose()).<PoseStack>getNative().last().pose();
                Vector3f vector3f = matrix4f.transformPosition(x, y, 0.0F, new Vector3f());
                Vector3f vector3f2 = matrix4f.transformPosition(xd, yd, 0.0F, new Vector3f());
                applyScissor(scissorStack.push(new ScreenRectangle(Mth.floor(vector3f.x), Mth.floor(vector3f.y), Mth.floor(vector3f2.x - vector3f.x), Mth.floor(vector3f2.y - vector3f.y))));
            } else context().enableScissor(x, y, xd, yd);
            *///?} else {

            if (matrixAffects) {
                context().method_44379(x, y, xd, yd);
            } else {
                //? if <1.21.6 {
                /*applyScissor(scissorStack.push(new ScreenRectangle(x, y, xd - x, yd - y)));
                *///?} else {
                scissorStack.method_49700(new class_8030(x, y, xd - x, yd - y));
                //?}
            }
            //?}
        }

        //? if <1.21.6 {
        /*@Override
        public void setColor(int color, boolean changeBlend) {
            setColor(ColorUtil.getRed(color), ColorUtil.getGreen(color), ColorUtil.getBlue(color), ColorUtil.getAlpha(color), changeBlend);
        }

        @Override
        public void setColor(float r, float g, float b, float a, boolean changeBlend) {
            if (changeBlend) {
                if (a < 1) FactoryScreenUtil.enableBlend();
                else FactoryScreenUtil.disableBlend();
            }
            //? if >=1.21.2 {
            context().flush();
            RenderSystem.setShaderColor(r, g, b, a);
            //?} else {
            /^context().setColor(r, g, b, a);
            ^///?}
        }

        @Override
        public float[] getColor() {
            //? if >=1.21.6 {
            return new float[]{1,1,1,1};
            //?} else {
            /^return RenderSystem.getShaderColor();
            ^///?}
        }
        *///?}

        //? if >=1.21.2 {
        @Override
        public void setBlitColor(float r, float g, float b, float a) {
            blitColor = ColorUtil.colorFromFloat(r,g,b,a);
        }

        @Override
        public void setBlitColor(int color) {
            blitColor = color;
        }

        @Override
        public int getBlitColor() {
            return blitColor;
        }
        //?}

        //? if >=1.21.2 {
        //? if <1.21.6 {
        /*private void innerBlit(Function<net.minecraft.resources.ResourceLocation, RenderType> function, net.minecraft.resources.ResourceLocation resourceLocation, int i, int j, int k, int l, int z, float f, float g, float h, float m, int n) {
            RenderType renderType = function.apply(resourceLocation);
            Matrix4f matrix4f = FactoryGuiMatrixStack.of(context().pose()).<PoseStack>getNative().last().pose();
            VertexConsumer vertexConsumer = getBufferSource().getBuffer(renderType);
            vertexConsumer.addVertex(matrix4f, (float)i, (float)k, z).setUv(f, h).setColor(n);
            vertexConsumer.addVertex(matrix4f, (float)i, (float)l, z).setUv(f, m).setColor(n);
            vertexConsumer.addVertex(matrix4f, (float)j, (float)l, z).setUv(g, m).setColor(n);
            vertexConsumer.addVertex(matrix4f, (float)j, (float)k, z).setUv(g, h).setColor(n);
            getBufferSource().endBatch(renderType);
        }
        *///?} else {
        private void innerBlit(RenderPipeline pipeline, net.minecraft.class_2960 resourceLocation, int i, int j, int k, int l, int z, float f, float g, float h, float m, int n) {
            class_1044 texture = minecraft.method_1531().method_4619(resourceLocation);
            GpuTextureView gpuTextureView = texture.method_71659();
            //? if >=26.1 {
            /*GuiGraphicsMixin.this.innerBlit(pipeline, gpuTextureView, texture.getSampler(), i, k, j, l, f, g, h, m, n);
            *///?} else {
            submitBlit(pipeline, gpuTextureView, /*?if >=1.21.11 {*//*texture.getSampler(),*//*?}*/ i, k, j, l, f, g, h, m, n);
            //?}
        }
        //?}
        //?}
        //? if <=1.20.1 {
        /*public void blitSprite(TextureAtlasSprite textureAtlasSprite, int i, int j, int k, int l, int m, int n, int o, int p, int q) {
            if (p != 0 && q != 0) {
                GuiGraphicsMixin.this.innerBlit(textureAtlasSprite.atlasLocation(), m, m + p, n, n + q, o, textureAtlasSprite.getU((float)k / (float)i * 16), textureAtlasSprite.getU((float)(k + p) / (float)i * 16), textureAtlasSprite.getV((float)l / (float)j * 16), textureAtlasSprite.getV((float)(l + q) / (float)j * 16));
            }
        }

        public void blitSprite(TextureAtlasSprite textureAtlasSprite, int i, int j, int k, int l, int m) {
            if (l != 0 && m != 0) {
                GuiGraphicsMixin.this.innerBlit(textureAtlasSprite.atlasLocation(), i, i + l, j, j + m, k, textureAtlasSprite.getU0(), textureAtlasSprite.getU1(), textureAtlasSprite.getV0(), textureAtlasSprite.getV1());
            }
        }
        *///?}
        @Override
        public class_4597.class_4598 getBufferSource() {
            //? if >=1.21.6 {
            return null;
            //?} else {
            /*return bufferSource;
            *///?}
        }
        @Override
        public void pushBufferSource(class_4597.class_4598 newBufferSource) {
            //? if <1.21.6 {
            /*lastBufferSource = bufferSource;
            bufferSource = newBufferSource;
            *///?}
        }

        @Override
        public void popBufferSource() {
            //? if <1.21.6 {
            /*if (lastBufferSource != null) bufferSource = lastBufferSource;
            *///?}
        }

        @Override
        public FactoryGuiMatrixStack pose() {
            return pose;
        }
    };
    @Override
    public FactoryGuiGraphics getFactoryGuiGraphics() {
        return factoryGuiGraphics;
    }


    //? if >=1.21.2 {
    //? if <1.21.6 {
    /*@ModifyArg(method = "blitSprite(Ljava/util/function/Function;Lnet/minecraft/resources/ResourceLocation;IIIIIIII)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Ljava/util/function/Function;Lnet/minecraft/client/renderer/texture/TextureAtlasSprite;IIIIIIIII)V"), index = 10)
    public int blitBlitCustom(int par3){
        return blitColor;
    }
    @ModifyArg(method = "blitSprite(Ljava/util/function/Function;Lnet/minecraft/resources/ResourceLocation;IIII)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Ljava/util/function/Function;Lnet/minecraft/resources/ResourceLocation;IIIII)V"), index = 6)
    public int blitSprite(int par3){
        return blitColor;
    }
    @ModifyArg(method = "blitSprite(Ljava/util/function/Function;Lnet/minecraft/client/renderer/texture/TextureAtlasSprite;IIII)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Ljava/util/function/Function;Lnet/minecraft/client/renderer/texture/TextureAtlasSprite;IIIII)V"), index = 6)
    public int blitSpriteAtlas(int par3){
        return blitColor;
    }
    @ModifyArg(method = "blit(Ljava/util/function/Function;Lnet/minecraft/resources/ResourceLocation;IIFFIIIIII)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blit(Ljava/util/function/Function;Lnet/minecraft/resources/ResourceLocation;IIFFIIIIIII)V"), index = 12)
    public int blit(int par3){
        return blitColor;
    }
    *///?} else {
    @ModifyArg(method = "blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/ResourceLocation;IIIIIIII)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/ResourceLocation;IIIIIIIII)V"), index = 10)
    public int blitBlitCustom(int par3){
        return blitColor;
    }
    @ModifyArg(method = "blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/ResourceLocation;IIII)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/ResourceLocation;IIIII)V"), index = 6)
    public int blitSprite(int par3){
        return blitColor;
    }
    @ModifyArg(method = "blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/client/renderer/texture/TextureAtlasSprite;IIII)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blitSprite(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/client/renderer/texture/TextureAtlasSprite;IIIII)V"), index = 6)
    public int blitSpriteAtlas(int par3){
        return blitColor;
    }
    @ModifyArg(method = "blit(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/ResourceLocation;IIFFIIIIII)V", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/GuiGraphics;blit(Lcom/mojang/blaze3d/pipeline/RenderPipeline;Lnet/minecraft/resources/ResourceLocation;IIFFIIIIIII)V"), index = 12)
    public int blit(int par3){
        return blitColor;
    }
    //?}
    //?}

    //? if >=1.21.6 && <1.21.9 {
    /*@Inject(method = "blitTiledSprite", at = @At("HEAD"), cancellable = true)
    public void blitTiledSprite(RenderPipeline renderPipeline, TextureAtlasSprite textureAtlasSprite, int i, int j, int k, int l, int m, int n, int o, int p, int q, int r, int s, CallbackInfo ci) {
        ci.cancel();
        if (k > 0 && l > 0) {
            if (o > 0 && p > 0) {
                GpuTextureView gpuTextureView = this.minecraft.getTextureManager().getTexture(textureAtlasSprite.atlasLocation()).getTextureView();
                this.guiRenderState
                        .submitGuiElement(new TiledBlitRenderState(
                        renderPipeline,
                        TextureSetup.singleTexture(gpuTextureView),
                        new Matrix3x2f(pose()),
                        o,
                        p,
                        i,
                        j,
                        i + k,
                        j + l,
                        textureAtlasSprite.getU((float)m / q),
                        textureAtlasSprite.getU((float)(m + o) / q),
                        textureAtlasSprite.getV((float)n / r),
                        textureAtlasSprite.getV((float)(n + p) / r),
                        s,
                        this.scissorStack.peek()
                        ));
            } else {
                throw new IllegalArgumentException("Tile size must be positive, got " + o + "x" + p);
            }
        }
    }
    *///?}


    //? if >1.20.1 && <1.21.2 {
    /*@Inject(method = "blitTiledSprite", at = @At("HEAD"), cancellable = true)
    public void blitTiledSprite(TextureAtlasSprite textureAtlasSprite, int i, int j, int k, int l, int m, int n, int o, int p, int q, int r, int s, CallbackInfo ci) {
        getFactoryGuiGraphics().blitTiledSprite(textureAtlasSprite, i, j, k, l, m, n, o, p, q, r, s);
        ci.cancel();
    }
    *///?}
}

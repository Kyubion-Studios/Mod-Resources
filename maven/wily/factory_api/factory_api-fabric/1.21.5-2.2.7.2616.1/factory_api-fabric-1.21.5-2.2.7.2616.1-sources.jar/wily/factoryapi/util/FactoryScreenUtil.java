package wily.factoryapi.util;

//? if >1.21.4 {
import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2fStack;
import wily.factoryapi.FactoryAPIClient;
import wily.factoryapi.base.client.FactoryGuiGraphics;
import wily.factoryapi.base.client.FactoryGuiMatrixStack;
import wily.factoryapi.base.client.IFactoryItemClientExtension;
import wily.factoryapi.base.client.UIAccessor;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.class_1109;
import net.minecraft.class_1792;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_308;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_3417;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_4608;
import net.minecraft.class_768;
import net.minecraft.class_7833;
import net.minecraft.class_8029;
import net.minecraft.class_8030;
import net.minecraft.class_811;
import net.minecraft.class_827;

public class FactoryScreenUtil {
    private static final class_310 mc = class_310.method_1551();

    public static void drawString(FactoryGuiMatrixStack stack, String text, int x, int y, int color, boolean shadow) {
        class_327 font = mc.field_1772;
        //? if >=1.21.6 {
        /*switch (stack) {
            case net.minecraft.client.gui.GuiGraphics graphics -> graphics./^? if >=26.1 {^//^text^//^?} else {^/ drawString/^?}^/(font, text, x, y, color, shadow);
            case PoseStack poseStack -> {
                MultiBufferSource.BufferSource source = mc.renderBuffers().bufferSource();
				font.drawInBatch(/^? if >=1.21.2 {^/Component.literal(text)/^?} else {^/ /^text^//^?}^/, (float) x, (float) y, color, shadow, poseStack.last().pose(), source, Font.DisplayMode.NORMAL, 0, 15728880/^? if <1.21.6 {^/, font.isBidirectional()/^?}^/);
                disableDepthTest();
                source.endBatch();
                enableDepthTest();
			}
			default -> throw new IllegalStateException("Unexpected value: " + stack);
		}
        *///?} else {
        class_4597.class_4598 source = mc.method_22940().method_23000();
        font.method_30882(/*? if >=1.21.2 {*/class_2561.method_43470(text)/*?} else {*/ /*text*//*?}*/, (float) x, (float) y, color, shadow, stack.<class_4587>getNative().method_23760().method_23761(), source, class_327.class_6415.field_33993, 0, 15728880/*? if <1.21.6 {*/, font.method_1726()/*?}*/);
        disableDepthTest();
        source.method_22993();
        enableDepthTest();
        //?}
    }

    public static void disableDepthTest(){
        GlStateManager._disableDepthTest();
    }

    public static void enableDepthTest(){
        GlStateManager._enableDepthTest();
    }

    public static void disableBlend(){
        GlStateManager._disableBlend();
    }

    public static void enableBlend(){
        GlStateManager._enableBlend();
    }

    public static void setShaderColor(float r, float g, float b, float a) {

    }

    public static void prepTextScale(FactoryGuiMatrixStack poseStack, Consumer<FactoryGuiMatrixStack> runnable, float x, float y, float scale) {
        float yAdd = 4 - (scale * 8) / 2F;
        poseStack.pushPose();
        poseStack.translate(x, y + yAdd, 0);
        poseStack.scale(scale, scale, scale);
        runnable.accept(poseStack);
        poseStack.popPose();
        setShaderColor(1, 1, 1, 1);
    }

    public static class_8030 rect2iToRectangle(class_768 rect){
        return new class_8030(new class_8029(rect.method_3321(),rect.method_3322()),rect.method_3319(),rect.method_3320());
    }

    //? if <1.21.6 {
    public static void renderGuiBlock(class_332 graphics, @Nullable class_2586 be, class_2680 state, int i, int j, float scaleX, float scaleY, float rotateX, float rotateY) {
        class_1792 item = state.method_26204().method_8389();
        graphics.method_51448().method_22903();
        graphics.method_51448().method_46416(i + 8F, j + 8F, 250F);
        graphics.method_51448().method_22905(1.0F, -1.0F, 1.0F);
        graphics.method_51448().method_22905(16.0F, 16.0F, 16.0F);
        graphics.method_51448().method_22905(scaleX, scaleY, 0.5F);
        graphics.method_51448().method_22907(class_7833.field_40714.rotationDegrees(rotateX));
        graphics.method_51448().method_22907(class_7833.field_40716.rotationDegrees(rotateY));
        graphics.method_51448().method_46416(-0.5f, -0.5f, -0.5f);
        class_308.method_24210();
        IFactoryItemClientExtension e;
        class_827<class_2586> blockEntityRenderer;
        if (be == null || (blockEntityRenderer = mc.method_31975().method_3550(be)) == null) {
            if ((e = IFactoryItemClientExtension.map.get(item)) != null && e.getCustomRenderer() != null) {
                e.getCustomRenderer().renderByItemBlockState(state, item.method_7854(), class_811.field_4315, graphics.method_51448(), FactoryGuiGraphics.of(graphics).getBufferSource(), 15728880, class_4608.field_21444);
            } else {
                mc.method_1541().method_3353(state, graphics.method_51448(), FactoryGuiGraphics.of(graphics).getBufferSource(), 15728880, class_4608.field_21444);
            }
        } else {
            blockEntityRenderer.method_3569(be, FactoryAPIClient.getGamePartialTick(true),graphics.method_51448(),FactoryGuiGraphics.of(graphics).getBufferSource(),15728880, class_4608.field_21444 /*? if >1.21.4 {*/, class_243.field_1353/*?}*/);
        }
        graphics.method_51452();
        graphics.method_51448().method_22909();
    }
    //?} else {
    /*public static void renderGuiBlock(net.minecraft.client.gui.GuiGraphics graphics, @Nullable BlockEntity be, BlockState state, int i, int j, float scaleX, float scaleY, float rotateX, float rotateY) {
        throw new IllegalStateException("Not implemented in 1.21.6+!");
    }
    *///?}

    public static void playButtonDownSound(float grave) {
        class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, grave));
    }

    public static boolean isMouseOver(double mouseX, double mouseY, int posX, int posY, int sizeX, int sizeY){
        return (mouseX >= posX && mouseX < posX + sizeX && mouseY >= posY && mouseY < posY + sizeY);
    }

    public static void applyOffset(net.minecraft.class_332 graphics, float x, float y, float z) {
        if (x != 0 || y != 0 | z != 0) FactoryGuiMatrixStack.of(graphics.method_51448()).translate(x, y, z);
    }

    public static void applyScale(net.minecraft.class_332 graphics, float x, float y, float z) {
        if (x != 1 || y != 1 || z != 1) FactoryGuiMatrixStack.of(graphics.method_51448()).scale(x, y, z);
    }

    public static void applyColor(net.minecraft.class_332 graphics, int color) {
        //? if >=1.21.6 {
        /*if (color != -1) FactoryGuiGraphics.of(graphics).setBlitColor(color);
        *///?} else
        if (color != -1) FactoryGuiGraphics.of(graphics).setColor(color, true);
    }

    public static UIAccessor getScreenAccessor(){
        return UIAccessor.of(FactoryAPIClient.getScreen());
    }

    public static UIAccessor getGuiAccessor(){
        return UIAccessor.of(mc.field_1705);
    }
}

package wily.factoryapi.base.client;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10515;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5599;
import net.minecraft.class_811;
import org.jetbrains.annotations.Nullable;

public interface IFactoryBlockEntityWLRenderer /*? if >=1.21.4 {*/extends class_10515<class_1799>/*?}*/ {
    //? if <1.21.9 {
    void renderByItemBlockState(class_2680 state, class_1799 itemStack, class_811 displayContext, class_4587 poseStack, class_4597 multiBufferSource, int i, int j);
    default void renderByItem(class_1799 itemStack, class_811 displayContext, class_4587 poseStack, class_4597 multiBufferSource, int i, int j) {
        renderByItemBlockState(((class_1747)(itemStack.method_7909())).method_7711().method_9564(), itemStack, displayContext, poseStack, multiBufferSource, i, j);
    }
    //?}
    //? if >=1.21.4 {
    @Override
    default class_1799 method_65695(class_1799 itemStack) {
        return itemStack;
    }

    default MapCodec<class_10515.class_10516> createUnbakedCodec(){
        return MapCodec.unit(new class_10515.class_10516(){

            //? if >=1.21.9 {
            /*@Override
            public @Nullable SpecialModelRenderer<?> bake(BakingContext bakingContext) {
                return IFactoryBlockEntityWLRenderer.this;
            }
            *///?} else {
            @Override
            public @Nullable class_10515<?> method_65698(class_5599 entityModelSet) {
                return IFactoryBlockEntityWLRenderer.this;
            }
            //?}

            @Override
            public MapCodec<? extends class_10516> method_65696() {
                return createUnbakedCodec();
            }
        });
    }

    //? if <1.21.9 {
    @Override
    default void render(@Nullable class_1799 object, class_811 itemDisplayContext, class_4587 poseStack, class_4597 multiBufferSource, int i, int j, boolean bl) {
        renderByItem(object,itemDisplayContext,poseStack,multiBufferSource,i,j);
    }
    //?}
    //?}
}

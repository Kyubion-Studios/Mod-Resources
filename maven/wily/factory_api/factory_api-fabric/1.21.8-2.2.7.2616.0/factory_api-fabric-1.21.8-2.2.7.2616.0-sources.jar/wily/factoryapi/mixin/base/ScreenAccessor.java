package wily.factoryapi.mixin.base;

import net.minecraft.class_2558;
import net.minecraft.class_310;
import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_437.class)
public interface ScreenAccessor {
	//? if >=1.21.6 {
	@Invoker
	static void callDefaultHandleGameClickEvent(class_2558 clickEvent, class_310 minecraft, class_437 screen) {
		throw new UnsupportedOperationException();
	}
	//?}
}

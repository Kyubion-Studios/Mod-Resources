package wily.factoryapi.base;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;

public interface IFactoryBlock {
    default int getLightEmission(class_2680 state, class_1922 level, class_2338 pos) {
        return state.method_26213();
    }
    static int getBlockLuminance(class_2680 state, class_1922 level, class_2338 pos){
        return state.method_26204() instanceof IFactoryBlock b ? b.getLightEmission(state,level,pos): state.method_26213();
    }
}

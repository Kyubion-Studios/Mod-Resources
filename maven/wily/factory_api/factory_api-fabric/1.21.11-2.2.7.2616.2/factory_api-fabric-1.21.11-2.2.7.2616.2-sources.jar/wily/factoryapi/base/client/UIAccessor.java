package wily.factoryapi.base.client;

import com.mojang.blaze3d.systems.RenderSystem;
import org.jetbrains.annotations.Nullable;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIClient;
import wily.factoryapi.FactoryAPIPlatform;
import wily.factoryapi.base.ArbitrarySupplier;
import wily.factoryapi.base.Bearer;
import wily.factoryapi.util.FactoryScreenUtil;
import wily.factoryapi.util.VariableResolver;
import wily.factoryapi.util.VariablesMap;

import java.util.Collections;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import java.util.regex.Matcher;
import net.minecraft.class_1304;
import net.minecraft.class_1661;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_339;
import net.minecraft.class_364;
import net.minecraft.class_3936;
import net.minecraft.class_4068;
import net.minecraft.class_437;
import net.minecraft.class_642;
import net.minecraft.class_7919;
import net.minecraft.class_8021;

public interface UIAccessor extends UIDefinition, VariableResolver {
    static UIAccessor of(class_437 screen) {
        return (UIAccessor) screen;
    }

    static UIAccessor of(class_329 gui) {
        return (UIAccessor) gui;
    }

    @Nullable
    class_437 getScreen();

    default void reloadUI() {
        beforeInit();
        getChildrenRenderables().clear();
        afterInit();
    }

    boolean initialized();

    @Override
    default void beforeInit(UIAccessor accessor) {
        getElements().clear();
        class_310 minecraft = class_310.method_1551();
        putStaticElement("windowWidth", minecraft.method_22683().method_4489());
        putStaticElement("windowHeight", minecraft.method_22683().method_4506());
        putStaticElement("width", minecraft.method_22683().method_4486());
        putStaticElement("height", minecraft.method_22683().method_4502());
        getElements().put("hasScreen", ()-> FactoryAPIClient.getScreen() != null);
        if (getChildrenRenderables() != null)
            getElements().put("renderablesCount", getChildrenRenderables()::size);
        FactoryAPIPlatform.getMods().forEach(i -> putStaticElement("loadedMods." + i.getId(), true));
        class_642 serverData = minecraft.method_1558();
        if (serverData != null)
            putStaticElement("serverIp."+serverData.field_3761,true);
        class_1661 inventory = minecraft.field_1724 == null ? null : minecraft.field_1724.method_31548();
        if (inventory != null) {
            List<class_1799> items = inventory./*? if >1.21.4 {*/method_67533()/*?} else {*//*items*//*?}*/;
            for (int i = 0; i < items.size(); i++) {
                int index = i;
                getElements().put("inventory." + index, () -> items.get(index));
            }
            //? if >1.21.4 {
            class_1661.field_56551.forEach((i, equipmentSlot)->{
                if (equipmentSlot == class_1304.field_6171) return;
                getElements().put("inventory.armor." + equipmentSlot.method_5927(), () -> inventory.method_5438(i));
            });
            //?} else {
            /*for (int i = 0; i < inventory.armor.size(); i++) {
                int index = i;
                getElements().put("inventory.armor." + index, () -> inventory.armor.get(index));
            }
            *///?}
            getElements().put("inventory.offhand", () -> /*? if >1.21.4 {*/inventory.method_5438(class_1661.field_30639)/*?} else {*//*inventory.offhand.get(0)*//*?}*/);
        }
        putSupplierComponent("username", () -> class_2561.method_43470(minecraft.method_1548().method_1676()));
        if (getScreen() instanceof class_3936<?> access) {
            getElements().put("slotsCount", access.method_17577().field_7761::size);
            for (class_1735 slot : access.method_17577().field_7761) {
                getElements().put("menu.slot." + slot.method_34266(), slot::method_7677);
            }
        }
        getDefinitions().clear();
        FactoryAPIClient.uiDefinitionManager.applyStatic(accessor);
        getDefinitions().addAll(getStaticDefinitions());
        FactoryAPIClient.uiDefinitionManager.apply(accessor);
        UIDefinition.super.beforeInit(accessor);
    }

    default void beforeInit() {
        beforeInit(this);
    }

    default void afterInit() {
        afterInit(this);
        if (FactoryOptions.UI_DEFINITION_LOGGING.get()) {
            FactoryAPI.LOGGER.warn(getElements());
        }
    }

    default void beforeTick() {
        beforeTick(this);
    }

    default void afterTick() {
        afterTick(this);
    }

    List<class_364> getChildren();

    List<class_4068> getChildrenRenderables();

    <T extends class_364> T removeChild(T widget);

    <T extends class_364> T addChild(int renderableIndex, T listener, boolean isRenderable, boolean isNarratable);

    default <T extends class_364> T addChild(int renderableIndex, T listener) {
        return addChild(renderableIndex, listener, true, true);
    }

    default <T extends class_364> T addChild(String name, T listener) {
        return addChild(getInteger(name + ".order", getChildrenRenderables().size()), listener);
    }

    default <T extends class_4068> T addRenderable(T renderable) {
        return addRenderable(getChildrenRenderables().size(), renderable);
    }

    default <T extends class_4068> T addRenderable(int index, T renderable) {
        getChildrenRenderables().add(Math.min(Math.max(0, index), getChildrenRenderables().size()), renderable);
        return renderable;
    }

    default <T extends class_4068> T addRenderable(String name, T renderable) {
        return addRenderable(getInteger(name + ".order", getChildrenRenderables().size()), renderable);
    }

    VariablesMap<String, ArbitrarySupplier<?>> getElements();

    default <E> E putStaticElement(String name, E e) {
        getElements().put(name, ArbitrarySupplier.of(e));
        return e;
    }

    default <E> E putBearer(String name, Bearer<E> e, Function<Object, E> convertOldValue) {
        ArbitrarySupplier<?> oldElement = getElements().put(name, e);
        if (oldElement != null) oldElement.map(convertOldValue::apply).ifPresent(e::set);
        return e.get();
    }

    default <E> E putBearer(String name, Bearer<E> e) {
        return putBearer(name, e, o -> (E) o);
    }

    default Integer putIntegerBearer(String name, Bearer<Integer> e) {
        return putBearer(name, e, o -> o instanceof Number n ? Integer.valueOf(n.intValue()) : o instanceof String s ? Integer.parseInt(s) : null);
    }

    default <E extends class_339> E putWidget(String name, E e) {
        putBearer(name + ".message", Bearer.of(e::method_25369, e::method_25355));
        getElement(name + ".tooltip", class_2561.class).ifPresent(c-> e.method_47400(class_7919.method_47407(c)));
        putBearer(name + ".spriteOverride", Bearer.of(WidgetAccessor.of(e)::getSpriteOverride, WidgetAccessor.of(e)::setSpriteOverride));
        putBearer(name + ".highlightedSpriteOverride", Bearer.of(WidgetAccessor.of(e)::getSpriteOverride, WidgetAccessor.of(e)::setHighlightedSpriteOverride));
        putBearer(name + ".onPressOverride", Bearer.of(WidgetAccessor.of(e)::getOnPressOverride, WidgetAccessor.of(e)::setOnPressOverride));
        WidgetAccessor.of(e).setVisibility(getElement(name + ".isVisible", Boolean.class));
        return putLayoutElement(name, e, e::method_25358, /*? if <=1.20.1 {*//*WidgetAccessor.of(e)*//*?} else {*/e/*?}*/::method_53533);
    }

    default class_2561 putComponent(String name, class_2561 component) {
        putStaticElement(name, component);
        putStaticElement(name + ".width", class_310.method_1551().field_1772.method_27525(component));
        return component;
    }

    default void putSupplierComponent(String name, ArbitrarySupplier<class_2561> component) {
        getElements().put(name, component);
        getElements().put(name+".width", component.map(c->class_310.method_1551().field_1772.method_27525(c)));
    }

    default class_243 putVec3(String name, class_243 vec3) {
        putStaticElement(name, vec3);
        putStaticElement(name + ".x", vec3.method_10216());
        putStaticElement(name + ".y", vec3.method_10214());
        putStaticElement(name + ".z", vec3.method_10215());
        return vec3;
    }

    default class_241 putVec2(String name, class_241 offset) {
        putStaticElement(name, offset);
        putStaticElement(name + ".x", offset.field_1343);
        putStaticElement(name + ".y", offset.field_1342);
        return offset;
    }

    default class_4068 createModifiableRenderable(String name, class_4068 renderable) {
        return (guiGraphics, i, j, f) -> {
            int amount = getInteger(name+".amount", 1);
            for (int i1 = 0; i1 < amount; i1++) {
                if (getElements().get(name+".index") instanceof Bearer<?> b) b.secureCast(Integer.class).set(i1);
                FactoryGuiMatrixStack.of(guiGraphics.method_51448()).pushPose();
                int color = getInteger(name+".renderColor", 0xFFFFFFFF);
                //? if <1.21.6 {
                /*FactoryScreenUtil.enableBlend();
                FactoryGuiGraphics.of(guiGraphics).setColor(color);
                *///?} else
                FactoryGuiGraphics.of(guiGraphics).setBlitColor(color);
                FactoryGuiMatrixStack.of(guiGraphics.method_51448()).translate(getDouble(name + ".translateX", 0), getDouble(name + ".translateY", 0), getDouble(name + ".translateZ", 0));
                FactoryGuiMatrixStack.of(guiGraphics.method_51448()).scale(getFloat(name + ".scaleX", 1), getFloat(name + ".scaleY", 1), getFloat(name + ".scaleZ", 1));
                //? if >26.1 {
                /*renderable.extractRenderState(guiGraphics, i, j, f);
                *///?} else {
                renderable.method_25394(guiGraphics, i, j, f);
                //?}
                FactoryGuiMatrixStack.of(guiGraphics.method_51448()).popPose();
                FactoryScreenUtil.disableBlend();
                //? if <1.21.6 {
                /*FactoryGuiGraphics.of(guiGraphics).clearColor();
                *///?} else
                FactoryGuiGraphics.of(guiGraphics).clearBlitColor();

            }
        };
    }

    default <E extends class_8021> E putLayoutElement(String name, E e, Consumer<Integer> setWidth, Consumer<Integer> setHeight) {
        putIntegerBearer(name + ".x", Bearer.of(e::method_46426, e::method_46421));
        putIntegerBearer(name + ".y", Bearer.of(e::method_46427, e::method_46419));
        putIntegerBearer(name + ".width", Bearer.of(e::method_25368, setWidth));
        putIntegerBearer(name + ".height", Bearer.of(e::method_25364, setHeight));
        return putStaticElement(name, e);
    }

    default String replaceValidElementValues(String s) {
        getElements().updatePattern();
        Matcher matcher = getElements().getPattern().matcher(s);
        StringBuilder result = new StringBuilder();
        while (matcher.find()) {
            String key = matcher.group(1);
            matcher.appendReplacement(result, String.valueOf(getElements().get(key).get()));
        }
        matcher.appendTail(result);
        return result.toString();
    }

    default <V> ArbitrarySupplier<V> getElement(String name, Class<V> valueClass) {
        return getElements().getOrDefault(name, ArbitrarySupplier.empty()).secureCast(valueClass);
    }

    default ArbitrarySupplier<?> getElement(String name) {
        return getElements().getOrDefault(name, ArbitrarySupplier.empty());
    }

    default ArbitrarySupplier<Boolean> getBooleanElement(String name) {
        return getElement(name, Boolean.class);
    }

    default ArbitrarySupplier<Integer> getIntegerElement(String name) {
        return getElement(name, Number.class).map(Number::intValue);
    }

    default <V> V getElementValue(String name, V defaultValue, Class<V> valueClass) {
        ArbitrarySupplier<?> element = getElements().get(name);
        Object value;
        return element != null && valueClass.isInstance(value = element.get()) ? valueClass.cast(value) : defaultValue;
    }

    default int getInteger(String name, int defaultValue) {
        return getElementValue(name, defaultValue, Number.class).intValue();
    }

    default double getDouble(String name, double defaultValue) {
        return getElementValue(name, defaultValue, Number.class).doubleValue();
    }

    default float getFloat(String name, float defaultValue) {
        return getElementValue(name, defaultValue, Number.class).floatValue();
    }

    default Boolean getBoolean(String name, Boolean defaultValue) {
        return getElementValue(name, defaultValue, Boolean.class);
    }

    default Boolean getBoolean(String name) {
        return getBoolean(name, false);
    }

    default net.minecraft.class_2960 getResourceLocation(String name, net.minecraft.class_2960 defaultValue) {
        return getElementValue(name, defaultValue, net.minecraft.class_2960.class);
    }

    default net.minecraft.class_2960 getResourceLocation(String name) {
        return getResourceLocation(name, null);
    }

    default class_1799 getItemStack(String name) {
        return getElementValue(name, class_1799.field_8037, class_1799.class);
    }

    default class_1799 getItemStack(String name, class_1799 defaultValue) {
        return getElementValue(name, defaultValue, class_1799.class);
    }

    default class_2561 getComponent(String name, class_2561 defaultValue) {
        return getElementValue(name, defaultValue, class_2561.class);
    }

    default class_2561 getComponent(String name) {
        return getComponent(name, null);
    }

    default class_243 getVec3(String name, class_243 defaultValue) {
        return getElementValue(name, defaultValue, class_243.class);
    }

    default class_243 getVec3(String name) {
        return getVec3(name, null);
    }

    @Override
    default Number getNumber(String name, Number defaultValue) {
        return getElementValue(name, defaultValue, Number.class);
    }

    static UIAccessor createRenderablesWrapper(UIAccessor accessor, List<class_4068> renderables) {
        return new UIAccessor() {
            @Override
            public @Nullable class_437 getScreen() {
                return accessor.getScreen();
            }

            @Override
            public List<UIDefinition> getDefinitions() {
                return accessor.getDefinitions();
            }

            @Override
            public void reloadUI() {
                accessor.reloadUI();
            }

            @Override
            public boolean initialized() {
                return accessor.initialized();
            }

            @Override
            public List<UIDefinition> getStaticDefinitions() {
                return accessor.getStaticDefinitions();
            }

            @Override
            public List<class_364> getChildren() {
                return Collections.emptyList();
            }

            @Override
            public List<class_4068> getChildrenRenderables() {
                return renderables;
            }

            @Override
            public <T extends class_364> T removeChild(T widget) {
                if (widget instanceof class_4068) renderables.remove(widget);
                return widget;
            }

            @Override
            public <T extends class_364> T addChild(int renderableIndex, T listener, boolean isRenderable, boolean isNarratable) {
                if (isRenderable && listener instanceof class_4068 r) renderables.add(renderableIndex, r);
                return listener;
            }

            @Override
            public VariablesMap<String, ArbitrarySupplier<?>> getElements() {
                return accessor.getElements();
            }
        };
    }
}

package wily.factoryapi.mixin.base;

import net.minecraft.class_1792;
//? if forge {
/*import net.minecraftforge.client.extensions.common.IClientItemExtensions;
*///?} else if neoforge {
/*import net.neoforged.neoforge.client.extensions.common.IClientItemExtensions;
*///?}
import org.jetbrains.annotations.NotNull;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wily.factoryapi.base.IFactoryItem;
import wily.factoryapi.base.client.IFactoryItemClientExtension;

@Mixin(class_1792.class)
public class ClientItemMixin {

    //? if forge || neoforge && <1.20.5
    /*@Shadow(remap = false) private Object renderProperties;*/

    @Inject(method = "<init>", at = @At("RETURN"))
    private void init(class_1792.class_1793 arg, CallbackInfo ci){
        if (this instanceof IFactoryItem i){
            i.clientExtension(c-> {
                IFactoryItemClientExtension.map.put((class_1792)(Object)this,c);
                //? if forge || neoforge && <1.20.5 {
                /*renderProperties = new IClientItemExtensions() {
                    @Override
                    public @NotNull HumanoidModel<?> getHumanoidArmorModel(/^? if >1.21.2 {^//^LivingEntityRenderState livingEntityRenderState ^//^?} else {^/LivingEntity livingEntity/^?}^/, ItemStack itemStack, EquipmentSlot equipmentSlot, HumanoidModel<?> original) {
                        return c.getHumanoidArmorModel(/^? if >1.21.2 {^//^livingEntityRenderState ^//^?} else {^/livingEntity/^?}^/,itemStack,equipmentSlot,original);
                    }
                };
                *///?}
            });
        }
    }
}
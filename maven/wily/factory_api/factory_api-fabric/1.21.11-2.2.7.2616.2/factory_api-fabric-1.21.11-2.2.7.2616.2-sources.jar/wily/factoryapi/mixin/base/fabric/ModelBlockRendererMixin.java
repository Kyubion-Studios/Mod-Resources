//? if fabric {
package wily.factoryapi.mixin.base.fabric;

import com.llamalad7.mixinextras.injector.ModifyExpressionValue;
import com.llamalad7.mixinextras.sugar.Local;
import net.minecraft.class_1920;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_778;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import wily.factoryapi.base.IFactoryBlock;

@Mixin(class_778.class )
public class ModelBlockRendererMixin {
    @ModifyExpressionValue(method = "tesselateBlock", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/block/state/BlockState;getLightEmission()I"))
    private int render(int original, @Local(argsOnly = true) class_1920 level, @Local(argsOnly = true) class_2680 state, @Local(argsOnly = true) class_2338 pos) {
        return state.method_26204() instanceof IFactoryBlock block ? block.getLightEmission(state,level,pos) : original;
    }
}
//?}
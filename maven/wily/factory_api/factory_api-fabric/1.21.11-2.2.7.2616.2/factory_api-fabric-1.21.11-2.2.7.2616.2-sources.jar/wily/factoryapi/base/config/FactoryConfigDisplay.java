package wily.factoryapi.base.config;

import wily.factoryapi.util.FactoryComponents;

import java.util.function.BiFunction;
import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_5244;

public interface FactoryConfigDisplay<T> {
    class_2561 name();

    Function<T, class_2561> tooltip();

    @Deprecated
    BiFunction<class_2561, T, class_2561> captionFunction();

    Function<T, class_2561> valueToComponent();

    BiFunction<FactoryConfigDisplay<T>, T, class_2561> messageFunction();

    default class_2561 getMessage(T value) {
        return messageFunction().apply(this, value);
    }

    static Instance<Boolean> createToggle(class_2561 name, Function<Boolean, class_2561> tooltip) {
        return toggleBuilder().tooltip(tooltip).build(name);
    }

    static Instance<Boolean> createToggle(class_2561 name) {
        return toggleBuilder().build(name);
    }

    record Instance<T>(class_2561 name, Function<T, class_2561> tooltip, Function<T, class_2561> valueToComponent, BiFunction<FactoryConfigDisplay<T>, T, class_2561> messageFunction, BiFunction<class_2561, T, class_2561> captionFunction) implements FactoryConfigDisplay<T> {
        public Instance(class_2561 name, Function<T, class_2561> tooltip, Function<T, class_2561> valueToComponent, BiFunction<FactoryConfigDisplay<T>, T, class_2561> messageFunction) {
            this(name, tooltip, valueToComponent, messageFunction, (n, value) -> valueToComponent.apply(value));
        }

        @Deprecated
        public Instance(class_2561 name, Function<T, class_2561> tooltip, BiFunction<class_2561, T, class_2561> captionFunction) {
            this(name, tooltip, t -> class_2561.method_43470(t.toString()), (display, value) -> captionFunction.apply(display.name(), value), captionFunction);
        }

        @Deprecated
        public Instance(class_2561 name, BiFunction<class_2561, T, class_2561> captionFunction) {
            this(name, v -> null, captionFunction);
        }

        @Deprecated
        public Instance(class_2561 name, Function<T, class_2561> tooltip) {
            this(name, tooltip, (c, v) -> c);
        }

        @Deprecated
        public Instance(class_2561 name) {
            this(name, (c, v) -> c);
        }
    }

    class Builder<T> {
        private Function<T, class_2561> valueToComponent = t -> class_2561.method_43470(t.toString());
        private BiFunction<FactoryConfigDisplay<T>, T, class_2561> messageFunction = (display, t) -> class_5244.method_32700(display.name(), display.valueToComponent().apply(t));
        private Function<T, class_2561> tooltip = value -> null;

        public Builder<T> valueToComponent(Function<T, class_2561> valueToComponent) {
            this.valueToComponent = valueToComponent;
            return this;
        }

        public Builder<T> messageFunction(BiFunction<FactoryConfigDisplay<T>, T, class_2561> messageFunction) {
            this.messageFunction = messageFunction;
            return this;
        }

        public Builder<T> messageFunctionLabel(BiFunction<class_2561, class_2561, class_2561> messageFunction) {
            return messageFunction((display, t) -> messageFunction.apply(display.name(), display.valueToComponent().apply(t)));
        }

        public Builder<T> messageFunctionCaption(BiFunction<class_2561, T, class_2561> messageFunction) {
            return messageFunction((display, t) -> messageFunction.apply(display.name(), t));
        }

        public Builder<T> tooltip(Function<T, class_2561> tooltip) {
            this.tooltip = tooltip;
            return this;
        }

        public Instance<T> build(class_2561 name) {
            return new Instance<>(name, tooltip, valueToComponent, messageFunction);
        }
    }

    static <T> Builder<T> builder() {
        return new Builder<>();
    }

    static Builder<Boolean> toggleBuilder() {
        return new Builder<Boolean>().valueToComponent((b) -> b ? class_5244.field_24332 : class_5244.field_24333);
    }

    static Builder<Integer> intBuilder() {
        return builder();
    }

    static Builder<Integer> intPercentBuilder() {
        return intBuilder().messageFunctionLabel(FactoryComponents::percentValueLabel);
    }

    static Builder<Double> doubleBuilder() {
        return builder();
    }

    static Builder<Double> percentBuilder() {
        return doubleBuilder().valueToComponent(value -> class_2561.method_43470(String.valueOf((int) (value * 100)))).messageFunctionLabel(FactoryComponents::percentValueLabel);
    }
}

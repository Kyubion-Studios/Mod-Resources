//? if >=1.21.9 {
package wily.factoryapi.mixin.base;

import net.minecraft.class_382;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_382.class)
public interface BakedSheetGlyphAccessor {

    @Accessor("up")
    float getTop();

    @Accessor("down")
    float getBottom();
}
//?}

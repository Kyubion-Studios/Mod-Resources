package wily.factoryapi.base;

import net.minecraft.class_2561;
import net.minecraft.class_3542;

public enum TransportState implements class_3542 {
    EXTRACT("extract"),
    INSERT("insert"),
    EXTRACT_INSERT("extract_insert"),
    NONE("none");

    private final String name;

    TransportState(String string2) {
        this.name = string2;
    }

    public String toString() {
        return this.method_15434();
    }

    public static TransportState byOrdinal(int ordinal) {
        return values()[ordinal];
    }

    public String method_15434() {
        return this.name;
    }
    public class_2561 getTooltip(){
        return class_2561.method_43471("tooltip.factory_api.config.transport." + name);
    }

    public boolean isUsable() {
        return this != NONE;
    }

    public boolean canInsert() {
        return this == INSERT || this == EXTRACT_INSERT;
    }
    public boolean canExtract() {
        return this == EXTRACT || this == EXTRACT_INSERT;
    }

    public TransportState next(){
        return values()[ordinal() >= values().length - 1 ? 0 :  ordinal() + 1];
    }

    public static TransportState ofBoolean(boolean canExtract, boolean canInsert){
        if (!canInsert && canExtract) return EXTRACT;
        if (!canExtract && canInsert) return INSERT;
        if (canExtract) return EXTRACT_INSERT;
        return  NONE;
    }


}

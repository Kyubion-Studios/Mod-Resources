//? if fabric {
package wily.factoryapi.mixin.base.fabric;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wily.factoryapi.base.IFactoryBlock;

import java.util.function.BiConsumer;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2791;

@Mixin(class_2791.class)
public class ChunkAccessMixin {

    @Inject( at = @At( value = "HEAD"), method = "findBlockLightSources", cancellable = true)
    private void getLightSourcesStream(BiConsumer<class_2338, class_2680> biConsumer, CallbackInfo ci ) {
        class_2791 chunk = (class_2791)(Object)(this);
        chunk.method_51525(blockState -> blockState.method_26204() instanceof IFactoryBlock || blockState.method_26213() != 0,((blockPos, state) -> {if (!(state.method_26204() instanceof IFactoryBlock b) || b.getLightEmission(state,chunk,blockPos) != 0) biConsumer.accept(blockPos,state);}));
        ci.cancel();
    }
}
//?}

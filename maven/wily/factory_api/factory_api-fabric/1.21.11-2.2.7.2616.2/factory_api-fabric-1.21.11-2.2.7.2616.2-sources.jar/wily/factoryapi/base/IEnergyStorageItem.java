package wily.factoryapi.base;

import net.minecraft.class_1799;
import wily.factoryapi.FactoryAPIPlatform;


public interface IEnergyStorageItem<T extends IPlatformEnergyStorage> extends IFactoryItem
{
   default T getEnergyStorage(class_1799 stack){
      return (T) FactoryAPIPlatform.getItemEnergyStorage(stack);
   }
   default int getMaxConsume(){
      return getCapacity();
   }
   default int getMaxReceive(){
      return getCapacity();
   }

   int getCapacity();

   default TransportState getTransport(){
    return TransportState.EXTRACT_INSERT;
   }
   default <T extends IPlatformHandler> ArbitrarySupplier<T> getStorage(FactoryStorage<T> storage, class_1799 stack) {
      if (storage == FactoryStorage.ENERGY) return ()-> (T) new FactoryItemEnergyStorage(stack,0,getCapacity(), getMaxConsume(), getMaxReceive(),getTransport());
      return ()->null;
   }
}
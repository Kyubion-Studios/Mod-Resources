package wily.factoryapi.base.client.drawable;

import wily.factoryapi.util.FactoryScreenUtil;

import java.util.function.Function;
import net.minecraft.class_2561;

public class FactoryDrawableSlider extends AbstractDrawableButton<FactoryDrawableSlider> {
    private final DrawableCustomWidth<?> sliderBackground;
    public int value;
    public final int maxValue;

    public int relativePosX = 0;

    public boolean dragging = false;

    protected Function<FactoryDrawableSlider,class_2561> customText;

    public FactoryDrawableSlider(int x, int y, Function<FactoryDrawableSlider,class_2561> customText, IFactoryDrawableType buttonImage, IFactoryDrawableType sliderBackground, int buttonWidth, int sliderWidth, int initialValue, int maxValue) {
        super(x, y, buttonImage);
        this.customText = customText;
        this.sliderBackground = new DrawableCustomWidth<>(sliderBackground);
        this.sliderBackground.customWidth = sliderWidth;
        this.value = initialValue;
        this.maxValue = maxValue;
        customWidth = buttonWidth;
    }

    public FactoryDrawableSlider(int x, int y, Function<FactoryDrawableSlider,class_2561> customText, IFactoryDrawableType buttonImage, int buttonWidth, int sliderWidth, int initialValue, int maxValue) {
        this(x, y, customText, buttonImage,IFactoryDrawableType.create(buttonImage.texture(),buttonImage.uvX() + buttonImage.width(), buttonImage.uvY(), sliderWidth, buttonImage.height()),buttonWidth,sliderWidth, initialValue,maxValue);
    }

    public int getValue() {
        return value;
    }

    public float getPercentage(){
        return (float)value / maxValue;
    }


    @Override
    public boolean handleClick(double d, double e, int i) {
        if (inMouseLimit(d,e)){
            if (!inButtonLimit(d,e)) value = getActualValue(d);
        }
        return super.handleClick(d, e, i);
    }

    protected int getActualValue(double mouseX){
        return Math.round(Math.max(0,Math.min(((float)mouseX - method_3321()) / sliderBackground.width() * maxValue, maxValue)));
    }

    @Override
    public boolean handleRelease(double d, double e, int i) {
        selected = dragging = false;
        return false;
    }

    @Override
    public boolean handleDragging(double mouseX, double mouseY, int i, double f, double g) {
        if (!visible.get()) return false;
        if (inButtonLimit(mouseX,mouseY) || dragging) {
            selected = dragging = true;
            value = getActualValue(mouseX);
            onPress.accept(this,i);
            return true;
        }
        return false;
    }

    @Override
    public boolean inMouseLimit(double mouseX, double mouseY) {
        return sliderBackground.inMouseLimit((int) mouseX, (int) mouseY,method_3321(),method_3322());
    }

    public boolean inButtonLimit(double mouseX, double mouseY){
        return FactoryScreenUtil.isMouseOver(mouseX,mouseY,relativePosX,method_3322(),width(),height());
    }

    @Override
    public void draw(net.minecraft.class_332 graphics) {
        if (dragging) selected = true;
        sliderBackground.draw(graphics,method_3321(),method_3322());
        class_2561 comp = customText.apply(this);
        if (comp != null && !comp.getString().isEmpty()) {
            //? if >=26.1 {
            /*graphics.text(mc.font, comp,  getX() + (sliderBackground.width() - mc.font.width(comp.getString())) / 2, getY() + height() / 2 - 4, -1);
            *///?} else {
            graphics.method_27535(mc.field_1772, comp,  method_3321() + (sliderBackground.width() - mc.field_1772.method_1727(comp.getString())) / 2, method_3322() + height() / 2 - 4, -1);
            //?}
        }
        relativePosX = (int) (method_3321() + getPercentage() * (sliderBackground.width() - width()));
        draw(graphics, relativePosX, method_3322());
    }
}

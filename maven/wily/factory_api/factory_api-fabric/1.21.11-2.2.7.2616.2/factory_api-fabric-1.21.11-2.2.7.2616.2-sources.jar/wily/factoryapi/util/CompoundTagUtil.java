package wily.factoryapi.util;

import java.util.Optional;
import net.minecraft.class_2487;

public class CompoundTagUtil {

    public static class_2487 getCompoundTagOrEmpty(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_68568(name)/*?} else {*//*tag.getCompound(name)*//*?}*/;
    }

    public static Optional<class_2487> getCompoundTag(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10562(name)/*?} else {*//*tag.contains(name) ? Optional.of(tag.getCompound(name)) : Optional.empty()*//*?}*/;
    }

    public static Optional<Boolean> getBoolean(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10577(name)/*?} else {*//*tag.contains(name) ? Optional.of(tag.getBoolean(name)): Optional.empty()*//*?}*/;
    }

    public static Optional<Byte> getByte(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10571(name)/*?} else {*//*tag.contains(name) ? Optional.of(tag.getByte(name)) : Optional.empty()*//*?}*/;
    }

    public static Optional<Integer> getInt(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10550(name)/*?} else {*//*tag.contains(name) ? Optional.of(tag.getInt(name)) : Optional.empty()*//*?}*/;
    }

    public static Optional<Long> getLong(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10537(name)/*?} else {*//*tag.contains(name) ? Optional.of(tag.getLong(name)) : Optional.empty()*//*?}*/;
    }

    public static Optional<Float> getFloat(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10583(name)/*?} else {*//*tag.contains(name) ? Optional.of(tag.getFloat(name)) : Optional.empty()*//*?}*/;
    }

    public static Optional<Double> getDouble(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10574(name)/*?} else {*//*tag.contains(name) ? Optional.of(tag.getDouble(name)) : Optional.empty()*//*?}*/;
    }

    public static Optional<byte[]> getByteArray(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10547(name)/*?} else {*//*tag.contains(name) ? Optional.of(tag.getByteArray(name)) : Optional.empty()*//*?}*/;
    }

    public static Optional<int[]> getIntArray(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10561(name)/*?} else {*//*tag.contains(name) ? Optional.of(tag.getIntArray(name)) : Optional.empty()*//*?}*/;
    }

    public static Optional<long[]> getLongArray(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10565(name)/*?} else {*//*tag.contains(name) ? Optional.of(tag.getLongArray(name)) : Optional.empty()*//*?}*/;
    }

    public static byte[] getByteArrayOrEmpty(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10547(name).orElseGet(()->new byte[0])/*?} else {*//*tag.getByteArray(name)*//*?}*/;
    }

    public static int[] getIntArrayOrEmpty(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10561(name).orElseGet(()->new int[0])/*?} else {*//*tag.getIntArray(name)*//*?}*/;
    }

    public static long[] getLongArrayOrEmpty(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10565(name).orElseGet(()->new long[0])/*?} else {*//*tag.getLongArray(name)*//*?}*/;
    }

    public static Optional<String> getString(class_2487 tag, String name){
        return /*? if >1.21.4 {*/tag.method_10558(name)/*?} else {*//*tag.contains(name) ? Optional.of(tag.getString(name)) : Optional.empty()*//*?}*/;
    }
}

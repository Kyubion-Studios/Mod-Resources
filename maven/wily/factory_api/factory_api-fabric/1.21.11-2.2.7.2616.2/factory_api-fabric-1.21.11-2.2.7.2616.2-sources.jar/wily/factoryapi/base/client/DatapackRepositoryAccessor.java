package wily.factoryapi.base.client;

import net.minecraft.class_3283;

public interface DatapackRepositoryAccessor {
    class_3283 getDatapackRepository();
    void tryApplyNewDataPacks(class_3283 repository);
}

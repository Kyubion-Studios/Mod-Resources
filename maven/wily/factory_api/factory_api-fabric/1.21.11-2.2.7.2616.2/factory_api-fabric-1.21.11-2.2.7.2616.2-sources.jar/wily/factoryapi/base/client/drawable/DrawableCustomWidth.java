package wily.factoryapi.base.client.drawable;

import wily.factoryapi.base.client.FactoryGuiGraphics;

public class DrawableCustomWidth<D extends DrawableCustomWidth<D>> extends AbstractDrawableStatic<D,IFactoryDrawableType> {
    public Integer customWidth;
    public DrawableCustomWidth(IFactoryDrawableType drawable, int posX, int posY) {
        super(drawable, posX, posY);
    }
    public DrawableCustomWidth(IFactoryDrawableType drawable) {
        super(drawable, 0, 0);
    }
    @Override
    public int method_3319() {
        return customWidth != null ? customWidth : super.method_3319();
    }

    @Override
    public void draw(net.minecraft.class_332 graphics, int x, int y) {
        super.draw(graphics, x, y);
        if (customWidth != null && !isSprite()) FactoryGuiGraphics.of(graphics).blit(texture(),x + width() - 2, y, uvX() + drawable.width() - 2, uvY(), 2,height());
    }
}

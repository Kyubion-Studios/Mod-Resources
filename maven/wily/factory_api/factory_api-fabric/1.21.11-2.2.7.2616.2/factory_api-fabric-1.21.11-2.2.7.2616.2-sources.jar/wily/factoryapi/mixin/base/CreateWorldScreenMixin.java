package wily.factoryapi.mixin.base;

import com.mojang.datafixers.util.Pair;
import org.jetbrains.annotations.Nullable;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wily.factoryapi.base.client.DatapackRepositoryAccessor;
import wily.factoryapi.base.client.UIAccessor;

import java.nio.file.Path;
import java.util.function.Consumer;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_3283;
import net.minecraft.class_437;
import net.minecraft.class_525;
import net.minecraft.class_7712;
import net.minecraft.class_8089;
import net.minecraft.class_8100;

@Mixin(class_525.class)
public abstract class CreateWorldScreenMixin extends class_437 implements DatapackRepositoryAccessor {
    protected CreateWorldScreenMixin(class_2561 arg) {
        super(arg);
    }

    @Shadow @Nullable
    protected abstract Pair<Path, class_3283> getDataPackSelectionSettings(class_7712 arg);

    @Shadow @Final private class_8100 uiState;

    @Shadow protected abstract void tryApplyNewDataPacks(class_3283 arg, boolean bl, Consumer<class_7712> consumer);


    @Shadow @Nullable private class_8089 tabNavigationBar;

    @Inject(method = "init", at = @At("RETURN"))
    public void init(CallbackInfo ci) {
        if (tabNavigationBar == null) return;
        UIAccessor.of(this).getElements().put("currentTabIndex", ((TabNavigationBarAccessor)tabNavigationBar)::getCurrentTabIndex);
    }

    @Override
    public class_3283 getDatapackRepository() {
        return getDataPackSelectionSettings(uiState.method_48728().comp_1030()).getSecond();
    }

    @Override
    public void tryApplyNewDataPacks(class_3283 repository) {
        tryApplyNewDataPacks(repository, false, data -> {
            if (this instanceof UIAccessor accessor) class_310.method_1551().method_1507(accessor.getScreen());
        });
    }
}

//? if >=1.21.2 {
package wily.factoryapi.mixin.base;

import it.unimi.dsi.fastutil.objects.Object2IntSortedMap;
import net.minecraft.class_1792;
import net.minecraft.class_9895;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_9895.class)
public interface FuelValuesAccessor {
    @Accessor
    Object2IntSortedMap<class_1792> getValues();
}
//?}

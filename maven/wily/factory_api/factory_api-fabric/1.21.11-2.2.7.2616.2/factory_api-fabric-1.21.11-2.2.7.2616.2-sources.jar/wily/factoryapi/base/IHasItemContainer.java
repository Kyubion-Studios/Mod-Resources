package wily.factoryapi.base;

import net.minecraft.class_1799;

public interface IHasItemContainer {
    class_1799 getContainer();
}

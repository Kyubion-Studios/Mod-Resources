package wily.factoryapi.base;

import org.jetbrains.annotations.Nullable;
import wily.factoryapi.base.client.IFactoryItemClientExtension;

import java.util.function.Consumer;
import net.minecraft.class_1304;
import net.minecraft.class_1799;
import net.minecraft.class_5321;
import net.minecraft.class_9334;

public interface IFactoryItem {
    default <T extends IPlatformHandler> ArbitrarySupplier<T> getStorage(FactoryStorage<T> storage, class_1799 stack){
        return ()->null;
    }

    //? if <1.21.2 {
    /*default @Nullable String getArmorTexture(ItemStack stack, Entity entity, EquipmentSlot slot) {
        net.minecraft.resources.Identifier texture = getArmorLocation(stack,entity,slot);
        return texture == null ? null : texture.toString();
    }
    *///?}

    default @Nullable net.minecraft.class_2960 getArmorLocation(class_1799 stack, /*? if <1.21.2 {*//*Entity entity, *//*?}*/ class_1304 slot) {
        return /*? if <1.21.2 {*//*null *//*?} else if <1.21.4 {*/ /*stack.get(DataComponents.EQUIPPABLE).model().orElse(null)*//*?} else {*/stack.method_58694(class_9334.field_54196).comp_3176().map(class_5321::/*? if <1.21.11 {*//*location*//*?} else {*/method_29177/*?}*/).orElse(null)/*?}*/;
    }

    default void clientExtension(Consumer<IFactoryItemClientExtension> clientExtensionConsumer){
    }
}

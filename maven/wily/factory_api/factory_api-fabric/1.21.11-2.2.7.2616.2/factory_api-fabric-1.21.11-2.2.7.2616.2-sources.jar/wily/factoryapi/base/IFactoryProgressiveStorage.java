package wily.factoryapi.base;

import org.jetbrains.annotations.Nullable;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_2487;

public interface IFactoryProgressiveStorage extends IFactoryExpandedStorage {
    default boolean hasProgress(){
        return !getProgresses().isEmpty();
    }
    default List<Progress> getProgresses(){
        return Collections.emptyList();
    }
    default @Nullable Progress getProgressByType(Progress.Identifier identifier){
        for (Progress p : getProgresses()) {
            if (p.identifier == identifier) return p;
        }
        return null;
    }


    @Override
    default void loadTag(class_2487 compoundTag) {
        IFactoryExpandedStorage.super.loadTag(compoundTag);
        if(hasProgress()) {getProgresses().forEach(p -> p.deserializeTag(compoundTag));}
    }
    @Override
    default void saveTag(class_2487 compoundTag) {
        IFactoryExpandedStorage.super.saveTag(compoundTag);
        if(hasProgress()) {getProgresses().forEach(p -> compoundTag.method_10543(p.serializeTag()));}
    }
}

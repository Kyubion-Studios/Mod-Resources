package wily.factoryapi.util;

import wily.factoryapi.base.*;

import java.util.function.Function;
import net.minecraft.class_2350;

public class StorageUtil {
    public static void transferEnergyTo(IFactoryStorage fromStorage, class_2350 d, ICraftyEnergyStorage energyReceiver){
        transferEnergyTo(fromStorage,c->c,c->c,d,energyReceiver);
    }
    public static void transferEnergyFrom(IFactoryStorage fromStorage, class_2350 d, ICraftyEnergyStorage energyConsumer){
       transferEnergyFrom(fromStorage,c->c,c->c,d,energyConsumer);
    }
    public static void transferEnergyTo(IFactoryStorage fromStorage, Function<CraftyTransaction,CraftyTransaction> transferFunction, Function<CraftyTransaction,CraftyTransaction> consumeFunction, class_2350 d, ICraftyEnergyStorage energyReceiver){
        fromStorage.getStorage(FactoryStorage.CRAFTY_ENERGY,d).ifPresent((e)-> {
            CraftyTransaction transaction1 = e.consumeEnergy(transferFunction.apply(new CraftyTransaction(e.getMaxConsume(), e.getStoredTier())), true);
            e.consumeEnergy(consumeFunction.apply(energyReceiver.receiveEnergy(transaction1, false)),false);
        });
    }
    public static void transferEnergyFrom(IFactoryStorage fromStorage, Function<CraftyTransaction,CraftyTransaction> transferFunction, Function<CraftyTransaction,CraftyTransaction> consumeFunction, class_2350 d, ICraftyEnergyStorage energyConsumer){
        fromStorage.getStorage(FactoryStorage.CRAFTY_ENERGY,d).ifPresent((e)-> {
            CraftyTransaction transaction = energyConsumer.consumeEnergy(transferFunction.apply(new CraftyTransaction(energyConsumer.getMaxConsume(), energyConsumer.getStoredTier())), true);
            energyConsumer.consumeEnergy(consumeFunction.apply(e.receiveEnergy(transaction,false)),false);
        });
    }
    public static void transferFluidTo(IFactoryStorage fromStorage, class_2350 d, IPlatformFluidHandler fluidFiller){
        transferFluidTo(fromStorage,c->c,d,fluidFiller);
    }
    public static void transferFluidFrom(IFactoryStorage toStorage, class_2350 d, IPlatformFluidHandler fluidFiller){
        transferFluidFrom(toStorage,c->c,d,fluidFiller);
    }
    public static void transferFluidTo(IFactoryStorage fromStorage, Function<FluidInstance,FluidInstance> transaction, class_2350 d, IPlatformFluidHandler fluidFiller){
        fromStorage.getStorage(FactoryStorage.FLUID,d).ifPresent((e)-> e.drain(fluidFiller.fill(transaction.apply(e.getFluidInstance()), false), false));
    }
    public static void transferFluidFrom(IFactoryStorage toStorage, Function<FluidInstance,FluidInstance> transaction, class_2350 d, IPlatformFluidHandler fluidDrainer){
        toStorage.getStorage(FactoryStorage.FLUID,d).ifPresent((e)-> fluidDrainer.drain(e.fill(transaction.apply(fluidDrainer.getFluidInstance()),false), false));
    }
}

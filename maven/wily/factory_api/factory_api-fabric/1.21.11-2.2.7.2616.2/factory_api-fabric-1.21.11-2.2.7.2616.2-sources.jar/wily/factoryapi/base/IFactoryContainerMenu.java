package wily.factoryapi.base;

import net.minecraft.class_1657;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_2338;
import net.minecraft.class_2371;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import wily.factoryapi.util.FactoryItemUtil;

public interface IFactoryContainerMenu<T extends class_2586 & IFactoryExpandedStorage> {
    T getBlockEntity();
    default class_2338 getBlockPos(){
        return getBlockEntity().method_11016();
    }
    default class_2680 getBlockState(){
        return getBlockEntity().method_11010();
    }

    class_1657 getPlayer();

    class_2371<class_1735> getSlots();

    default void updateChanges(){

    }

    default class_1799 quickMoveStack(class_1657 player, int index) {
        class_1799 itemstack = class_1799.field_8037;

        int machineSlots = getBlockEntity().getSlots(player).size();
        int inventorySlots =  machineSlots + 27;
        int totalSlots =  machineSlots + 36;

        class_1735 slot = this.getSlots().get(index);
        if (slot.method_7681()) {
            class_1799 stack = slot.method_7677();
            itemstack = stack.method_7972();

            if (index < machineSlots) {
                if (!this.moveItemStackToSlot(stack, machineSlots, totalSlots, true)) {
                    return class_1799.field_8037;
                }
                slot.method_7670(stack, itemstack);
            } else if (!this.moveItemStackToSlot(stack, 0, machineSlots, false)){
                if (index < inventorySlots) {
                    if (!this.moveItemStackToSlot(stack, inventorySlots, totalSlots, true)) {
                        return class_1799.field_8037;
                    }
                } else if (index < totalSlots) {
                    if (!this.moveItemStackToSlot(stack, machineSlots, inventorySlots, false)) {
                        return class_1799.field_8037;
                    }
                }
                return class_1799.field_8037;
            }

            if (stack.method_7960()) {
                slot.method_7673(class_1799.field_8037);
            } else {
                slot.method_7668();
            }

            if (stack.method_7947() == itemstack.method_7947()) {
                return class_1799.field_8037;
            }

            slot.method_7667(player, stack);
        }

        return itemstack;
    }
    default boolean moveItemStackToSlot(class_1799 itemStack, int i, int j, boolean inclusive) {
        boolean bl2 = false;
        int k = i;
        if (inclusive) {
            k = j - 1;
        }

        class_1735 slot;
        class_1799 itemStack2;
        if (itemStack.method_7946()) {
            while(!itemStack.method_7960()) {
                if (inclusive) {
                    if (k < i) {
                        break;
                    }
                } else if (k >= j) {
                    break;
                }

                slot = getSlots().get(k);
                itemStack2 = slot.method_7677();
                if (!itemStack2.method_7960() && FactoryItemUtil.equalItems(itemStack, itemStack2) && slot.method_7680(itemStack)) {
                    int l = itemStack2.method_7947() + itemStack.method_7947();
                    if (l <= slot.method_7676(itemStack)) {
                        itemStack.method_7939(0);
                        itemStack2.method_7939(l);
                        slot.method_7668();
                        bl2 = true;
                    } else if (itemStack2.method_7947() < slot.method_7676(itemStack)) {
                        itemStack.method_7934(itemStack.method_7914() - itemStack2.method_7947());
                        itemStack2.method_7939(itemStack.method_7914());
                        slot.method_7668();
                        bl2 = true;
                    }
                }

                if (inclusive) {
                    --k;
                } else {
                    ++k;
                }
            }
        }

        if (!itemStack.method_7960()) {
            if (inclusive) {
                k = j - 1;
            } else {
                k = i;
            }

            while(true) {
                if (inclusive) {
                    if (k < i) {
                        break;
                    }
                } else if (k >= j) {
                    break;
                }

                slot = getSlots().get(k);
                itemStack2 = slot.method_7677();
                if (itemStack2.method_7960() && slot.method_7680(itemStack)) {
                    if (itemStack.method_7947() > slot.method_7675()) {
                        slot.method_7673(itemStack.method_7971(slot.method_7675()));
                    } else {
                        slot.method_7673(itemStack.method_7971(itemStack.method_7947()));
                    }

                    slot.method_7668();
                    bl2 = true;
                    break;
                }

                if (inclusive) {
                    --k;
                } else {
                    ++k;
                }
            }
        }
        return bl2;
    }
}

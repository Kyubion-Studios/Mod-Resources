package wily.factoryapi.mixin.base;

//?} else {
/*import net.minecraft.util.random.WeightedList;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.WeightedVariants;
*///?}
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import wily.factoryapi.base.client.FactoryOptions;

import java.util.List;
import java.util.function.Function;
import net.minecraft.class_1087;
import net.minecraft.class_1097;
import net.minecraft.class_6012;

@Mixin(/*? if >1.21.4 {*/class_1097/*?} else {*//*MultiVariant*//*?}*/.class)
public class MultiVariantMixin {
    //? if <1.21.5 {
    /*@Mutable
    @Shadow @Final private List<Variant> variants;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void init(List list, CallbackInfo ci) {
        if (!FactoryOptions.RANDOM_BLOCK_ROTATIONS.get()) {
            this.variants = List.of(variants.get(0));
        }
    }
    *///?} else {
    @Mutable
    @Shadow @Final private class_6012<class_1087> list;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void init(class_6012<class_1087> weightedList, CallbackInfo ci) {
        if (!FactoryOptions.RANDOM_BLOCK_ROTATIONS.get()) {
            this.list = class_6012.method_66214(list.method_34994().getFirst().comp_2542());
        }
    }
    //?}
}

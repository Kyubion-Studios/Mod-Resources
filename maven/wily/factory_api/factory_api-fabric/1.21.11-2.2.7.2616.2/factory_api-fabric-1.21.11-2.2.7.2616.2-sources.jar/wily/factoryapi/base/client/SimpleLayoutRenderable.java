package wily.factoryapi.base.client;

import wily.factoryapi.util.FactoryScreenUtil;

import java.util.function.Consumer;
import java.util.function.Function;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4068;
import net.minecraft.class_8021;

public abstract class SimpleLayoutRenderable implements class_4068, class_8021 {
    public int width;
    public int height;
    public int x;
    public int y;

    public SimpleLayoutRenderable() {
    }

    public SimpleLayoutRenderable(int width, int height){
        this.width = width;
        this.height = height;
    }

    public static SimpleLayoutRenderable create(Function<SimpleLayoutRenderable, class_4068> simpleRender){
        return new SimpleLayoutRenderable() {
            //? if >=26.1 {
            /*@Override
            public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a) {
                simpleRender.apply(this).extractRenderState(graphics, mouseX, mouseY, a);
            }
            *///?} else {
            @Override
            public void method_25394(class_332 guiGraphics, int i, int j, float f) {
                simpleRender.apply(this).method_25394(guiGraphics,i,j,f);
            }
            //?}
        };
    }

    public static SimpleLayoutRenderable create(int width, int height, Function<SimpleLayoutRenderable, class_4068> simpleRender){
        SimpleLayoutRenderable renderable = create(simpleRender);
        renderable.size(width, height);
        return renderable;
    }

    public static SimpleLayoutRenderable createDrawString(class_2561 message, int xOffset, int yOffset, int width, int height, int color, boolean shadow){
        return new SimpleLayoutRenderable(width, height) {
            //? if >=26.1 {
            /*@Override
            public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a) {
                graphics.text(Minecraft.getInstance().font, message, getX() + xOffset, getY() + yOffset, color, shadow);
            }
            *///?} else {
            @Override
            public void method_25394(class_332 guiGraphics, int i, int j, float f) {
                guiGraphics.method_51439(class_310.method_1551().field_1772, message, method_46426() + xOffset, method_46427() + yOffset, color, shadow);
            }
            //?}
        };
    }

    public void bounds(int x, int y, int width, int height){
        method_48229(x,y);
        size(width,height);
    }

    public void size(int width, int height){
        this.width = width;
        this.height = height;
    }

    public void init(){
    }

    public boolean isHovered(double mouseX, double mouseY){
        return FactoryScreenUtil.isMouseOver(mouseX,mouseY,method_46426(),method_46427(),method_25368(),method_25364());
    }

    public void method_46421(int i) {
        x = i;
    }

    public void method_46419(int i) {
        y = i;
    }

    public int method_46426() {
        return x;
    }

    public int method_46427() {
        return y;
    }

    public int method_25368() {
        return width;
    }

    public int method_25364() {
        return height;
    }

    public void method_48206(Consumer<class_339> consumer) {

    }
}

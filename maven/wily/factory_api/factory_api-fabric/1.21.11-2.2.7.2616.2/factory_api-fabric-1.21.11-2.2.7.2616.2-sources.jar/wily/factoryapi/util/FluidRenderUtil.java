package wily.factoryapi.util;

import net.minecraft.class_1058;
import wily.factoryapi.FactoryAPIClient;
import wily.factoryapi.base.client.FactoryGuiGraphics;

public class FluidRenderUtil {
    public static void renderTiledFluid(net.minecraft.class_332 graphics, int x, int y, int offsetX, int offsetY, int fluidWidth, int fluidHeight, class_1058 fluidSprite){
        FactoryGuiGraphics.of(graphics).blit(fluidSprite.method_45852(), x + offsetX, y + offsetY, fluidSprite.method_35806() * 16f / fluidSprite.method_45851().method_45807(), fluidSprite.method_35807() * 16f / fluidSprite.method_45851().method_45815(), Math.min(fluidWidth - offsetX, 16), Math.min(fluidHeight - offsetY, 16), Math.round((1 / (fluidSprite.method_4594() / fluidSprite.method_35806())) * 16 / fluidSprite.method_45851().method_45807()), Math.round((1 / (fluidSprite.method_4593() / fluidSprite.method_35807())) * 16 / fluidSprite.method_45851().method_45815()));
    }

    public static int getFixedColor(FluidInstance fluid){
        int color = FactoryAPIClient.getFluidColor(fluid);
        return ColorUtil.getA(color) <= 0 ? ColorUtil.withAlpha(color, 1.0f) : color;
    }
}

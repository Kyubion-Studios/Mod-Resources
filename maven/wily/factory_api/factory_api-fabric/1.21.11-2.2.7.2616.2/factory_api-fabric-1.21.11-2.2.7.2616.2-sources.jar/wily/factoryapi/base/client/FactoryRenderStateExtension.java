//? if >=1.21.2 {
package wily.factoryapi.base.client;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_10017;
import net.minecraft.class_1297;

public interface FactoryRenderStateExtension<E extends class_1297> {
    List<Type<?,?>> types = new ArrayList<>();

    record Type<E extends class_1297, S extends class_10017>(Class<S> renderStateClass, Supplier<FactoryRenderStateExtension<E>> renderStateExtension){
    }

    Class<E> getEntityClass();

    default void tryExtractToRenderState(class_1297 entity, float partialTicks){
        if (getEntityClass().isInstance(entity)) extractToRenderState(getEntityClass().cast(entity),partialTicks);
    }

    void extractToRenderState(E entity, float partialTicks);

    interface Accessor {
        static Accessor of(class_10017 entityRenderState){
            return (Accessor) entityRenderState;
        }
        Iterable<FactoryRenderStateExtension<?>> getExtensions();

        <T extends FactoryRenderStateExtension<?>> T getExtension(Class<T> extensionClass);
    }
}
//?}

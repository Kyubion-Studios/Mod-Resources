package wily.factoryapi.mixin.base;

import net.minecraft.class_11768;
import net.minecraft.class_2583;
import net.minecraft.class_327;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_327.class)
public interface FontAccessor {
    //? if <1.21.9 {
    /*@Invoker("getFontSet")
    FontSet getDefaultFontSet(ResourceLocation arg);
    @Accessor
    boolean getFilterFishyGlyphs();
    *///?} else {
    @Invoker("getGlyph")
    class_11768 getBakedGlyph(int i, class_2583 style);
    //?}
}

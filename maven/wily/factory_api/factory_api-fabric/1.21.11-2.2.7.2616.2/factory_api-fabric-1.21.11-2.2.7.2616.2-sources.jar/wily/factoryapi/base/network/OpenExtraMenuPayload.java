package wily.factoryapi.base.network;

import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIClient;
import wily.factoryapi.base.FactoryExtraMenuSupplier;

import java.util.function.Consumer;
import java.util.function.Supplier;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.minecraft.class_7923;

public record OpenExtraMenuPayload(int menuId, class_3917<?> menuType, class_2561 component, CommonNetwork.PlayBuf extra) implements CommonNetwork.Payload {
    public static final CommonNetwork.Identifier<OpenExtraMenuPayload> ID = CommonNetwork.Identifier.create(FactoryAPI.createModLocation("open_extra_menu"), OpenExtraMenuPayload::new);

    public OpenExtraMenuPayload(CommonNetwork.PlayBuf buf) {
        this(buf.get().method_10816(), class_7923.field_41187.method_10200(buf.get().method_10816()), CommonNetwork.decodeComponent(buf), CommonNetwork.decodeBuf(buf));
    }

    public static void openMenuWithPos(class_3222 player, class_3908 provider, class_2338 pos) {
        openMenuWithExtra(player, provider, buf-> buf.get().method_10807(pos));
    }

    public static void openMenuWithExtra(class_3222 player, class_3908 provider, Consumer<CommonNetwork.PlayBuf> extraConsumer) {
        ((FactoryExtraMenuSupplier.PrepareMenu)player).prepareMenu(provider, menu-> {
            CommonNetwork.PlayBuf playBuf = CommonNetwork.PlayBuf.create();
            extraConsumer.accept(playBuf);
            CommonNetwork.sendToPlayer(player, new OpenExtraMenuPayload(menu.field_7763, menu.method_17358(), provider.method_5476(), playBuf));
        });
    }

    @Override
    public void apply(Context context) {
        if (FactoryAPI.isClient()) FactoryAPIClient.handleExtraMenu(context.executor(), context.player(), menuType, this);
    }

    @Override
    public CommonNetwork.Identifier<? extends CommonNetwork.Payload> identifier() {
        return ID;
    }

    @Override
    public void encode(CommonNetwork.PlayBuf buf) {
        buf.get().method_10804(menuId);
        buf.get().method_10804(class_7923.field_41187.method_10206(menuType));
        CommonNetwork.encodeComponent(buf, component);
        extra.get().method_52988(0);
        CommonNetwork.encodeBuf(buf, extra);
    }
}

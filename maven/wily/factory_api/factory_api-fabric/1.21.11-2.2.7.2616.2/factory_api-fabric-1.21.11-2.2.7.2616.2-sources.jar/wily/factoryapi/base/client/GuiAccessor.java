package wily.factoryapi.base.client;

import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_365;

public interface GuiAccessor {
    class_1799 getLastToolHighlight();

    int getToolHighlightTimer();

    class_365 getSpectatorGui();

    static GuiAccessor of(class_329 gui){
        return (GuiAccessor) gui;
    }

    static GuiAccessor getInstance(){
        return of(class_310.method_1551().field_1705);
    }
}

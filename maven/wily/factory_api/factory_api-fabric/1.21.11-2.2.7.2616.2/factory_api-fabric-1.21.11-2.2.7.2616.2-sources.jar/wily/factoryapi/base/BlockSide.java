package wily.factoryapi.base;

import java.util.Locale;
import net.minecraft.class_2350;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2741;

public enum BlockSide {
    FRONT,BACK,TOP,BOTTOM,RIGHT,LEFT;

    public class_2561 getComponent(){
        return class_2561.method_43471("tooltip.factory_api.gui_" + name().toLowerCase(Locale.ENGLISH));
    }
    public static final BlockSide[] FRONT_FACE_SIDES = values();
    public static final BlockSide[] TOP_FACE_SIDES = new BlockSide[]{TOP,BOTTOM,FRONT,BACK,RIGHT,LEFT};


    public class_2350 blockStateToFacing(class_2680 blockState, BlockSide[] sides){
        if (blockState.method_28500(class_2741.field_12481).isPresent()) return convertToHorizontalFacing(blockState.method_11654(class_2741.field_12481),sides);
        else if (blockState.method_28500(class_2741.field_12525).isPresent()) return convertToFacing(blockState.method_11654(class_2741.field_12525),sides);
        return null;
    }
    public class_2350 blockStateToFacing(class_2680 blockState){
        return blockStateToFacing(blockState,values());
    }
    public class_2350 convertToHorizontalFacing(class_2350 blockStateDirection, BlockSide[] sides){
        if (this.equals(sides[0])) {
            return blockStateDirection;
        } else if (this.equals(sides[1])) {
            return blockStateDirection.method_10153();
        } else if (this.equals(sides[2])) {
            return class_2350.field_11036;
        } else if (this.equals(sides[3])) {
            return class_2350.field_11033;
        } else if (this.equals(sides[4])) {
            return blockStateDirection.method_10160();
        } else if (this.equals(sides[5])) {
            return blockStateDirection.method_10170();
        }
        return blockStateDirection;
    }
    public class_2350 convertToHorizontalFacing(class_2350 blockStateDirection){
        return convertToHorizontalFacing(blockStateDirection,values());
    }
    public class_2350 convertToFacing(class_2350 d, BlockSide[] sides){
        if (this == sides[0])
            return d;
        if (this == sides[1])
            return d.method_10153();
        if (class_2350.class_2353.field_11062.method_10182(d)) {
            if (this == sides[2])
                return class_2350.field_11036;
            if (this == sides[3])
                return class_2350.field_11033;
            if (this == sides[4])
                return d.method_10160();
            if (this == sides[5])
                return d.method_10170();
        }else {
            if (this == sides[2])
                return d == class_2350.field_11033 ? class_2350.field_11043 : class_2350.field_11035;
            if (this == sides[3])
                return d == class_2350.field_11033 ? class_2350.field_11035 : class_2350.field_11043;
            if (this == sides[4])
                return  d == class_2350.field_11033 ? class_2350.field_11034 : class_2350.field_11039;
            if (this == sides[5])
                return d == class_2350.field_11033 ? class_2350.field_11039 : class_2350.field_11034;
        }
        return d;
    }
    public class_2350 convertToFacing(class_2350 blockStateDirection){
        return convertToFacing(blockStateDirection,values());
    }

}

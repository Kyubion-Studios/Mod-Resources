package wily.factoryapi.base.network;

import com.google.gson.JsonElement;
import com.google.gson.internal.Streams;
import com.google.gson.stream.JsonReader;
import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.StringReader;
import com.mojang.brigadier.arguments.ArgumentType;
import com.mojang.brigadier.context.CommandContext;
import com.mojang.serialization.Dynamic;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIClient;
import wily.factoryapi.base.client.UIDefinitionManager;
import wily.factoryapi.base.config.FactoryConfig;

import java.lang.reflect.Field;
import java.util.Arrays;
import java.util.Collection;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;
import net.minecraft.class_12087;
import net.minecraft.class_12094;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2179;
import net.minecraft.class_2186;
import net.minecraft.class_2232;
import net.minecraft.class_2487;
import net.minecraft.class_2509;
import net.minecraft.class_2540;
import net.minecraft.class_7157;

public class FactoryAPICommand {
    public static class JsonArgument implements ArgumentType<JsonElement> {
        public static final Map<String, Field> JSON_READER_FIELDS = FactoryAPI.getAccessibleFieldsMap(JsonReader.class,"pos","lineStart");
        public static int getPos(JsonReader jsonReader) {
            try {
                return JSON_READER_FIELDS.get("pos").getInt(jsonReader) - JSON_READER_FIELDS.get("lineStart").getInt(jsonReader) + 1;
            } catch (IllegalAccessException var2) {
                throw new IllegalStateException("Couldn't read position of JsonReader", var2);
            }
        }
        private static final Collection<String> EXAMPLES = Arrays.asList("\"hello world\"", "\"\"", "\"{\"text\":\"hello world\"}", "[\"\"]");

        public static JsonElement getJson(CommandContext<class_2168> commandContext, String string) {
            return commandContext.getArgument(string, JsonElement.class);
        }

        public static JsonArgument json() {
            return new JsonArgument();
        }

        public JsonElement parse(StringReader stringReader) {
            JsonElement element;
            JsonReader jsonReader = new JsonReader(new java.io.StringReader(stringReader.getRemaining()));
            jsonReader.setLenient(false);

            try {
                element = Streams.parse(jsonReader);
            }finally {
                stringReader.setCursor(stringReader.getCursor() + getPos(jsonReader));
            }
            return element;
        }

        public Collection<String> getExamples() {
            return EXAMPLES;
        }
    }

    public static void register(CommandDispatcher<class_2168> commandDispatcher, class_7157 commandBuildContext) {
        var command = class_2170.method_9247("factoryapi").requires(commandSourceStack -> commandSourceStack/*? if >=1.21.11 {*/.method_75037()/*?}*/.hasPermission(/*? if >=1.21.11 {*/new class_12087.class_12089(class_12094.field_63198)/*?} else {*//*2*//*?}*/));


        command.then(class_2170.method_9247("display").then(class_2170.method_9247("ui_definition").then(class_2170.method_9244("targets", class_2186.method_9308()).then(class_2170.method_9244("ui_definition", class_2179.method_9284()).executes(context -> {
            CommonNetwork.sendToPlayers(class_2186.method_9312(context, "targets"), new UIDefinitionPayload(Optional.empty(), class_2179.method_9285(context, "ui_definition")));
            return 0;
        }).then(class_2170.method_9244("default_screen", class_2232.method_9441()).executes(context -> {
            CommonNetwork.sendToPlayers(class_2186.method_9312(context, "targets"), new UIDefinitionPayload(Optional.of(class_2232.method_9443(context, "default_screen")), class_2179.method_9285(context, "ui_definition")));
            return 0;
        }))))));

        var config = class_2170.method_9247("config");
        FactoryConfig.COMMON_STORAGES.forEach((k,s)->{
            config.then(class_2170.method_9247(k.toString()).then(class_2170.method_9247("reload").executes(c->{
                s.load();
                return 1;
            })).then(class_2170.method_9247("set").then(class_2170.method_9244("value", class_2179.method_9284()).executes(c->{
                s.decodeConfigs(new Dynamic<>(class_2509.field_11560, class_2179.method_9285(c, "value")));
                s.sync();
                return 1;
            }))).then(class_2170.method_9247("save").executes(c->{
                s.save();
                return 1;
            })));
        });

        command.then(config);


        commandDispatcher.register(command);
    }

    public record UIDefinitionPayload(Optional<net.minecraft.class_2960> defaultScreen, class_2487 uiDefinitionNbt) implements CommonNetwork.Payload {
        public static final CommonNetwork.Identifier<UIDefinitionPayload> ID = CommonNetwork.Identifier.create(FactoryAPI.createModLocation("ui_definition_s2c"),UIDefinitionPayload::decode);

        @Override
        public void apply(Context context) {
            context.executor().execute(()-> FactoryAPIClient.uiDefinitionManager.openDefaultScreenAndAddDefinition(defaultScreen, UIDefinitionManager.fromDynamic(ID.toString(), new Dynamic<>(class_2509.field_11560, uiDefinitionNbt))));
        }
        public static UIDefinitionPayload decode(CommonNetwork.PlayBuf buf) {
            return new UIDefinitionPayload(buf.get().method_37436(class_2540::method_10810), buf.get().method_10798());
        }
        @Override
        public void encode(CommonNetwork.PlayBuf buf) {
            buf.get().method_37435(defaultScreen, class_2540::method_10812);
            buf.get().method_10794(uiDefinitionNbt);
        }

        @Override
        public CommonNetwork.Identifier<UIDefinitionPayload> identifier() {
            return ID;
        }
    }
}

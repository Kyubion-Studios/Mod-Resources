//? if fabric {
package wily.factoryapi.mixin.base.fabric;

import net.minecraft.class_1922;
import net.minecraft.class_1923;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_3552;
import net.minecraft.class_3558;
import net.minecraft.class_4076;
import net.minecraft.class_8527;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import wily.factoryapi.base.IFactoryBlock;

@Mixin(class_3552.class)
public class BlockLightEngineMixin {

    @Inject(method = ("getEmission"), at = @At("HEAD"), cancellable = true)
    private void injectLuminance(long l, class_2680 blockState, CallbackInfoReturnable<Integer> info){
        class_3552 engine = ((class_3552)(Object)this);
        if (blockState.method_26204() instanceof IFactoryBlock b && engine.field_15793.method_51548(class_4076.method_18691(l))){
            int i = b.getLightEmission(blockState,engine.field_15795.method_16399(),class_2338.method_10092(l));
            if (i> 0)info.setReturnValue(i);
        }
    }
    @Unique
    private int getBlockLuminance(class_2680 state, class_1922 level, class_2338 pos){
        return state.method_26204() instanceof IFactoryBlock b ? b.getLightEmission(state,level,pos): state.method_26213();
    }
    @Inject(method = ("propagateLightSources"), at = @At("HEAD"), cancellable = true)
    private void injectLightSources(class_1923 pos, CallbackInfo info){
        class_3552 engine = ((class_3552)(Object)this);
        engine.method_15512(pos, true);
        class_8527 lightChunk = engine.field_15795.method_12246(pos.field_9181/*? if >=26.1 {*//*()*//*?}*/, pos.field_9180/*? if >=26.1 {*//*()*//*?}*/);
        if (lightChunk != null) {
            lightChunk.method_51524((blockPos, blockState) -> {
                int i = getBlockLuminance(blockState,engine.field_15795.method_16399(),blockPos);
                engine.method_51566(blockPos.method_10063(), class_3558.class_8531.method_51573(i, !blockState.method_26225() || !blockState.method_26211()));
            });
        }
        info.cancel();
    }
}
//?}

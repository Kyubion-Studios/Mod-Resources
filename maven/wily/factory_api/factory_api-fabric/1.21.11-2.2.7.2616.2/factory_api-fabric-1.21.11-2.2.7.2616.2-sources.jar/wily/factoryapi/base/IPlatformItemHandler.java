package wily.factoryapi.base;

//? if fabric {
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
//?} else if forge {
/*import net.minecraftforge.items.IItemHandlerModifiable;
*///?} else if neoforge && <1.21.9 {
/*import net.neoforged.neoforge.items.IItemHandlerModifiable;
*///?} else if neoforge {
/*import net.neoforged.neoforge.transfer.ResourceHandler;
import net.neoforged.neoforge.transfer.fluid.FluidResource;
import net.neoforged.neoforge.transfer.item.ItemResource;
import net.neoforged.neoforge.transfer.transaction.SnapshotJournal;
import net.neoforged.neoforge.transfer.transaction.Transaction;
import net.neoforged.neoforge.transfer.transaction.TransactionContext;
*///?}
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.UnmodifiableView;
import wily.factoryapi.FactoryAPIPlatform;
import wily.factoryapi.util.FluidInstance;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public interface IPlatformItemHandler extends class_1263, ITagSerializable<class_2487>, IPlatformHandler /*? if forge || (neoforge && <1.21.9) {*//*, IItemHandlerModifiable*//*?} else if fabric {*/,IPlatformHandlerApi<Storage<ItemVariant>>/*?} else if neoforge {*//*, ResourceHandler<ItemResource>*//*?}*/{

    @Override
    default class_1799 method_5441(int i){
        return extractItem(i,method_5438(i).method_7947(),false);
    }

    @Override
    default void method_5431() {

    }

    default class_1799 method_5434(int i, int j){
        return extractItem(i,j,false);
    }

    @Override
    default boolean method_5443(class_1657 player) {
        return true;
    }

    /**
     * Returns the ItemStack in a given slot.
     *
     * The result's stack size may be greater than the itemstack's max size.
     *
     * If the result is empty, then the slot is empty.
     *
     * <p>
     * <strong>IMPORTANT:</strong> This ItemStack <em>MUST NOT</em> be modified. This method is not for
     * altering an inventory's contents. Any implementers who are able to detect
     * modification through this method should throw an exception.
     * </p>
     * <p>
     * <strong><em>SERIOUSLY: DO NOT MODIFY THE RETURNED ITEMSTACK</em></strong>
     * </p>
     *
     * @param slot Slot to query
     * @return ItemStack in given slot. Empty Itemstack if the slot is empty.
     **/
    @NotNull
    class_1799 method_5438(int slot);

    /**
     * <p>
     * Inserts an ItemStack into the given slot and return the remainder.
     * The ItemStack <em>should not</em> be modified in this function!
     * </p>
     *
     * @param slot     Slot to insert into.
     * @param stack    ItemStack to insert. This must not be modified by the item handler.
     * @param simulate If true, the insertion is only simulated
     * @return The remaining ItemStack that was not inserted (if the entire stack is accepted, then return an empty ItemStack).
     *         May be the same as the input ItemStack if unchanged, otherwise a new ItemStack.
     *         The returned ItemStack can be safely modified after.
     **/
    @NotNull
    class_1799 insertItem(int slot, @NotNull class_1799 stack, boolean simulate);

    /**
     * Extracts an ItemStack from the given slot.
     * <p>
     * The returned value must be empty if nothing is extracted,
     * otherwise its stack size must be less than or equal to {@code amount} and {@link class_1799#method_7914()}.
     * </p>
     *
     * @param slot     Slot to extract from.
     * @param amount   Amount to extract (may be greater than the current stack's max limit)
     * @param simulate If true, the extraction is only simulated
     * @return ItemStack extracted from the slot, must be empty if nothing can be extracted.
     *         The returned ItemStack can be safely modified after, so item handlers should return a new or copied stack.
     **/
    @NotNull
    class_1799 extractItem(int slot, int amount, boolean simulate);


    //? if forge || (neoforge && <1.21.9) {
    /*@Override
    default int getSlots() {
        return getContainerSize();
    }

    @Override
    default @NotNull ItemStack getStackInSlot(int i) {
        return getItem(i);
    }

    @Override
    default void setStackInSlot(int i, @NotNull ItemStack arg) {
        setItem(i,arg);
    }

    @Override
    default int getSlotLimit(int i) {
        return getMaxStackSize();
    }

    @Override
    default boolean isItemValid(int i, @NotNull ItemStack arg) {
        return canPlaceItem(i,arg);
    }
    *///?} else if neoforge {
    /*default int size() {
        return getContainerSize();
    }

    default ItemResource getResource(int i) {
        return ItemResource.of(getItem(i));
    }

    default long getAmountAsLong(int i) {
        return getItem(i).getCount();
    }

    default long getCapacityAsLong(int i, ItemResource resource) {
        return getMaxStackSize(resource.toStack());
    }

    default boolean isValid(int i, ItemResource resource) {
        return canPlaceItem(i, resource.toStack());
    }

    default int insert(int i, ItemResource resource, int j, TransactionContext transactionContext) {
        ItemStack item = resource.toStack();
        if (transactionContext instanceof Transaction transaction) {
            SnapshotJournal<Integer> snapshotJournal = new SnapshotJournal<>() {
                @Override
                protected Integer createSnapshot() {
                    return 0;
                }

                @Override
                protected void revertToSnapshot(Integer object) {

                }

                @Override
                protected void releaseSnapshot(Integer snapshot) {
                    insertItem(i, item, false);
                }
            };
            //? if <=1.21.10 {
            /^transaction.addCommittingJournal(snapshotJournal);
            ^///?} else {
            snapshotJournal.updateSnapshots(transaction);
            //?}
        }

        return insertItem(i, item, true).getCount();
    }

    default int extract(int i, ItemResource resource, int j, TransactionContext transactionContext) {
        if (transactionContext instanceof Transaction transaction) {
            SnapshotJournal<Integer> snapshotJournal = new SnapshotJournal<>() {
                @Override
                protected Integer createSnapshot() {
                    return 0;
                }

                @Override
                protected void revertToSnapshot(Integer object) {

                }

                @Override
                protected void releaseSnapshot(Integer snapshot) {
                    extractItem(i, j, false);
                }
            };
            //? if <=1.21.10 {
            /^transaction.addCommittingJournal(snapshotJournal);
            ^///?} else {
            snapshotJournal.updateSnapshots(transaction);
            //?}
        }

        return extractItem(i, j, true).getCount();
    }
    *///?}

}
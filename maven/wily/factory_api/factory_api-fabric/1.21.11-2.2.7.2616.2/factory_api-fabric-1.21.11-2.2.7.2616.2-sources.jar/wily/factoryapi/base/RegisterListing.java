package wily.factoryapi.base;

import wily.factoryapi.FactoryAPI;

import java.util.Collection;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Stream;
import net.minecraft.class_2378;

public interface RegisterListing<T> extends Iterable<RegisterListing.Holder<T>> {
    void register();

    default <V extends T> Holder<V> add(String name, Supplier<V> supplier){
        return add(name, id-> supplier.get());
    }

    <V extends T> Holder<V> add(String name, Function<net.minecraft.class_2960, V> supplier);

    Stream<Holder<T>> stream();

    Collection<Holder<T>> getEntries();

    class_2378<T> getRegistry();

    String getNamespace();

    interface Holder<T> extends Supplier<T> {
        net.minecraft.class_2960 getId();
    }
}

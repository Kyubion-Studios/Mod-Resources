package wily.factoryapi.base;

//? if fabric {
//? if >=26.1 {
/*import net.fabricmc.fabric.api.transfer.v1.item.ContainerStorage;
*///?} else {
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
//?}
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.minecraft.class_11352;
import net.minecraft.class_11362;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_8942;
//?}
import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.NotNull;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIPlatform;
import wily.factoryapi.util.FactoryItemUtil;

import java.util.function.BiPredicate;

public class FactoryItemHandler extends class_1277 implements IPlatformItemHandler {
    protected class_2586 be;
    protected TransportState transportState;

    public FactoryItemHandler(int inventorySize, class_2586 be, TransportState transportState){
        super(inventorySize);
        this.be = be;
        this.transportState = transportState;
    }

    @Override
    public boolean method_49104(class_1263 container, int i, class_1799 itemStack) {
        return getTransport().canExtract();
    }

    @Override
    public boolean method_5437(int slot, @NotNull class_1799 stack) {
        return getTransport().canInsert() && (!(be instanceof IFactoryExpandedStorage storage) || storage.getSlots(null).get(slot).method_7680(stack));
    }

    public FactoryItemHandler(IPlatformItemHandler  handler, TransportState transportState){
        this(handler.method_5439(), handler instanceof FactoryItemHandler h ? h.be : null,transportState);

    }

    @Override
    public @NotNull class_1799 insertItem(int slot, @NotNull class_1799 stack, boolean simulate) {
        if (stack.method_7960()) {
            return class_1799.field_8037;
        } else {
            class_1799 stackInSlot = this.method_5438(slot);
            int m;
            if (!stackInSlot.method_7960()) {
                if (stackInSlot.method_7947() >= Math.min(stackInSlot.method_7914(), this.method_5444())) {
                    return stack;
                } else if (!FactoryItemUtil.equalItems(stack, stackInSlot)) {
                    return stack;
                } else if (!this.method_5437(slot, stack)) {
                    return stack;
                } else {
                    m = Math.min(stack.method_7914(), this.method_5444()) - stackInSlot.method_7947();
                    class_1799 copy;
                    if (stack.method_7947() <= m) {
                        if (!simulate) {
                            copy = stack.method_7972();
                            copy.method_7933(stackInSlot.method_7947());
                            this.method_5447(slot, copy);
                            this.method_5431();
                        }

                        return class_1799.field_8037;
                    } else {
                        stack = stack.method_7972();
                        if (!simulate) {
                            copy = stack.method_7971(m);
                            copy.method_7933(stackInSlot.method_7947());
                            this.method_5447(slot, copy);
                            this.method_5431();
                            return stack;
                        } else {
                            stack.method_7934(m);
                            return stack;
                        }
                    }
                }
            } else if (!this.method_5437(slot, stack)) {
                return stack;
            } else {
                m = Math.min(stack.method_7914(), this.method_5444());
                if (m < stack.method_7947()) {
                    stack = stack.method_7972();
                    if (!simulate) {
                        this.method_5447(slot, stack.method_7971(m));
                        this.method_5431();
                        return stack;
                    } else {
                        stack.method_7934(m);
                        return stack;
                    }
                } else {
                    if (!simulate) {
                        this.method_5447(slot, stack);
                        this.method_5431();
                    }

                    return class_1799.field_8037;
                }
            }
        }
    }

    @Override
    public @NotNull class_1799 extractItem(int slot, int amount, boolean simulate) {
        if (amount == 0 || !method_49104(this,slot,method_5438(slot))) {
            return class_1799.field_8037;
        } else {
            class_1799 stackInSlot = this.method_5438(slot);
            if (stackInSlot.method_7960()) {
                return class_1799.field_8037;
            } else if (simulate) {
                if (stackInSlot.method_7947() < amount) {
                    return stackInSlot.method_7972();
                } else {
                    class_1799 copy = stackInSlot.method_7972();
                    copy.method_7939(amount);
                    return copy;
                }
            } else {
                int m = Math.min(stackInSlot.method_7947(), amount);
                class_1799 decrStackSize = this.method_5434(slot, m);
                this.method_5431();
                return decrStackSize;
            }
        }
    }

    @Override
    public void method_5431() {
        super.method_5431();
        if (be != null)
            be.method_5431();
    }
    @Override
    public class_2487 serializeTag() {
        //? if <1.20.5 {
        /*ListTag nbtTagList = new ListTag();

        for(int i = 0; i < getContainerSize(); ++i) {
            if (!getItem(i).isEmpty()) {
                CompoundTag itemTag = new CompoundTag();
                itemTag.putInt("Slot", i);
                getItem(i).save(itemTag);
                nbtTagList.add(itemTag);
            }
        }

        CompoundTag nbt = new CompoundTag();
        nbt.put("Items", nbtTagList);
        return nbt;
        *///?} else {
        //? if <1.21.6 {
        /*return ContainerHelper.saveAllItems(new CompoundTag(),getItems(), FactoryAPIPlatform.getRegistryAccess());
        *///?} else {
        class_11362 withoutContext = class_11362.method_71458(class_8942.field_60348);
        class_1262.method_5427(withoutContext,method_54454(), true);
        return withoutContext.method_71475();
        //?}
        //?}
    }

    @Override
    public boolean method_5443(@NotNull class_1657 player) {
        return be == null || class_1263.method_49105(be, player);
    }

    @Override
    public void deserializeTag(class_2487 tag) {
        //? if <1.20.5 {
        /*ListTag tagList = tag.getList("Items", 10);

        for(int i = 0; i < tagList.size(); ++i) {
            CompoundTag itemTags = tagList.getCompound(i);
            int slot = itemTags.getInt("Slot");
            if (slot >= 0 && slot < getContainerSize()) {
                setItem(slot, ItemStack.of(itemTags));
            }
        }
        *///?} else {
        //? if <1.21.6 {
        /*ContainerHelper.loadAllItems(tag,getItems(), FactoryAPIPlatform.getRegistryAccess());
        *///?} else {
        class_1262.method_5429(class_11352.method_71417(class_8942.field_60348, FactoryAPIPlatform.getRegistryAccess(), tag), method_54454());
        //?}
        //?}
    }

    @Override
    public class_1799 method_5491(class_1799 itemStack) {
        return super.method_5491(itemStack);
    }

    @Override
    public TransportState getTransport() {
        return transportState;
    }

    @Override
    public boolean isRemoved() {
        return be != null && be.method_11015();
    }

    //? if fabric {
    //? if >=26.1 {
    /*protected final ContainerStorage inventoryStorage = ContainerStorage.of(this, null);
    *///?} else {
    protected final InventoryStorage inventoryStorage = InventoryStorage.of(this, null);
    //?}

    @Override
    public Storage<ItemVariant> getHandler() {
        return inventoryStorage;
    }
    //?}

    public static class SidedWrapper extends FactoryItemHandler implements IModifiableTransportHandler {
        private final IPlatformItemHandler platformItemHandler;
        public int[] slots = new int[0];

        public SidedWrapper(IPlatformItemHandler platformItemHandler) {
            super(platformItemHandler, platformItemHandler.getTransport());
            this.platformItemHandler = platformItemHandler;
        }

        @Override
        public boolean method_5437(int i, @NotNull class_1799 arg) {
            return platformItemHandler.method_5437(i,arg) && ArrayUtils.contains(slots,i);
        }

        @Override
        public boolean method_49104(class_1263 container, int i, class_1799 itemStack) {
            return platformItemHandler.method_49104(container, i, itemStack) && ArrayUtils.contains(slots,i);
        }

        @Override
        public class_1799 method_5438(int i) {
            return ArrayUtils.contains(slots,i) ? platformItemHandler.method_5438(i) : class_1799.field_8037;
        }

        @Override
        public class_1799 method_5434(int i, int j) {
            return platformItemHandler.method_5434(i,j);
        }

        @Override
        public class_1799 method_5441(int i) {
            return platformItemHandler.method_5441(i);
        }

        @Override
        public void method_5447(int i, class_1799 arg) {
            platformItemHandler.method_5447(i,arg);
        }

        @Override
        public void setTransport(TransportState state) {
            transportState = state;
        }
    }
}
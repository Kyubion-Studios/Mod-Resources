package wily.factoryapi.util;

//? if >1.21.4 {
import com.mojang.blaze3d.opengl.GlStateManager;
import com.mojang.blaze3d.systems.RenderSystem;
import org.jetbrains.annotations.Nullable;
import org.joml.Matrix3x2fStack;
import wily.factoryapi.FactoryAPIClient;
import wily.factoryapi.base.client.FactoryGuiGraphics;
import wily.factoryapi.base.client.FactoryGuiMatrixStack;
import wily.factoryapi.base.client.IFactoryItemClientExtension;
import wily.factoryapi.base.client.UIAccessor;

import java.util.function.BiConsumer;
import java.util.function.Consumer;
import net.minecraft.class_1109;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2680;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_3417;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_768;
import net.minecraft.class_8029;
import net.minecraft.class_8030;

public class FactoryScreenUtil {
    private static final class_310 mc = class_310.method_1551();

    public static void drawString(FactoryGuiMatrixStack stack, String text, int x, int y, int color, boolean shadow) {
        class_327 font = mc.field_1772;
        //? if >=1.21.6 {
        switch (stack) {
            case net.minecraft.class_332 graphics -> graphics./*? if >=26.1 {*//*text*//*?} else {*/ method_51433/*?}*/(font, text, x, y, color, shadow);
            case class_4587 poseStack -> {
                class_4597.class_4598 source = mc.method_22940().method_23000();
				font.method_27522(/*? if >=1.21.2 {*/class_2561.method_43470(text)/*?} else {*/ /*text*//*?}*/, (float) x, (float) y, color, shadow, poseStack.method_23760().method_23761(), source, class_327.class_6415.field_33993, 0, 15728880/*? if <1.21.6 {*//*, font.isBidirectional()*//*?}*/);
                disableDepthTest();
                source.method_22993();
                enableDepthTest();
			}
			default -> throw new IllegalStateException("Unexpected value: " + stack);
		}
        //?} else {
        /*MultiBufferSource.BufferSource source = mc.renderBuffers().bufferSource();
        font.drawInBatch(/^? if >=1.21.2 {^/Component.literal(text)/^?} else {^/ /^text^//^?}^/, (float) x, (float) y, color, shadow, stack.<PoseStack>getNative().last().pose(), source, Font.DisplayMode.NORMAL, 0, 15728880/^? if <1.21.6 {^//^, font.isBidirectional()^//^?}^/);
        disableDepthTest();
        source.endBatch();
        enableDepthTest();
        *///?}
    }

    public static void disableDepthTest(){
        GlStateManager._disableDepthTest();
    }

    public static void enableDepthTest(){
        GlStateManager._enableDepthTest();
    }

    public static void disableBlend(){
        GlStateManager._disableBlend();
    }

    public static void enableBlend(){
        GlStateManager._enableBlend();
    }

    public static void setShaderColor(float r, float g, float b, float a) {

    }

    public static void prepTextScale(FactoryGuiMatrixStack poseStack, Consumer<FactoryGuiMatrixStack> runnable, float x, float y, float scale) {
        float yAdd = 4 - (scale * 8) / 2F;
        poseStack.pushPose();
        poseStack.translate(x, y + yAdd, 0);
        poseStack.scale(scale, scale, scale);
        runnable.accept(poseStack);
        poseStack.popPose();
        setShaderColor(1, 1, 1, 1);
    }

    public static class_8030 rect2iToRectangle(class_768 rect){
        return new class_8030(new class_8029(rect.method_3321(),rect.method_3322()),rect.method_3319(),rect.method_3320());
    }

    //? if <1.21.6 {
    /*public static void renderGuiBlock(GuiGraphics graphics, @Nullable BlockEntity be, BlockState state, int i, int j, float scaleX, float scaleY, float rotateX, float rotateY) {
        Item item = state.getBlock().asItem();
        graphics.pose().pushPose();
        graphics.pose().translate(i + 8F, j + 8F, 250F);
        graphics.pose().scale(1.0F, -1.0F, 1.0F);
        graphics.pose().scale(16.0F, 16.0F, 16.0F);
        graphics.pose().scale(scaleX, scaleY, 0.5F);
        graphics.pose().mulPose(Axis.XP.rotationDegrees(rotateX));
        graphics.pose().mulPose(Axis.YP.rotationDegrees(rotateY));
        graphics.pose().translate(-0.5f, -0.5f, -0.5f);
        Lighting.setupForFlatItems();
        IFactoryItemClientExtension e;
        BlockEntityRenderer<BlockEntity> blockEntityRenderer;
        if (be == null || (blockEntityRenderer = mc.getBlockEntityRenderDispatcher().getRenderer(be)) == null) {
            if ((e = IFactoryItemClientExtension.map.get(item)) != null && e.getCustomRenderer() != null) {
                e.getCustomRenderer().renderByItemBlockState(state, item.getDefaultInstance(), ItemDisplayContext.NONE, graphics.pose(), FactoryGuiGraphics.of(graphics).getBufferSource(), 15728880, OverlayTexture.NO_OVERLAY);
            } else {
                mc.getBlockRenderer().renderSingleBlock(state, graphics.pose(), FactoryGuiGraphics.of(graphics).getBufferSource(), 15728880, OverlayTexture.NO_OVERLAY);
            }
        } else {
            blockEntityRenderer.render(be, FactoryAPIClient.getGamePartialTick(true),graphics.pose(),FactoryGuiGraphics.of(graphics).getBufferSource(),15728880, OverlayTexture.NO_OVERLAY /^? if >1.21.4 {^/, Vec3.ZERO/^?}^/);
        }
        graphics.flush();
        graphics.pose().popPose();
    }
    *///?} else {
    public static void renderGuiBlock(net.minecraft.class_332 graphics, @Nullable class_2586 be, class_2680 state, int i, int j, float scaleX, float scaleY, float rotateX, float rotateY) {
        throw new IllegalStateException("Not implemented in 1.21.6+!");
    }
    //?}

    public static void playButtonDownSound(float grave) {
        class_310.method_1551().method_1483().method_4873(class_1109.method_47978(class_3417.field_15015, grave));
    }

    public static boolean isMouseOver(double mouseX, double mouseY, int posX, int posY, int sizeX, int sizeY){
        return (mouseX >= posX && mouseX < posX + sizeX && mouseY >= posY && mouseY < posY + sizeY);
    }

    public static void applyOffset(net.minecraft.class_332 graphics, float x, float y, float z) {
        if (x != 0 || y != 0 | z != 0) FactoryGuiMatrixStack.of(graphics.method_51448()).translate(x, y, z);
    }

    public static void applyScale(net.minecraft.class_332 graphics, float x, float y, float z) {
        if (x != 1 || y != 1 || z != 1) FactoryGuiMatrixStack.of(graphics.method_51448()).scale(x, y, z);
    }

    public static void applyColor(net.minecraft.class_332 graphics, int color) {
        //? if >=1.21.6 {
        if (color != -1) FactoryGuiGraphics.of(graphics).setBlitColor(color);
        //?} else
        //if (color != -1) FactoryGuiGraphics.of(graphics).setColor(color, true);
    }

    public static UIAccessor getScreenAccessor(){
        return UIAccessor.of(FactoryAPIClient.getScreen());
    }

    public static UIAccessor getGuiAccessor(){
        return UIAccessor.of(mc.field_1705);
    }
}

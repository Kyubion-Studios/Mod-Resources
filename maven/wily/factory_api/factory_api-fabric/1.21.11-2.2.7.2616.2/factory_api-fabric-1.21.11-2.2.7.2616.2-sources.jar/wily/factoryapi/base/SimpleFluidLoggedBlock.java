package wily.factoryapi.base;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.Function;
import java.util.function.Supplier;
import net.minecraft.class_156;
import net.minecraft.class_1750;
import net.minecraft.class_1799;
import net.minecraft.class_1922;
import net.minecraft.class_1936;
import net.minecraft.class_2263;
import net.minecraft.class_2338;
import net.minecraft.class_2402;
import net.minecraft.class_2680;
import net.minecraft.class_2758;
import net.minecraft.class_3414;
import net.minecraft.class_3609;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_3612;


public interface SimpleFluidLoggedBlock extends class_2263, class_2402 {
    List<Supplier<class_3611>> BLOCK_LOGGABLE_FLUIDS_SUPPLIER = new ArrayList<>(List.of(()->class_3612.field_15906,()->class_3612.field_15910,()->class_3612.field_15908));
    Function<Integer,class_2758> DEFAULT_FLUIDLOGGED_PROPERTY = class_156.method_34866(i-> class_2758.method_11867("fluidlogged", 0, i));

    default class_2758 FLUIDLOGGED() {
        return DEFAULT_FLUIDLOGGED_PROPERTY.apply(BLOCK_LOGGABLE_FLUIDS_SUPPLIER.size() -1);
    }
    default List<class_3611> getBlockLoggableFluids(){
        return BLOCK_LOGGABLE_FLUIDS_SUPPLIER.stream().map(Supplier::get).toList();
    }

    default boolean canPlaceLiquid(class_1922 blockGetter, class_2338 blockPos, class_2680 blockState, class_3611 fluid) {
        List<class_3611> fluids = getBlockLoggableFluids();
        return BLOCK_LOGGABLE_FLUIDS_SUPPLIER.get(blockState.method_11654(FLUIDLOGGED())).get().method_15780(class_3612.field_15906) && fluids.contains(fluid);
    }

    default boolean method_10311(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState, class_3610 fluidState) {
        List<class_3611> fluids = getBlockLoggableFluids();
        if (BLOCK_LOGGABLE_FLUIDS_SUPPLIER.get(blockState.method_11654(FLUIDLOGGED())).get().method_15780(class_3612.field_15906) && fluids.contains(fluidState.method_15772())) {
            if (!levelAccessor.method_8608()) {
                levelAccessor.method_8652(blockPos, blockState.method_11657(FLUIDLOGGED(), fluids.indexOf(fluidState.method_15772())), 3);
                levelAccessor.method_64312(blockPos, fluidState.method_15772(), fluidState.method_15772().method_15789(levelAccessor));
            }

            return true;
        } else {
            return false;
        }
    }
    default class_3610 getSimpleFluidState(class_2680 state) {
        class_3610 f = BLOCK_LOGGABLE_FLUIDS_SUPPLIER.get( state.method_11654(FLUIDLOGGED())).get().method_15785();
        return f.method_15772() instanceof class_3609 g ? g.method_15729(false) : f;
    }

    default class_2680 getStateForPlacement(class_2680 state,class_1750 ctx) {
        int f = getBlockLoggableFluids().indexOf(ctx.method_8045().method_8316(ctx.method_8037()).method_15772());
        return state.method_11657(FLUIDLOGGED(),f == -1 ? 0 : f);
    }
    default class_1799 pickupBlock(class_1936 levelAccessor, class_2338 blockPos, class_2680 blockState) {
        if ( blockState.method_11654(FLUIDLOGGED()) > 0) {
            class_3611 f = BLOCK_LOGGABLE_FLUIDS_SUPPLIER.get(blockState.method_11654(FLUIDLOGGED())).get();
            levelAccessor.method_8652(blockPos, blockState.method_11657(FLUIDLOGGED(), 0), 3);
            if (!blockState.method_26184(levelAccessor, blockPos)) {
                levelAccessor.method_22352(blockPos, true);
            }
            return new class_1799(f.method_15774());
        } else {
            return class_1799.field_8037;
        }
    }

    default Optional<class_3414> method_32351() {
        return class_3612.field_15910.method_32359();
    }
}

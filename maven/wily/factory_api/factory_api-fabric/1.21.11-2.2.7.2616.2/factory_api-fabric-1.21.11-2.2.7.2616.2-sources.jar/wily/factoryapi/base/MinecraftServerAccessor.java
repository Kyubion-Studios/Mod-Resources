package wily.factoryapi.base;

import net.minecraft.class_32;
import net.minecraft.server.MinecraftServer;

public interface MinecraftServerAccessor {
    class_32.class_5143 getStorageSource();
    static MinecraftServerAccessor of(MinecraftServer server){
        return (MinecraftServerAccessor) server;
    }
}

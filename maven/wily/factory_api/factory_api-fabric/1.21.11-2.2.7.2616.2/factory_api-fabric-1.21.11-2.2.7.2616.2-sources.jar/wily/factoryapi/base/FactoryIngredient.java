package wily.factoryapi.base;

import wily.factoryapi.FactoryAPI;
import wily.factoryapi.base.network.CommonNetwork;
import wily.factoryapi.util.ListMap;

import java.util.Arrays;
import java.util.function.Predicate;
import java.util.function.Supplier;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

public interface FactoryIngredient extends Predicate<class_1799>,CommonNetwork.Payload {
    ListMap<net.minecraft.class_2960, CommonNetwork.Identifier<? extends FactoryIngredient>> map = new ListMap<>();
    //? if >=1.20.5 {
    class_9139<class_9129,FactoryIngredient> CODEC = class_9139.method_56437((b,i)-> encode(()->b,i), b-> decode(()->b));
    //?}
    CommonNetwork.Identifier<FactoryIngredient> DEFAULT_ID = CommonNetwork.Identifier.create(FactoryAPI.createVanillaLocation("ingredient"),FactoryIngredient::decodeDefaultIngredient);

    static void init() {
        register(StackIngredient.ID);
    }

    class_1799[] getStacks();

    static void register(CommonNetwork.Identifier<? extends FactoryIngredient> id){
        map.put(id.location(), id);
    }

    static FactoryIngredient of(class_1856 ing){
        return (FactoryIngredient) ing;
    }
    static FactoryIngredient of(class_1799... stacks){
        return of(class_1856.method_8091(Arrays.stream(stacks).map(class_1799::method_7909).toArray(class_1792[]::new)));
    }

    default class_1856 toIngredient(){
        return (class_1856) this;
    }

    default void apply(Context context) {
    }

    int getCount();

    static void encode(CommonNetwork.PlayBuf buf, FactoryIngredient ingredient){
        buf.get().method_10812(ingredient.identifier().location());
        ingredient.encode(buf);
    }
    static FactoryIngredient decode(CommonNetwork.PlayBuf buf){
        CommonNetwork.Identifier<? extends FactoryIngredient> id = map.getOrDefault(buf.get().method_10810(),DEFAULT_ID);
        return id.decode(buf.get());
    }
    static FactoryIngredient decodeDefaultIngredient(CommonNetwork.PlayBuf buf){
        return FactoryIngredient.of(/*? >=1.20.5 {*/class_1856.field_48355.decode(buf.get())/*?} else {*/ /*Ingredient.fromNetwork(buf.get())*//*?}*/);
    }

}

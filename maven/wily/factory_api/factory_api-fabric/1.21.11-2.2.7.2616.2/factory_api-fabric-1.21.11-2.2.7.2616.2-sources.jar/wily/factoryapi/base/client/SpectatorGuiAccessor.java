package wily.factoryapi.base.client;

import net.minecraft.class_365;
import net.minecraft.class_531;

public interface SpectatorGuiAccessor {
    float getVisibility();

    class_531 getMenu();

    static SpectatorGuiAccessor of(class_365 gui){
        return (SpectatorGuiAccessor) gui;
    }
    static SpectatorGuiAccessor getInstance(){
        return of(GuiAccessor.getInstance().getSpectatorGui());
    }
}

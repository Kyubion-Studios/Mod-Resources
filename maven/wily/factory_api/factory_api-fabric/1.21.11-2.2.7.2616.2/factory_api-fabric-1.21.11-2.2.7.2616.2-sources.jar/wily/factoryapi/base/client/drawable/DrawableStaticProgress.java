package wily.factoryapi.base.client.drawable;

import wily.factoryapi.base.Progress;

public class DrawableStaticProgress extends AbstractDrawableStatic<DrawableStaticProgress,IFactoryDrawableType.DrawableProgress>{

    public DrawableStaticProgress(DrawableProgress drawable, int posX, int posY) {
        super(drawable, posX, posY);
    }

    public void drawProgress(net.minecraft.class_332 graphics, float percentage){
        drawable.drawProgress(graphics,method_3321(),method_3322(), percentage);
    }

    public void drawProgress(net.minecraft.class_332 graphics, int progress, int max){
        drawable.drawProgress(graphics,method_3321(),method_3322(), progress, max);
    }

    public void drawProgress(net.minecraft.class_332 graphics, Progress progress){
        drawable.drawProgress(graphics,method_3321(),method_3322(),progress);
    }
}

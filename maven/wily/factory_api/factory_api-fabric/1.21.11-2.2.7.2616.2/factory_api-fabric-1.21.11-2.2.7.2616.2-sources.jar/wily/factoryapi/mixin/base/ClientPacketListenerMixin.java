package wily.factoryapi.mixin.base;

import net.minecraft.class_2678;
import net.minecraft.class_310;
import net.minecraft.class_634;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wily.factoryapi.FactoryAPIClient;

@Mixin(class_634.class)
public class ClientPacketListenerMixin {
    @Inject(method = "handleLogin", at = @At("RETURN"))
    private void handleLogin(class_2678 clientboundLoginPacket, CallbackInfo ci){
        FactoryAPIClient.PlayerEvent.JOIN_EVENT.invoker.accept(class_310.method_1551().field_1724);
    }
    @Inject(method = "close", at = @At("RETURN"))
    private void close(CallbackInfo ci){
        FactoryAPIClient.PlayerEvent.DISCONNECTED_EVENT.invoker.accept(class_310.method_1551().field_1724);
    }
}

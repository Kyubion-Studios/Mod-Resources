package wily.factoryapi.mixin.base;

import net.minecraft.class_8089;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_8089.class)
public interface TabNavigationBarAccessor {
    @Invoker("currentTabIndex")
    int getCurrentTabIndex();
}

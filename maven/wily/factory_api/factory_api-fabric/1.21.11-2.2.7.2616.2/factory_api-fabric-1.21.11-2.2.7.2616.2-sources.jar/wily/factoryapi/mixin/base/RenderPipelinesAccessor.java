//? if >=1.21.5 {
package wily.factoryapi.mixin.base;

import com.mojang.blaze3d.pipeline.RenderPipeline;
import net.minecraft.class_10799;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_10799.class)
public interface RenderPipelinesAccessor {
    @Invoker("register")
    static RenderPipeline register(RenderPipeline renderPipeline) {
        return renderPipeline;
    }
}
//?}

package wily.factoryapi.base;

import wily.factoryapi.util.CompoundTagUtil;

import java.util.Collections;
import java.util.List;
import net.minecraft.class_2350;
import net.minecraft.class_2487;

public class TransportSide implements IHasIdentifier,IModifiableTransportHandler{
    public TransportState transportState;

    public SlotsIdentifier identifier;
    public TransportSide(SlotsIdentifier identifier, TransportState transportState){
        this.transportState = transportState;
        this.identifier = identifier;
    }
    public TransportSide(TransportState transportState){
        this(SlotsIdentifier.GENERIC,transportState);
    }
    public TransportSide(){
        this(TransportState.NONE);
    }
    public TransportSide withTransport(TransportState state) {
        this.transportState = state;
        return this;
    }
    public static class_2487 serializeTag(SideList<TransportSide> sided, List<? extends IHasIdentifier> list) {
        class_2487 sides = new class_2487();
        List<SlotsIdentifier> identifiers = IHasIdentifier.getSlotsIdentifiers(list);
        for (class_2350 direction : class_2350.values())
            sides.method_10539(direction.method_10151(), new int[]{identifiers.contains(sided.get(direction).identifier()) ? identifiers.indexOf(sided.get(direction).identifier()) : 0, sided.get(direction).getTransport().ordinal()});
        return sides;
    }

    public static void deserializeTag(class_2487 nbt, SideList<TransportSide> sided, List<? extends IHasIdentifier> list) {
        if (!nbt.method_33133())
            for (class_2350 direction : class_2350.values()) {
                int[] slotsState = CompoundTagUtil.getIntArrayOrEmpty(nbt, direction.method_10151());
                sided.put(direction, new TransportSide(!list.isEmpty() ?  list.get(slotsState[0]).identifier() : sided.get(direction).identifier(), TransportState.byOrdinal(slotsState[slotsState.length - 1])));
            }
    }

    public static class_2487 serializeTag(SideList<TransportSide> sided) {
        return serializeTag(sided, Collections.emptyList());
    }

    public static void deserializeTag(class_2487 nbt, SideList<TransportSide> sided) {
       deserializeTag(nbt,sided,Collections.emptyList());
    }
    @Override
    public SlotsIdentifier identifier() {
        return identifier;
    }

    public TransportSide ofTransport(TransportState transport) {
        return new TransportSide(identifier,transport);
    }

    @Override
    public TransportState getTransport() {
        return transportState;
    }

    @Override
    public void setTransport(TransportState state) {
        transportState = state;
    }
    public TransportSide withSlotIdentifier(SlotsIdentifier identifier) {
        this.identifier = identifier;
        return this;
    }
    public int nextSlotIndex(List<? extends IHasIdentifier> identifiers) {
        int i = getSlotIndex(identifiers) + 1;
        int b = i < identifiers.size() ? i : 0;
        identifier = identifiers.get(b).identifier();
        return b;
    }
    public int getSlotIndex(List<? extends IHasIdentifier> identifierList) {
        return Math.max(IHasIdentifier.getSlotsIdentifiers(identifierList).indexOf(identifier()), 0);
    }
}

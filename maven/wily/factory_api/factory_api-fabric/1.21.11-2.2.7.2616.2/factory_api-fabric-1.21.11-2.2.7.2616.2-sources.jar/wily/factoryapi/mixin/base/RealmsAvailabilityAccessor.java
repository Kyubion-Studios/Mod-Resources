//? if >=1.20.3 {
package wily.factoryapi.mixin.base;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

import java.util.concurrent.CompletableFuture;
import net.minecraft.class_8647;

@Mixin(class_8647.class)
public interface RealmsAvailabilityAccessor {
    @Accessor
    static void setFuture(CompletableFuture<class_8647.class_8648> userProperties) {
    }
}
//?}

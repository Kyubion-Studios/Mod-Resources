package wily.factoryapi.base.client;

import net.minecraft.class_310;
import net.minecraft.class_320;

public interface MinecraftAccessor {
    static MinecraftAccessor getInstance(){
        return (MinecraftAccessor) class_310.method_1551();
    }
    //? if <1.20.5 {
    /*float getPausePartialTick();
    *///?}
    boolean setUser(class_320 user);

    boolean hasGameLoaded();

    static void reloadResourcePacksIfLoaded(){
        if (MinecraftAccessor.getInstance().hasGameLoaded()) class_310.method_1551().method_1521();
    }
}

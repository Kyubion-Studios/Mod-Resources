package wily.factoryapi.base;

import wily.factoryapi.base.network.CommonNetwork;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_3908;
import net.minecraft.class_3917;
import net.minecraft.class_7701;

public interface FactoryExtraMenuSupplier<T extends class_1703> extends class_3917.class_3918<T> {
    default T create(int i, class_1661 inventory){
        return create(i, inventory, null);
    }

    T create(int i, class_1661 inventory, CommonNetwork.PlayBuf buf);

    static <T extends class_1703> class_3917<T> createMenuType(FactoryExtraMenuSupplier<T> factoryExtraMenuSupplier){
        return new class_3917<>(factoryExtraMenuSupplier, class_7701.field_40182);
    }

    interface PrepareMenu {
        Optional<class_1703> prepareMenu(class_3908 provider, Consumer<class_1703> openClientMenu);
    }
}

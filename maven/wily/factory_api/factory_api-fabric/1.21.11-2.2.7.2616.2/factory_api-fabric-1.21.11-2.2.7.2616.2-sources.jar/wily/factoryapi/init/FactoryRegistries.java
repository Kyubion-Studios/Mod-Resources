package wily.factoryapi.init;

import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIPlatform;
import wily.factoryapi.base.FactoryCapacityTier;
import wily.factoryapi.base.RegisterListing;
import wily.factoryapi.base.network.FactoryAPICommand;
import wily.factoryapi.util.FactoryItemUtil;
import wily.factoryapi.util.FluidInstance;

import java.util.List;
import net.minecraft.class_1792;
import net.minecraft.class_2314;
import net.minecraft.class_2319;
import net.minecraft.class_5699;
import net.minecraft.class_7923;
import net.minecraft.class_9135;
import net.minecraft.class_9331;

public class FactoryRegistries {
    public static final RegisterListing<class_2314<?,?>> ARGUMENT_TYPE_INFOS = FactoryAPIPlatform.createRegister(FactoryAPI.MOD_ID, class_7923.field_41192);
    public static final RegisterListing.Holder<class_2314<FactoryAPICommand.JsonArgument,?>> JSON_ARGUMENT_TYPE = ARGUMENT_TYPE_INFOS.add("json_argument_type",()-> class_2319.method_41999(FactoryAPICommand.JsonArgument::json));

    //? if >=1.20.5 {
    public static final RegisterListing<class_9331<?>> DATA_COMPONENT_TYPES = FactoryAPIPlatform.createRegister(FactoryAPI.MOD_ID, class_7923.field_49658);
    public static final RegisterListing.Holder<class_9331<FluidInstance>> FLUID_INSTANCE_COMPONENT  = DATA_COMPONENT_TYPES.add("fluid_instance",()-> class_9331.<FluidInstance>method_57873().method_57881(FluidInstance.CODEC).method_57882(FluidInstance.STREAM_CODEC).method_57880());
    public static final RegisterListing.Holder<class_9331<Integer>> FLUID_CAPACITY_COMPONENT = DATA_COMPONENT_TYPES.add("fluid_capacity",()-> class_9331.<Integer>method_57873().method_57881(class_5699.field_33442).method_57882(class_9135.field_48550).method_57880());
    public static final RegisterListing.Holder<class_9331<Integer>> ENERGY_COMPONENT = DATA_COMPONENT_TYPES.add("energy",()-> class_9331.<Integer>method_57873().method_57881(class_5699.field_33442).method_57882(class_9135.field_48550).method_57880());
    //public static final RegisterListing.Holder<DataComponentType<Integer>> ENERGY_CAPACITY_COMPONENT = DATA_COMPONENT_TYPES.add("energy_capacity",()-> DataComponentType.<Integer>builder().persistent(ExtraCodecs.POSITIVE_INT).networkSynchronized(ByteBufCodecs.VAR_INT).build());
    public static final RegisterListing.Holder<class_9331<FactoryCapacityTier>> ENERGY_TIER_COMPONENT = DATA_COMPONENT_TYPES.add("energy_tier",()-> class_9331.<FactoryCapacityTier>method_57873().method_57881(FactoryCapacityTier.CODEC).method_57882(FactoryCapacityTier.STREAM_CODEC).method_57880());
    public static final RegisterListing.Holder<class_9331<FactoryCapacityTier>> STORED_ENERGY_TIER_COMPONENT = DATA_COMPONENT_TYPES.add("stored_energy_tier",()-> class_9331.<FactoryCapacityTier>method_57873().method_57881(FactoryCapacityTier.CODEC).method_57882(FactoryCapacityTier.STREAM_CODEC).method_57880());

    public static final RegisterListing.Holder<class_9331<List<class_1792>>> ITEM_COMPONENTS_COMPONENT = DATA_COMPONENT_TYPES.add("item_components",()-> class_9331.<List<class_1792>>method_57873().method_57881(FactoryItemUtil.ITEM_COMPONENTS_CODEC).method_57882(FactoryItemUtil.ITEM_COMPONENTS_STREAM_CODEC).method_57880());

    //?}

    public static void init() {
        ARGUMENT_TYPE_INFOS.register();
        //? if >=1.20.5 {
        DATA_COMPONENT_TYPES.register();
        //?}
    }
}

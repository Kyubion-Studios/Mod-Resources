package wily.factoryapi.base;

import org.apache.commons.lang3.ArrayUtils;
import org.jetbrains.annotations.Nullable;
import wily.factoryapi.util.CompoundTagUtil;

import java.util.*;
import net.minecraft.class_1657;
import net.minecraft.class_2350;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2586;

public interface IFactoryExpandedStorage extends IFactoryStorage {
    default void replaceSidedStorage(BlockSide blockSide,SideList<TransportSide> side, TransportSide replacement){
        if (this instanceof class_2586 be) side.put(blockSide.blockStateToFacing(be.method_11010()), replacement);
    }

    default class_2371<FactoryItemSlot> getSlots(@Nullable class_1657 player){
        return class_2371.method_10211();
    }

    default List<IPlatformFluidHandler> getTanks(){
        return Collections.emptyList();
    }

    default Map<SlotsIdentifier, int[]> itemSlotsIdentifiers() {
        Map<SlotsIdentifier, int[]> map = new LinkedHashMap<>();
        for( FactoryItemSlot slot : getSlots(null)){
            int[] list =  map.getOrDefault(slot.identifier(), new int[]{});
            if (ArrayUtils.contains(list,slot.method_34266())) continue;
            list = ArrayUtils.add(list,slot.method_34266());
            map.put(slot.identifier(),list);
        }
        return map;
    }

    default List<class_2350> getBlockedSides(){
        return Collections.emptyList();
    }

    default List<SlotsIdentifier> getItemSlotsIdentifiers(){
        return List.copyOf(itemSlotsIdentifiers().keySet());
    }

    default List<SlotsIdentifier> getFluidSlotsIdentifiers() { return IHasIdentifier.getSlotsIdentifiers(getTanks()); }

    default void loadTag(class_2487 compoundTag) {
        getStorage(FactoryStorage.CRAFTY_ENERGY).ifPresent((e)-> e.deserializeTag(CompoundTagUtil.getCompoundTagOrEmpty(compoundTag, "CYEnergy")));
        getStorage(FactoryStorage.ENERGY).ifPresent((e)-> e.deserializeTag(CompoundTagUtil.getCompoundTagOrEmpty(compoundTag,"Energy")));
        if (!getTanks().isEmpty()) getTanks().forEach((tank)-> tank.deserializeTag(CompoundTagUtil.getCompoundTagOrEmpty(compoundTag,tank.getName())));
        getStorage(FactoryStorage.ITEM).ifPresent((e)-> e.deserializeTag(CompoundTagUtil.getCompoundTagOrEmpty(compoundTag,"inventory")));
        getStorageSides(FactoryStorage.FLUID).ifPresent((f)-> TransportSide.deserializeTag(CompoundTagUtil.getCompoundTagOrEmpty(compoundTag,"fluidSides"), f, getTanks()));
        getStorageSides(FactoryStorage.ITEM).ifPresent((i)-> TransportSide.deserializeTag(CompoundTagUtil.getCompoundTagOrEmpty(compoundTag,"itemSides"), i, getItemSlotsIdentifiers()));
        getStorageSides(FactoryStorage.CRAFTY_ENERGY).ifPresent((e)-> TransportSide.deserializeTag(CompoundTagUtil.getCompoundTagOrEmpty(compoundTag,"energySides"), e));
    }

    default void saveTag(class_2487 compoundTag) {
        getStorage(FactoryStorage.CRAFTY_ENERGY).ifPresent((e)-> compoundTag.method_10566("CYEnergy", e.serializeTag()));
        getStorage(FactoryStorage.ENERGY).ifPresent((e)-> compoundTag.method_10566("Energy", e.serializeTag()));
        if (!getTanks().isEmpty()) getTanks().forEach((tank)-> compoundTag.method_10566(tank.getName(), tank.serializeTag()));
        getStorage(FactoryStorage.ITEM).ifPresent((i)-> compoundTag.method_10566("inventory", i.serializeTag()));
        getStorageSides(FactoryStorage.FLUID).ifPresent((f)-> compoundTag.method_10566("fluidSides",TransportSide.serializeTag(f, getTanks())));
        getStorageSides(FactoryStorage.ITEM).ifPresent((i)-> compoundTag.method_10566("itemSides", TransportSide.serializeTag(i, getItemSlotsIdentifiers())));
        getStorageSides(FactoryStorage.CRAFTY_ENERGY).ifPresent((e)-> compoundTag.method_10566("energySides", TransportSide.serializeTag(e)));
    }

}

package wily.factoryapi.mixin.base;

import net.minecraft.class_11908;
import net.minecraft.class_11909;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_4264;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import wily.factoryapi.base.client.FactoryGuiGraphics;
import wily.factoryapi.base.client.WidgetAccessor;
import wily.factoryapi.util.FactoryScreenUtil;

@Mixin(class_4264.class)
public abstract class AbstractButtonMixin extends class_339 implements WidgetAccessor {

    public AbstractButtonMixin(int i, int j, int k, int l, class_2561 component) {
        super(i, j, k, l, component);
    }

    //? if >=1.21.9 {
    @Inject(method = "onClick", at = @At("HEAD"), cancellable = true)
    public void onClick(class_11909 mouseButtonEvent, boolean bl, CallbackInfo ci) {
        if (getOnPressOverride() != null) {
            super.method_25348(mouseButtonEvent, bl);
            ci.cancel();
        }
    }

    @Inject(method = "keyPressed", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/AbstractButton;onPress(Lnet/minecraft/client/input/InputWithModifiers;)V"), cancellable = true)
    public void keyPressed(class_11908 keyEvent, CallbackInfoReturnable<Boolean> cir) {
        if (getOnPressOverride() != null) {
            getOnPressOverride().accept(this);
            cir.setReturnValue(true);
        }
    }
    //?} else {
    /*@Inject(method = "onClick", at = @At("HEAD"), cancellable = true)
    public void onClick(double d, double e, CallbackInfo ci) {
        if (getOnPressOverride() != null) {
            super.onClick(d,e);
            ci.cancel();
        }
    }

    @Inject(method = "keyPressed", at = @At(value = "INVOKE", target = "Lnet/minecraft/client/gui/components/AbstractButton;onPress()V"), cancellable = true)
    public void keyPressed(int i, int j, int k, CallbackInfoReturnable<Boolean> cir) {
        if (getOnPressOverride() != null) {
            getOnPressOverride().accept(this);
            cir.setReturnValue(true);
        }
    }
    *///?}

    //? if <1.21.11 {
    /*@Inject(method = "renderString", at = @At("HEAD"))
    public void renderString(GuiGraphics guiGraphics, Font font, int i, CallbackInfo ci) {
        net.minecraft.resources.Identifier sprite = getSpriteOverride();
        if (sprite != null) {
            FactoryScreenUtil.enableBlend();
            //? if <1.21.6 {
            /^FactoryGuiGraphics.of(guiGraphics).setColor(1.0f, 1.0f, 1.0f, alpha);
            ^///?} else
            FactoryGuiGraphics.of(guiGraphics).setBlitColor(1.0f, 1.0f, 1.0f, alpha);
            FactoryGuiGraphics.of(guiGraphics).blitSprite(sprite, getX(), getY(), getWidth(), getHeight());
            //? if <1.21.6 {
            /^FactoryGuiGraphics.of(guiGraphics).clearColor();
            ^///?} else
            FactoryGuiGraphics.of(guiGraphics).clearBlitColor();
            FactoryScreenUtil.disableBlend();
        }
    }
    *///?} else if >=26.1 {
    /*@Inject(method = "extractDefaultSprite", at = @At("HEAD"), cancellable = true)
    public void renderString(GuiGraphicsExtractor guiGraphics, CallbackInfo ci) {
        net.minecraft.resources.Identifier sprite = getSpriteOverride();
        if (sprite != null) {
            FactoryScreenUtil.enableBlend();
            FactoryGuiGraphics.of(guiGraphics).setBlitColor(1.0f, 1.0f, 1.0f, alpha);
            FactoryGuiGraphics.of(guiGraphics).blitSprite(sprite, getX(), getY(), getWidth(), getHeight());
            FactoryGuiGraphics.of(guiGraphics).clearBlitColor();
            FactoryScreenUtil.disableBlend();
            ci.cancel();
        }
    }
    *///?} else {
    @Inject(method = "renderDefaultSprite", at = @At("HEAD"), cancellable = true)
    public void renderString(class_332 guiGraphics, CallbackInfo ci) {
        net.minecraft.class_2960 sprite = getSpriteOverride();
        if (sprite != null) {
            FactoryScreenUtil.enableBlend();
            FactoryGuiGraphics.of(guiGraphics).setBlitColor(1.0f, 1.0f, 1.0f, field_22765);
            FactoryGuiGraphics.of(guiGraphics).blitSprite(sprite, method_46426(), method_46427(), method_25368(), method_25364());
            FactoryGuiGraphics.of(guiGraphics).clearBlitColor();
            FactoryScreenUtil.disableBlend();
            ci.cancel();
        }
    }
    //?}
}

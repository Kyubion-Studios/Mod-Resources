package wily.factoryapi.mixin.base;

import org.spongepowered.asm.mixin.*;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import wily.factoryapi.base.FactoryIngredient;
import wily.factoryapi.base.network.CommonNetwork;

import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Stream;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

@Mixin(class_1856.class)
public abstract class IngredientMixin implements FactoryIngredient {
    //? if >=1.21.2 {

    @Mutable
    @Shadow @Final public static class_9139<class_9129, Optional<class_1856>> OPTIONAL_CONTENTS_STREAM_CODEC;
    @Unique
    private class_1799[] stacks;
    //?} else
    //@Shadow public abstract ItemStack[] getItems();

    @Override
    public CommonNetwork.Identifier<? extends CommonNetwork.Payload> identifier() {
        return FactoryIngredient.DEFAULT_ID;
    }

    @Unique
    private class_1856 self(){
        return (class_1856) (Object) this;
    }

    @Override
    public class_1799[] getStacks() {
        //? if >=1.21.2 {
        return stacks == null ? stacks = self().method_8105()/*? if <1.21.4 {*//*.stream()*//*?}*/.map(class_1799::new).toArray(class_1799[]::new) : stacks;
        //?} else
        //return getItems();
    }

    @Override
    public void encode(CommonNetwork.PlayBuf buf) {
        //? if >=1.20.5 {
        class_1856.field_48355.encode(buf.get(),(class_1856) (Object) this);
        //?} else
        //((Ingredient)(Object) this).toNetwork(buf.get());
    }

    @Override
    public int getCount() {
        return 1;
    }

    //? if >=1.21.2 && forge {
    /*@Redirect(method = "<clinit>", at = @At(value = "FIELD", target = "Lnet/minecraft/world/item/crafting/Ingredient;OPTIONAL_CONTENTS_STREAM_CODEC:Lnet/minecraft/network/codec/StreamCodec;"))
    private static void fixOptionalIngredientStreamCodec(StreamCodec<RegistryFriendlyByteBuf, Optional<Ingredient>> value){
        OPTIONAL_CONTENTS_STREAM_CODEC = StreamCodec.of((b, o)-> b.writeOptional(o,(b1,i)->Ingredient.CONTENTS_STREAM_CODEC.encode(b,i)), b-> b.readOptional(b1->Ingredient.CONTENTS_STREAM_CODEC.decode(b)));
    }
    *///?}
}

package wily.factoryapi.util;

import net.minecraft.class_2561;

public class FactoryComponents {
    public static class_2561 optionsName(String key){
        return class_2561.method_43471("options.factory_api."+key);
    }

    public static class_2561 pixelValueLabel(class_2561 name, class_2561 value) {
        return class_2561.method_43469("options.pixel_value", name, value);
    }

    public static class_2561 percentValueLabel(class_2561 name, class_2561 value) {
        return class_2561.method_43469("options.percent_value", name, value);
    }
}

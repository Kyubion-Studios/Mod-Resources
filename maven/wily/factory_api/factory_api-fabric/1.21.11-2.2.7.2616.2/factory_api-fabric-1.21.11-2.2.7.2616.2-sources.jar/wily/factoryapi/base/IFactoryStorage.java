package wily.factoryapi.base;

import net.minecraft.class_2350;

public interface IFactoryStorage {

    default <T extends IPlatformHandler> ArbitrarySupplier<T> getStorage(FactoryStorage<T> storage){return getStorage(storage, null);}

    <T extends IPlatformHandler> ArbitrarySupplier<T> getStorage(FactoryStorage<T> storage, class_2350 direction);

    default ArbitrarySupplier<SideList<TransportSide>> getStorageSides(FactoryStorage<?> storage){return ArbitrarySupplier.empty();}

}

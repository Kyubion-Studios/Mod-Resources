package wily.factoryapi.mixin.base;

import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.Unique;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wily.factoryapi.base.ArbitrarySupplier;
import wily.factoryapi.base.client.WidgetAccessor;

import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_364;

@Mixin(class_339.class)
public abstract class AbstractWidgetMixin implements WidgetAccessor, class_364 {
    @Shadow protected int height;

    @Shadow public abstract boolean isHoveredOrFocused();

    @Shadow public boolean visible;

    @Unique net.minecraft.class_2960 overrideSprite = null;
    @Unique net.minecraft.class_2960 highlightedOverrideSprite = null;
    @Unique Consumer<class_339> onPressOverride = null;
    @Unique ArbitrarySupplier<Boolean> visibility = ArbitrarySupplier.empty();

    @Override
    public void setSpriteOverride(net.minecraft.class_2960 sprite) {
        this.overrideSprite = sprite;
    }

    @Override
    public void setHighlightedSpriteOverride(net.minecraft.class_2960 sprite) {
        this.highlightedOverrideSprite = sprite;
    }

    @Override
    public net.minecraft.class_2960 getSpriteOverride() {
        return isHoveredOrFocused() ? highlightedOverrideSprite : overrideSprite;
    }
    @Override
    public Consumer<class_339> getOnPressOverride() {
        return onPressOverride;
    }

    @Override
    public void setOnPressOverride(Consumer<class_339> onPressOverride) {
        this.onPressOverride = onPressOverride;
    }

    @Unique
    private void onPress(){
        if (getOnPressOverride() != null) getOnPressOverride().accept((class_339) (Object) this);
    }

    @Override
    public void setVisibility(ArbitrarySupplier<Boolean> supplier) {
        this.visibility = supplier;
    }

    //? if >=26.1 {
    /*@Inject(method = "extractRenderState", at = @At("HEAD"))
    public void extractRenderState(GuiGraphicsExtractor arg, int i, int j, float f, CallbackInfo ci) {
        if (visibility.isPresent()) visible = visibility.get();
    }
    *///?} else {
    @Inject(method = "render", at = @At("HEAD"))
    public void render(class_332 arg, int i, int j, float f, CallbackInfo ci) {
        if (visibility.isPresent()) visible = visibility.get();
    }
    //?}

    @Inject(method = "onClick", at = @At("HEAD"))
    public void onClick(CallbackInfo ci) {
        onPress();
    }

    //? <=1.20.1 {
    /*@Override
    public void setHeight(int height) {
        this.height = height;
    }
    *///?}
}

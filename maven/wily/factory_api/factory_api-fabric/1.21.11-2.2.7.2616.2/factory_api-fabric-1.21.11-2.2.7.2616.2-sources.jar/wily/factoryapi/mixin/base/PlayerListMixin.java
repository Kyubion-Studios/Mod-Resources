package wily.factoryapi.mixin.base;

import net.minecraft.class_2535;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import net.minecraft.class_8792;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wily.factoryapi.FactoryEvent;

@Mixin(class_3324.class)
public class PlayerListMixin {
    @Inject(method = "placeNewPlayer", at = @At("RETURN"))
    public void placeNewPlayer(class_2535 connection, class_3222 serverPlayer,/*? if >1.20.2 {*/ class_8792 commonListenerCookie, /*?}*/CallbackInfo ci) {
        FactoryEvent.PlayerEvent.JOIN_EVENT.invoker.accept(serverPlayer);
    }
    @Inject(method = "remove", at = @At("RETURN"))
    public void remove(class_3222 serverPlayer, CallbackInfo ci) {
        FactoryEvent.PlayerEvent.REMOVED_EVENT.invoker.accept(serverPlayer);
    }
    @Inject(method = "reloadResources", at = @At("RETURN"))
    public void remove(CallbackInfo ci) {
        FactoryEvent.PlayerEvent.RELOAD_RESOURCES_EVENT.invoker.accept((class_3324) (Object)this);
    }
}

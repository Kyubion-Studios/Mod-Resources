package wily.factoryapi;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.mojang.brigadier.arguments.ArgumentType;
import io.netty.buffer.Unpooled;
import net.minecraft.class_124;
import net.minecraft.class_1297;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2248;
import net.minecraft.class_2314;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2378;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_3288;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7924;
import net.minecraft.core.*;
import net.minecraft.server.MinecraftServer;
import org.jetbrains.annotations.NotNull;
//? if forge {
/*import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.capabilities.Capability;
import net.minecraftforge.common.capabilities.ForgeCapabilities;
import net.minecraftforge.energy.IEnergyStorage;
import net.minecraftforge.fluids.FluidStack;
import net.minecraftforge.fluids.capability.IFluidHandler;
import net.minecraftforge.fluids.capability.IFluidHandlerItem;
import net.minecraftforge.fml.ModList;
import net.minecraftforge.fml.loading.FMLLoader;
import net.minecraftforge.fml.loading.FMLPaths;
import net.minecraftforge.fml.loading.LoadingModList;
import net.minecraftforge.items.IItemHandler;
import net.minecraftforge.fml.ModContainer;
import net.minecraftforge.fml.loading.FMLEnvironment;
import net.minecraftforge.fml.loading.moddiscovery.ModFileInfo;
import net.minecraftforge.forgespi.language.IModFileInfo;
import net.minecraftforge.forgespi.language.IModInfo;
import net.minecraftforge.network.NetworkDirection;
import net.minecraftforge.network.PacketDistributor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;
//? if <1.21.6 {
import net.minecraftforge.eventbus.api.IEventBus;
//?} else {
/^import net.minecraftforge.eventbus.api.bus.BusGroup;
^///?}
import net.minecraftforge.fml.ModLoadingContext;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
*///?} elif fabric {
import net.fabricmc.api.EnvType;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.item.ItemStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
//? if <1.21.11 {
/*import net.fabricmc.fabric.mixin.command.ArgumentTypesAccessor;
*///?} else {
import net.fabricmc.fabric.mixin.command.ArgumentTypeInfosAccessor;
//?}
import net.fabricmc.loader.api.FabricLoader;
import net.fabricmc.loader.api.ModContainer;
import net.fabricmc.loader.api.metadata.Person;
import team.reborn.energy.api.EnergyStorage;
import team.reborn.energy.impl.SimpleItemEnergyStorageImpl;
import wily.factoryapi.base.fabric.CraftyEnergyStorage;
import wily.factoryapi.base.fabric.FabricEnergyStoragePlatform;
import wily.factoryapi.base.fabric.FabricFluidStoragePlatform;
import wily.factoryapi.base.fabric.FabricItemStoragePlatform;
import wily.factoryapi.base.*;
import wily.factoryapi.base.network.CommonNetwork;
import wily.factoryapi.util.FluidInstance;
import wily.factoryapi.util.ListMap;
import wily.factoryapi.util.ModInfo;

import java.io.IOException;
import java.io.InputStream;
import java.net.URI;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public interface FactoryAPIPlatform {
    Map<IPlatformHandler, SideList<? super IModifiableTransportHandler>> filteredHandlersCache = new ConcurrentHashMap<>();
    Map<class_2586, IFactoryStorage> platformStorageWrappersCache = new ConcurrentHashMap<>();

    //? if forge {
    /*ListMap<Capability<?>, FactoryStorage<?>> ITEM_CAPABILITY_MAP = new ListMap.Builder<Capability<?>, FactoryStorage<?>>().put(ForgeCapabilities.FLUID_HANDLER_ITEM, FactoryStorage.FLUID).put(ForgeCapabilities.ITEM_HANDLER,FactoryStorage.ITEM).put(ForgeCapabilities.ENERGY,FactoryStorage.ENERGY).put(FactoryCapabilities.CRAFTY_ENERGY,FactoryStorage.CRAFTY_ENERGY).build();
    ListMap<Capability<?>, FactoryStorage<?>> BLOCK_CAPABILITY_MAP = new ListMap.Builder<Capability<?>, FactoryStorage<?>>().put(ForgeCapabilities.FLUID_HANDLER, FactoryStorage.FLUID).put(ForgeCapabilities.ITEM_HANDLER,FactoryStorage.ITEM).put(ForgeCapabilities.ENERGY,FactoryStorage.ENERGY).put(FactoryCapabilities.CRAFTY_ENERGY,FactoryStorage.CRAFTY_ENERGY).build();
    *///?} else if neoforge && <1.21.9 {
    /*ListMap<ItemCapability<?,?>, FactoryStorage<?>> ITEM_CAPABILITY_MAP = new ListMap.Builder<ItemCapability<?,?>, FactoryStorage<?>>().put(Capabilities.FluidHandler.ITEM, FactoryStorage.FLUID).put(Capabilities.ItemHandler.ITEM,FactoryStorage.ITEM).put(Capabilities.EnergyStorage.ITEM,FactoryStorage.ENERGY).put(FactoryCapabilities.CRAFTY_ENERGY_ITEM,FactoryStorage.CRAFTY_ENERGY).build();
    ListMap<BlockCapability<?,Direction>, FactoryStorage<?>> BLOCK_CAPABILITY_MAP = new ListMap.Builder<BlockCapability<?,Direction>, FactoryStorage<?>>().put(Capabilities.FluidHandler.BLOCK, FactoryStorage.FLUID).put(Capabilities.ItemHandler.BLOCK,FactoryStorage.ITEM).put(Capabilities.EnergyStorage.BLOCK,FactoryStorage.ENERGY).put(FactoryCapabilities.CRAFTY_ENERGY,FactoryStorage.CRAFTY_ENERGY).build();
    *///?} else if neoforge {
    /*ListMap<ItemCapability<?,?>, FactoryStorage<?>> ITEM_CAPABILITY_MAP = new ListMap.Builder<ItemCapability<?,?>, FactoryStorage<?>>().put(Capabilities.Fluid.ITEM, FactoryStorage.FLUID).put(Capabilities.Item.ITEM,FactoryStorage.ITEM).put(Capabilities.Energy.ITEM,FactoryStorage.ENERGY).put(FactoryCapabilities.CRAFTY_ENERGY_ITEM,FactoryStorage.CRAFTY_ENERGY).build();
    ListMap<BlockCapability<?,Direction>, FactoryStorage<?>> BLOCK_CAPABILITY_MAP = new ListMap.Builder<BlockCapability<?,Direction>, FactoryStorage<?>>().put(Capabilities.Fluid.BLOCK, FactoryStorage.FLUID).put(Capabilities.Item.BLOCK,FactoryStorage.ITEM).put(Capabilities.Energy.BLOCK,FactoryStorage.ENERGY).put(FactoryCapabilities.CRAFTY_ENERGY,FactoryStorage.CRAFTY_ENERGY).build();
    *///?}

    ListMap<String, ModInfo> MOD_INFOS = new ListMap<>();

    static class_2561 getPlatformEnergyComponent() {
        //? if fabric {
        return class_2561.method_43471("energy.factory_api.fabric").method_27692(class_124.field_1065);
        //?} elif forge {
        /*return Component.translatable("energy.factory_api.forge").withStyle(ChatFormatting.GREEN);
        *///?} elif neoforge {
        /*return Component.translatable("energy.factory_api.neoforge").withStyle(ChatFormatting.GREEN);
         *///?} else
        /*throw new AssertionError();*/
    }

    static <T> T getRegistryValue(net.minecraft.class_2960 location, class_2378<T> registry) {
        return registry./*? if <1.21.2 {*//*get*//*?} else {*/method_63535/*?}*/(location);
    }

    static <T> Optional<class_6880.class_6883<T>> getRegistryValue(class_5455 access, class_5321<T> resourceKey) {
        return access.method_30530(class_5321.<T>method_29180(resourceKey.method_41185())).method_46746(resourceKey);
    }

    static class_4970.class_2251 setupBlockProperties(class_4970.class_2251 properties, RegisterListing.Holder<? extends class_2248> blockHolder) {
        return setupBlockProperties(properties, blockHolder.getId());
    }

    static class_4970.class_2251 setupBlockProperties(class_4970.class_2251 properties, net.minecraft.class_2960 id) {
        return properties/*? if >=1.21.2 {*/.method_63500(class_5321.method_29179(class_7924.field_41254, id))/*?}*/;
    }

    static class_1792.class_1793 setupItemProperties(class_1792.class_1793 properties, RegisterListing.Holder<? extends class_1792> itemHolder) {
        return setupItemProperties(properties, itemHolder.getId());
    }

    static class_1792.class_1793 setupItemProperties(class_1792.class_1793 properties, net.minecraft.class_2960 id) {
        return properties/*? if >=1.21.2 {*/.method_63686(class_5321.method_29179(class_7924.field_41197, id)).method_63687()/*?}*/;
    }

    static class_1792.class_1793 setupBlockItemProperties(class_1792.class_1793 properties, RegisterListing.Holder<? extends class_2248> blockHolder) {
        return setupBlockItemProperties(properties, blockHolder.getId());
    }

    static class_1792.class_1793 setupBlockItemProperties(class_1792.class_1793 properties, net.minecraft.class_2960 id) {
        return properties/*? if >=1.21.2 {*/.method_63686(class_5321.method_29179(class_7924.field_41197, id)).method_63685()/*?}*/;
    }

    @FunctionalInterface
    interface BlockEntitySupplier<T extends class_2586> {
        T create(class_2338 blockPos, class_2680 blockState);
    }

    static <T extends class_2586> class_2591<T> createBlockEntityType(BlockEntitySupplier<T> supplier, class_2248... blocks) {
        return /*? if <1.21.2 {*//*BlockEntityType.Builder.of(supplier::create, blocks).build(null)*//*?} else {*/ new class_2591<>(supplier::create, Set.of(blocks))/*?}*/;
    }

    static IPlatformFluidHandler getItemFluidHandler(class_1799 container) {
        //? if fabric {
        ContainerItemContext context = ItemContainerPlatform.modifiableStackContext(container);
        Storage<FluidVariant> handStorage = FluidStorage.ITEM.find(container,context);
        if (handStorage instanceof  IPlatformFluidHandler p) return p;
        if (container.method_7909() instanceof IFluidHandlerItem<?> f) return createItemFluidHandler(f,container);
        return handStorage != null ? (FabricFluidStoragePlatform)()-> handStorage : null;
        //?} elif forge || (neoforge && <1.21.9) {
        /*IFluidHandlerItem handler = ItemContainerPlatform.getItemFluidHandler(container);
        return handler == null ? null : handler instanceof IPlatformFluidHandler f ? f : (ForgeFluidHandlerPlatform)()-> handler;
        *///?} elif neoforge {
        /*ResourceHandler<FluidResource> handler = ItemContainerPlatform.getItemFluidHandler(container);
        return handler == null ? null : handler instanceof IPlatformFluidHandler f ? f : (NeoForgeFluidHandlerPlatform)()-> handler;
        *///?} else
        /*throw new AssertionError();*/
    }

    static class_5455 getRegistryAccess() {
        return FactoryAPI.currentServer == null || isClient() && FactoryAPIClient.hasLevel() ? FactoryAPIClient.getRegistryAccess() : FactoryAPI.currentServer.method_30611();
    }

    static MinecraftServer getEntityServer(class_1297 entity) {
        return entity.method_73183().method_8503();
    }

    static IPlatformEnergyStorage getItemEnergyStorage(class_1799 stack) {
        //? if fabric {
        ContainerItemContext context = ItemContainerPlatform.modifiableStackContext(stack);
        EnergyStorage handStorage = EnergyStorage.ITEM.find(stack,context);
        if (handStorage instanceof  IPlatformEnergyStorage p) return p;
        if (stack.method_7909() instanceof IEnergyStorageItem<?>) return getItemEnergyStorage(stack,context);
        return handStorage != null ? (FabricEnergyStoragePlatform)()-> handStorage : null;
        //?} elif forge || (neoforge && <1.21.9) {
        /*IEnergyStorage storage = ItemContainerPlatform.getItemEnergyStorage(stack);
        return storage == null ? null : storage instanceof IPlatformEnergyStorage f ? f : (ForgeEnergyHandlerPlatform)()-> storage;
        *///?} elif neoforge {
        /*EnergyHandler storage = ItemContainerPlatform.getItemEnergyStorage(stack);
        return storage == null ? null : storage instanceof IPlatformEnergyStorage f ? f : (NeoForgeEnergyHandlerPlatform)()-> storage;
        *///?} else
        /*throw new AssertionError();*/
    }

    static ICraftyEnergyStorage getItemCraftyEnergyStorage(class_1799 stack) {
        //? if fabric {
        ICraftyEnergyStorage craftyStorage = CraftyEnergyStorage.ITEM.find(stack,ItemContainerPlatform.modifiableStackContext(stack));
        if (craftyStorage == null) return getItemCraftyEnergyStorageApi(stack);
        return craftyStorage;
        //?} elif forge {
        /*return stack.getCapability(FactoryCapabilities.CRAFTY_ENERGY).orElse(null);
        *///?} elif neoforge && <1.21.9 {
        /*return stack.getCapability(FactoryCapabilities.CRAFTY_ENERGY_ITEM);
        *///?} elif neoforge {
        /*return stack.getCapability(FactoryCapabilities.CRAFTY_ENERGY_ITEM, ItemAccess.forStack(stack));
        *///?} else

        /*throw new AssertionError();*/
    }

    //? if fabric {
    static IPlatformFluidHandler createItemFluidHandler(IFluidHandlerItem<?> f, class_1799 container) {
        return new FactoryItemFluidHandler(f.getCapacity(),container,f::isFluidValid,f.getTransport());
    }
    static IPlatformEnergyStorage getItemEnergyStorage(class_1799 container, ContainerItemContext context) {
        return  container.method_7909() instanceof IEnergyStorageItem<?> f  ? (FabricEnergyStoragePlatform) ()-> SimpleItemEnergyStorageImpl.createSimpleStorage(context,f.getCapacity(),f.getTransport().canInsert() ? f.getMaxReceive() : 0,f.getTransport().canExtract() ? f.getMaxConsume() : 0) : null;
    }
    static ICraftyEnergyStorage getItemCraftyEnergyStorageApi(class_1799 container) {
        return container.method_7909() instanceof ICraftyStorageItem f ? new SimpleItemCraftyStorage(container,0,f.getCapacity(), f.getMaxConsume(), f.getMaxReceive(),f.getTransport(),f.getSupportedEnergyTier(), ItemContainerPlatform.isBlockItem(container)) : null;
    }
    //?} else if forge {
    /*static <T> RegisterListing.Holder<T> deferredToRegisterHolder(RegistryObject<T> holder) {
        return new RegisterListing.Holder<>() {
            @Override
            public net.minecraft.resources.Identifier getId() {
                return holder.getId();
            }
            @Override
            public T get() {
                return holder.get();
            }
        };
    }
    static <T> T getBlockCapability(BlockEntity entity, Capability<T> capability, Direction direction) {
        return capability == null ? null : entity.getCapability(capability,direction).orElse(null);
    }
    //? if <1.21.6 {
    static IEventBus getModEventBus() {
        return FMLJavaModLoadingContext.get().getModEventBus();
    }
    static IEventBus getForgeEventBus() {
        return MinecraftForge.EVENT_BUS;
    }
    //?} else {
    /^static BusGroup getModEventBus() {
        return FMLJavaModLoadingContext.get().getModBusGroup();
    }
    static BusGroup getForgeEventBus() {
        return BusGroup.DEFAULT;
    }
    ^///?}
    *///?} else if neoforge {
    /*static <T,V extends T> RegisterListing.Holder<V> deferredToRegisterHolder(DeferredHolder<T, V> holder) {
        return new RegisterListing.Holder<>() {
            @Override
            public net.minecraft.resources.Identifier getId() {
                return holder.getId();
            }
            @Override
            public V get() {
                return holder.get();
            }
        };
    }
    static <T> T getBlockCapability(BlockEntity entity, BlockCapability<T,Direction> capability, Direction direction) {
        return capability == null ? null : capability.getCapability(entity.getLevel(),entity.getBlockPos(),entity.getBlockState(),entity, direction);
    }
    static IEventBus getModEventBus() {
        return ModLoadingContext.get().getActiveContainer().getEventBus();
    }
    static IEventBus getForgeEventBus() {
        return NeoForge.EVENT_BUS;
    }
    *///?}

    //? if forge || neoforge {
    /*//? if forge || <1.21.9 {
    static IFluidHandler.FluidAction fluidActionOf(boolean simulate) {
        return(simulate ? IFluidHandler.FluidAction.SIMULATE : IFluidHandler.FluidAction.EXECUTE);
    }
    //?}
    static FluidInstance fluidStackToInstance(FluidStack stack) {
        return new FluidInstance(stack.getFluid(),stack.getAmount());
    }
    *///?}


    static <T extends IPlatformHandler, U extends IModifiableTransportHandler & IPlatformHandler> U filteredOf(T handler, class_2350 direction, TransportState transportState, Function<T, U> sidedGetter) {
        filteredHandlersCache.entrySet().removeIf(e-> e.getKey().isRemoved());
        SideList<? super IModifiableTransportHandler> list = filteredHandlersCache.computeIfAbsent(handler, d-> new SideList<>(() -> null));
        if (!list.contains(direction)) list.put(direction,sidedGetter.apply(handler));
        list.get(direction).setTransport(transportState);
        return list.get(direction) != null ? (U)list.get(direction) : null;
    }

    static IPlatformItemHandler filteredOf(IPlatformItemHandler itemHandler, class_2350 direction, int[] slots, TransportState transportState) {
        FactoryItemHandler.SidedWrapper storage = FactoryAPIPlatform.filteredOf(itemHandler,direction,transportState,FactoryItemHandler.SidedWrapper::new);
        if (storage != null) storage.slots = slots;
        return storage;
    }

    static IPlatformFluidHandler filteredOf(IPlatformFluidHandler fluidHandler, class_2350 direction, TransportState transportState) {
        return filteredOf((FactoryFluidHandler)fluidHandler,direction,transportState,FactoryFluidHandler.SidedWrapper::new);
    }

    static IPlatformEnergyStorage filteredOf(IPlatformEnergyStorage energyStorage, class_2350 direction, TransportState transportState) {
        return filteredOf((FactoryEnergyStorage) energyStorage,direction,transportState,FactoryEnergyStorage.SidedWrapper::new);
    }

    static IFactoryStorage getPlatformFactoryStorage(class_2586 be) {
        if (be instanceof IFactoryStorage st) return st;
        FactoryAPIPlatform.platformStorageWrappersCache.entrySet().removeIf(e->e.getKey().method_11015());
        return FactoryAPIPlatform.platformStorageWrappersCache.computeIfAbsent(be, (be1)-> new IFactoryStorage() {
            @Override
            public <T extends IPlatformHandler> ArbitrarySupplier<T> getStorage(FactoryStorage<T> storage, class_2350 direction) {
                //? if fabric {
                if (storage == FactoryStorage.ITEM) {
                Storage<ItemVariant> variantStorage = ItemStorage.SIDED.find(be.method_10997(),be.method_11016(),be.method_11010(),be, direction);
                if (variantStorage != null)
                    return ()->((T)(FabricItemStoragePlatform)()-> variantStorage);
                } else if (storage == FactoryStorage.FLUID) {
                Storage<FluidVariant> variantStorage = FluidStorage.SIDED.find(be.method_10997(), be.method_11016(), be.method_11010(), be, direction);
                if (variantStorage instanceof IPlatformFluidHandler) return ()->(T) variantStorage;
                if (variantStorage!= null)
                    return ()->((T)(FabricFluidStoragePlatform) ()-> variantStorage);
                }else if (storage == FactoryStorage.ENERGY) {
                EnergyStorage energyStorage = EnergyStorage.SIDED.find(be.method_10997(), be.method_11016(), be.method_11010(), be, direction);
                      if (energyStorage instanceof IPlatformEnergyStorage) return ()->(T) energyStorage;
                      if (energyStorage!= null)
                            return ()->((T)(FabricEnergyStoragePlatform)()-> energyStorage);
                    }
                    else if (storage == FactoryStorage.CRAFTY_ENERGY) {
                        ICraftyEnergyStorage energyStorage = CraftyEnergyStorage.SIDED.find(be.method_10997(), be.method_11016(), be.method_11010(), be, direction);
                        if (energyStorage!= null) return ()->((T)energyStorage);
                    }
                //?} elif (neoforge && <1.21.9) || forge {
                /*Object handler = getBlockCapability(be,BLOCK_CAPABILITY_MAP.getKey(storage),direction);
                if (handler != null) {
                    if (storage == FactoryStorage.ENERGY)
                        return (() -> (T) (handler instanceof IPlatformEnergyStorage energyHandler ? energyHandler : (ForgeEnergyHandlerPlatform) () -> (IEnergyStorage) handler));
                    else if (storage == FactoryStorage.CRAFTY_ENERGY && handler instanceof ICraftyEnergyStorage energyHandler)
                        return (() -> (T) energyHandler);
                    else if (storage == FactoryStorage.ITEM)
                        return (() -> (T) (handler instanceof IPlatformItemHandler itemHandler ? itemHandler : (ForgeItemStoragePlatform) () -> (IItemHandler) handler));
                    else if (storage == FactoryStorage.FLUID)
                        return (() -> (T) (handler instanceof IPlatformFluidHandler fluidHandler ? fluidHandler : (ForgeFluidHandlerPlatform) () -> (IFluidHandler) handler));
                }
                *///?} else if neoforge {
                /*Object handler = getBlockCapability(be, BLOCK_CAPABILITY_MAP.getKey(storage),direction);
                if (handler != null) {
                    if (storage == FactoryStorage.ENERGY)
                        return (() -> (T) (handler instanceof IPlatformEnergyStorage energyHandler ? energyHandler : (NeoForgeEnergyHandlerPlatform) () -> (EnergyHandler) handler));
                    else if (storage == FactoryStorage.CRAFTY_ENERGY && handler instanceof ICraftyEnergyStorage energyHandler)
                        return (() -> (T) energyHandler);
                    else if (storage == FactoryStorage.ITEM)
                        return (() -> (T) (handler instanceof IPlatformItemHandler itemHandler ? itemHandler : (NeoForgeItemStoragePlatform) () -> (ResourceHandler<ItemResource>) handler));
                    else if (storage == FactoryStorage.FLUID)
                        return (() -> (T) (handler instanceof IPlatformFluidHandler fluidHandler ? fluidHandler : (NeoForgeFluidHandlerPlatform) () -> (ResourceHandler<FluidResource>) handler));
                }
                *///?}
                return ArbitrarySupplier.empty();
            }
        });
    }


    static boolean isClient() {
        return FactoryAPI.isClient();
    }

    static <A extends ArgumentType<?>, T extends class_2314.class_7217<A>, I extends class_2314<A, T>> void registerByClassArgumentType(Class<A> infoClass, I argumentTypeInfo) {
        //? if fabric {
        /*? if <1.21.11 {*//*ArgumentTypesAccessor*//*?} else {*/ArgumentTypeInfosAccessor/*?}*/.fabric_getClassMap().put(infoClass,argumentTypeInfo);
        //?} else if forge || neoforge {
        /*ArgumentTypeInfos.registerByClass(infoClass,argumentTypeInfo);
         *///?} else
        /*throw new AssertionError();*/
    }

    static <T> RegisterListing<T> createRegister(String namespace, class_2378<T> registry) {
        //? if fabric {
        return new RegisterListing<>() {
            private final List<Holder<T>> REGISTER_LIST = new ArrayList<>();

            @Override
            public Collection<Holder<T>> getEntries() {
                return REGISTER_LIST;
            }
            @Override
            public class_2378<T> getRegistry() {
                return registry;
            }
            @Override
            public String getNamespace() {
                return namespace;
            }
            @Override
            public void register() {
                forEach(o-> class_2378.method_10230(registry,o.getId(),o.get()));
            }
            @Override
            public <V extends T> Holder<V> add(String name, Function<net.minecraft.class_2960, V> supplier) {
                net.minecraft.class_2960 id = FactoryAPI.createLocation(getNamespace(), name);
                Holder<V> h = new Holder<>() {
                    V obj;
                    @Override
                    public net.minecraft.class_2960 getId() {
                        return id;
                    }

                    @Override
                    public V get() {
                        return obj == null ? (obj = supplier.apply(getId())) : obj ;
                    }
                };
                REGISTER_LIST.add((Holder<T>) h);
                return h;
            }
            @NotNull
            @Override
            public Iterator<Holder<T>> iterator() {
                return REGISTER_LIST.iterator();
            }

            @Override
            public Stream<Holder<T>> stream() {
                return REGISTER_LIST.stream();
            }
        };
        //?} else if forge || neoforge {
        /*return new RegisterListing<>() {
            private final DeferredRegister<T> REGISTER = DeferredRegister.create(registry.key(),namespace);

            @Override
            public Collection<Holder<T>> getEntries() {
                return stream().collect(Collectors.toSet());
            }
            @Override
            public Registry<T> getRegistry() {
                return registry;
            }
            @Override
            public String getNamespace() {
                return namespace;
            }
            @Override
            public void register() {
                REGISTER.register(getModEventBus());
            }
            @Override
            public <V extends T> Holder<V> add(String name, Function<net.minecraft.resources.Identifier, V> supplier) {
                return deferredToRegisterHolder(REGISTER.register(name,()-> supplier.apply(FactoryAPI.createLocation(getNamespace(), name))));
            }
            @NotNull
            @Override
            public Iterator<Holder<T>> iterator() {
                return stream().iterator();
            }

            @Override
            public Stream<Holder<T>> stream() {
                return REGISTER.getEntries().stream().map(h->(Holder<T>) deferredToRegisterHolder(h));
            }
        };
        *///?} else
        /*throw new AssertionError();*/
    }

    static String getCurrentClassName(String className) {
        //? if fabric {
        return FabricLoader.getInstance().getMappingResolver().mapClassName("official",className);
        //?} else
        //return className;
    }

    static Stream<ModInfo> getVisibleModsStream() {
        return getMods().stream().filter(info->!info.isHidden());
    }

    static Collection<ModInfo> getMods() {
        //? if fabric {
        FabricLoader.getInstance().getAllMods().forEach(m-> getModInfo(m.getMetadata().getId()));
        //?} else if forge || (neoforge && <1.21.9) {
        /*LoadingModList/^? if <26.1 || neoforge {^/.get()/^?}^/.getMods().forEach(m-> getModInfo(m.getModId()));
        *///?} else if neoforge {
        /*FMLLoader.getCurrent().getLoadingModList().getMods().forEach(m-> getModInfo(m.getModId()));
        *///?}

        return MOD_INFOS.values();
    }

    static ModInfo getModInfo(String modId) {
        return FactoryAPI.isModLoaded(modId) ? MOD_INFOS.computeIfAbsent(modId, s-> {
            //? if fabric {
            return new ModInfo() {
                Optional<ModContainer> opt = FabricLoader.getInstance().getModContainer(modId);
                @Override
                public Collection<String> getAuthors() {
                    return opt.map(c-> c.getMetadata().getAuthors().stream().map(Person::getName).toList()).orElse(Collections.emptyList());
                }

                @Override
                public Optional<String> getHomepage() {
                    return opt.flatMap(c-> c.getMetadata().getContact().get("homepage"));
                }

                @Override
                public Optional<String> getIssues() {
                    return opt.flatMap(c-> c.getMetadata().getContact().get("issues"));
                }

                @Override
                public Optional<String> getSources() {
                    return opt.flatMap(c-> c.getMetadata().getContact().get("sources"));
                }

                @Override
                public Collection<String> getCredits() {
                    return opt.map(c-> c.getMetadata().getContributors().stream().map(Person::getName).toList()).orElse(Collections.emptyList());
                }

                @Override
                public Collection<String> getLicense() {
                    return opt.map(c-> c.getMetadata().getLicense()).orElse(Collections.emptyList());
                }

                @Override
                public String getDescription() {
                    return opt.map(c->c.getMetadata().getDescription()).orElse("");
                }

                @Override
                public Optional<String> getLogoFile(int i) {
                    return opt.flatMap(c->c.getMetadata().getIconPath(i));
                }

                @Override
                public Optional<Path> findResource(String s) {
                    return opt.flatMap(c->c.findPath(s));
                }

                @Override
                public String getId() {
                    return modId;
                }

                @Override
                public String getVersion() {
                    return opt.map(c->c.getMetadata().getVersion().getFriendlyString()).orElse("");
                }

                @Override
                public String getName() {
                    return opt.map(c->c.getMetadata().getName()).orElse("");
                }

                @Override
                public boolean isHidden() {
                    return opt.isPresent() && opt.get().getMetadata().containsCustomValue("fabric-api:module-lifecycle");
                }
            };
            //?} else if forge || neoforge {
            /*return new ModInfo() {
                IModFileInfo info = ModList/^? if <26.1 || neoforge {^/.get()/^?}^/.getModFileById(modId);
                Optional<? extends ModContainer> opt = ModList/^? if <26.1 || neoforge {^/.get()/^?}^/.getModContainerById(modId);
                @Override
                public Collection<String> getAuthors() {
                    return opt.flatMap(c->c.getModInfo().getConfig().getConfigElement("authors").map(s-> Collections.singleton(String.valueOf(s)))).orElse(Collections.emptySet());
                }

                @Override
                public Optional<String> getHomepage() {
                    return opt.flatMap(c->c.getModInfo().getConfig().getConfigElement("displayURL").map(String::valueOf));
                }

                @Override
                public Optional<String> getIssues() {
                    return Optional.ofNullable(info instanceof ModFileInfo i ? i.getIssueURL() : null).map(URL::toString);
                }

                @Override
                public Optional<String> getSources() {
                    return Optional.empty();
                }

                @Override
                public Collection<String> getCredits() {
                    return opt.flatMap(c->c.getModInfo().getConfig().getConfigElement("credits").map(o-> Set.of(String.valueOf(o)))).orElse(Collections.emptySet());
                }

                @Override
                public Collection<String> getLicense() {
                    return Collections.singleton(info.getLicense());
                }

                @Override
                public String getDescription() {
                    return opt.map(c->c.getModInfo().getDescription()).orElse("");
                }

                @Override
                public Optional<String> getLogoFile(int i) {
                    return this.info.getMods().stream().filter(m->m.getModId().equals(modId)).findFirst().flatMap(IModInfo::getLogoFile);
                }

                @Override
                public Optional<Path> findResource(String s) {
                    //? if forge || (neoforge && <1.21.9) {
                    /^return Optional.of(this.info.getFile().findResource(s)).filter(Files::exists);
                     ^///?} else if neoforge {
                    /^return Optional.of(this.info.getFile().getFilePath().resolve(s));
                    ^///?}
                }

                //? if neoforge && >=1.21.9 {
                /^@Override
                public boolean containsResource(String s) {
                    return this.info.getFile().getContents().containsFile(s);
                }

                @Override
                public InputStream openResource(String s) throws IOException {
                    return this.info.getFile().getContents().openFile(s);
                }
                ^///?}

                @Override
                public String getId() {
                    return modId;
                }

                @Override
                public String getVersion() {
                    return opt.map(c->c.getModInfo().getVersion().toString()).orElse("");
                }

                @Override
                public String getName() {
                    return opt.map(c->c.getModInfo().getDisplayName()).orElse("");
                }

            };
            *///?} else
            /*throw new AssertionError();*/
        }) : null;
    }

    static boolean isPackHidden(class_3288 pack) {
        return /*? if fabric && >=1.20.4 && <1.21.11 {*/ /*((net.fabricmc.fabric.impl.resource.loader.FabricResourcePackProfile)pack).fabric_isHidden() *//*?} else {*/ false/*?}*/;
    }
}

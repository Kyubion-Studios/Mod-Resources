package wily.factoryapi.mixin.base;

import net.minecraft.class_3917;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3917.class)
public interface MenuTypeAccessor {
    @Accessor("constructor")
    class_3917.class_3918<?> getConstructor();
}

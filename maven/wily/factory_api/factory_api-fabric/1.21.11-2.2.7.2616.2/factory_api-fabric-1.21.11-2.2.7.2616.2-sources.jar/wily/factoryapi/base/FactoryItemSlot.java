package wily.factoryapi.base;

import java.util.function.Predicate;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1735;
import net.minecraft.class_1799;

public class FactoryItemSlot extends class_1735 implements IHasIdentifier {
    SlotsIdentifier identifier;

    public TransportState transportState;
    private Type type = Type.DEFAULT;
    protected Predicate<FactoryItemSlot> active = (s)-> true;


    public enum Type{
        DEFAULT,BIG;
        public int getSizedPos(int xy){
            return this == DEFAULT ? xy : xy - 4;
        }
        public int getOutPos(int xy){
            return getSizedPos(xy) -1;
        }
    }

    public FactoryItemSlot(class_1263 container, SlotsIdentifier identifier, TransportState transport, int i, int j, int k) {
        super(container, i, j, k);
        this.identifier = identifier;
        this.transportState = transport;
    }
    public FactoryItemSlot(IFactoryStorage storage, SlotsIdentifier identifier, TransportState transport, int i, int j, int k) {
        this((class_1263) storage.getStorage(FactoryStorage.ITEM).orObject(new class_1277()), identifier, transport, i, j, k);
    }

    public FactoryItemSlot withType(Type type){
        this.type = type;
        return this;
    }

    public int getCustomX(){
        return field_7873;
    }

    public int getCustomY(){
        return field_7872;
    }

    public Type getType() {
        return type;
    }

    @Override
    public boolean method_7680(class_1799 itemStack) {
        return method_7682();
    }
    @Override
    public boolean method_7682() {
        return active.test(this);
    }

    @Override
    public SlotsIdentifier identifier() {
        return identifier;
    }
}

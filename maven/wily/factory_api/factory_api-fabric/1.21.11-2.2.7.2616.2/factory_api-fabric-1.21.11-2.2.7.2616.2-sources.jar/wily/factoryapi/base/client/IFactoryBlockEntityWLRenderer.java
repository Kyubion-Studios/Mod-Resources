package wily.factoryapi.base.client;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10515;
import net.minecraft.class_1799;
import org.jetbrains.annotations.Nullable;

public interface IFactoryBlockEntityWLRenderer /*? if >=1.21.4 {*/extends class_10515<class_1799>/*?}*/ {
    //? if <1.21.9 {
    /*void renderByItemBlockState(BlockState state, ItemStack itemStack, ItemDisplayContext displayContext, PoseStack poseStack, MultiBufferSource multiBufferSource, int i, int j);
    default void renderByItem(ItemStack itemStack, ItemDisplayContext displayContext, PoseStack poseStack, MultiBufferSource multiBufferSource, int i, int j) {
        renderByItemBlockState(((BlockItem)(itemStack.getItem())).getBlock().defaultBlockState(), itemStack, displayContext, poseStack, multiBufferSource, i, j);
    }
    *///?}
    //? if >=1.21.4 {
    @Override
    default class_1799 method_65695(class_1799 itemStack) {
        return itemStack;
    }

    default MapCodec<class_10515.class_10516> createUnbakedCodec(){
        return MapCodec.unit(new class_10515.class_10516(){

            //? if >=1.21.9 {
            @Override
            public @Nullable class_10515<?> method_65698(class_11695 bakingContext) {
                return IFactoryBlockEntityWLRenderer.this;
            }
            //?} else {
            /*@Override
            public @Nullable SpecialModelRenderer<?> bake(EntityModelSet entityModelSet) {
                return IFactoryBlockEntityWLRenderer.this;
            }
            *///?}

            @Override
            public MapCodec<? extends class_10516> method_65696() {
                return createUnbakedCodec();
            }
        });
    }

    //? if <1.21.9 {
    /*@Override
    default void render(@Nullable ItemStack object, ItemDisplayContext itemDisplayContext, PoseStack poseStack, MultiBufferSource multiBufferSource, int i, int j, boolean bl) {
        renderByItem(object,itemDisplayContext,poseStack,multiBufferSource,i,j);
    }
    *///?}
    //?}
}

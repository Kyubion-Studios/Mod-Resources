//? if fabric {
package wily.factoryapi.mixin.base.fabric;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import wily.factoryapi.base.IFactoryBlock;

@Mixin(class_1922.class)
public interface BlockGetterMixin {
    @Inject(method = ("getLightEmission"), at = @At("HEAD"), cancellable = true)
    private void injectLuminance(class_2338 pos, CallbackInfoReturnable<Integer> info){
        class_1922 level = ((class_1922)this);
        if (level.method_8320(pos).method_26204() instanceof IFactoryBlock b) info.setReturnValue(b.getLightEmission(level.method_8320(pos),level,pos));
    }
}
//?}

package wily.factoryapi.base;

import net.minecraft.class_1799;
import wily.factoryapi.FactoryAPIPlatform;
import wily.factoryapi.util.FluidInstance;

public interface IFluidHandlerItem<T extends IPlatformFluidHandler> extends IFactoryItem
{
   default T getFluidStorage(class_1799 stack){
      return (T) FactoryAPIPlatform.getItemFluidHandler(stack);
   };

   int getCapacity();

   default boolean isFluidValid(FluidInstance fluidInstance){
      return true;
   }
   default TransportState getTransport(){
      return TransportState.EXTRACT_INSERT;
   }

   @Override
   default <T extends IPlatformHandler> ArbitrarySupplier<T> getStorage(FactoryStorage<T> storage, class_1799 stack) {
      if (storage == FactoryStorage.FLUID) return ArbitrarySupplier.of(new FactoryItemFluidHandler(getCapacity(),stack,this::isFluidValid,getTransport())).cast();
      return ()->null;
   }
}
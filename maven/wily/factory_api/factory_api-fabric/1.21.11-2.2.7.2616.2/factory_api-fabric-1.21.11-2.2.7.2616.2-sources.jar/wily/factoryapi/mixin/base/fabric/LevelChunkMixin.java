//? if fabric {
package wily.factoryapi.mixin.base.fabric;

import net.minecraft.class_1922;
import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2818;
import net.minecraft.class_2839;
import net.minecraft.class_3558;
import net.minecraft.world.level.chunk.*;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Redirect;
import wily.factoryapi.base.IFactoryBlock;

@Mixin(value = {class_2818.class, class_2839.class} )
public class LevelChunkMixin {
    //? if >=1.21.2 {
    @Redirect(method = "setBlockState", at = @At(value = "INVOKE", target = "Lnet/minecraft/world/level/lighting/LightEngine;hasDifferentLightProperties(Lnet/minecraft/world/level/block/state/BlockState;Lnet/minecraft/world/level/block/state/BlockState;)Z"))
    public boolean setBlockState(class_2680 blockState, class_2680 blockState1, class_2338 blockPos){
        return class_3558.method_51561(blockState,blockState1) || IFactoryBlock.getBlockLuminance(blockState, (class_1922) this,blockPos) != IFactoryBlock.getBlockLuminance(blockState1, (class_1922) this,blockPos);
    }
    //?}
}
//?}
//? if fabric {
package wily.factoryapi.base.fabric;

import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.SlottedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1799;
import net.minecraft.class_2487;
import org.jetbrains.annotations.NotNull;
import wily.factoryapi.base.IPlatformHandlerApi;
import wily.factoryapi.base.IPlatformItemHandler;
import wily.factoryapi.base.TransportState;

import java.util.function.BiPredicate;
import java.util.function.Predicate;

public interface FabricItemStoragePlatform extends IPlatformItemHandler {
    @Override
    default int method_5439() {
        int s = 0;
        for (StorageView<ItemVariant> view : getHandler())
            s++;
        return s;
    }

    @Override
    default boolean method_5442() {
        for (StorageView<ItemVariant> view : getHandler())
            if (!view.isResourceBlank()) return false;
        return true;
    }

    @Override
    default @NotNull class_1799 method_5438(int slot) {
        if (getHandler() instanceof SlottedStorage<ItemVariant> slots)
            return slots.getSlot(slot).getResource().toStack(slots.getSlotCount());
        return class_1799.field_8037;
    }

    @Override
    default class_1799 method_5441(int i) {
        if (getHandler() instanceof SlottedStorage<ItemVariant> slots){
            SingleSlotStorage<ItemVariant> slot = slots.getSlot(i);
            class_1799 stack;
            try(Transaction transaction = Transaction.openOuter()){
                stack =slot.getResource().toStack((int) slot.extract(slot.getResource(),slot.getAmount(), transaction));
                transaction.commit();
            }
            return stack;

        }
        return class_1799.field_8037;
    }

    @Override
    default void method_5447(int i, class_1799 itemStack) {
        if (getHandler() instanceof SlottedStorage<ItemVariant> slots){
            SingleSlotStorage<ItemVariant> slot = slots.getSlot(i);
            try(Transaction transaction = Transaction.openOuter()){
                slot.extract(slot.getResource(),slot.getAmount(), transaction);
                slot.insert(ItemVariant.of(itemStack),itemStack.method_7947(),transaction);
                transaction.commit();
            }
        }
    }

    @Override
    default void method_5431() {

    }

    @Override
    default @NotNull class_1799 insertItem(int i, @NotNull class_1799 stack, boolean simulate) {
        class_1799 inserted = stack;
        if (!stack.method_7960() && getHandler() instanceof SlottedStorage<ItemVariant> slots){
            SingleSlotStorage<ItemVariant> slot = slots.getSlot(i);
            try(Transaction transaction = Transaction.openOuter()){
                try (Transaction nested = transaction.openNested()){
                    int count = (int) slot.insert(ItemVariant.of(stack),stack.method_7947(),nested);
                    inserted = slot.getResource().toStack(stack.method_7947() - count);
                    if (!simulate) nested.commit();
                }
                transaction.commit();
            }
        }
        return inserted;
    }

    @Override
    default @NotNull class_1799 extractItem(int i, int amount, boolean simulate) {
        class_1799 extracted = class_1799.field_8037;
        if (amount > 0 && getHandler() instanceof SlottedStorage<ItemVariant> slots){
            SingleSlotStorage<ItemVariant> slot = slots.getSlot(i);
            ItemVariant slotVariant = slot.getResource();
            if (!slotVariant.isBlank())
                try(Transaction transaction = Transaction.openOuter()){
                    try (Transaction nested = transaction.openNested()){
                        int count = (int) slot.extract(slot.getResource(),amount,nested);
                        extracted = slotVariant.toStack(count);
                        if (!simulate) nested.commit();
                    }
                    transaction.commit();
                }
        }
        return extracted;
    }
    @Override
    default void method_5448() {
        for (StorageView<ItemVariant> view : getHandler())
            if (!view.isResourceBlank()){
                try (Transaction transaction = Transaction.openOuter()){
                    view.extract(view.getResource(),view.getAmount(),transaction);
                    transaction.commit();
                }
            }
    }


    @Override
    default TransportState getTransport() {
        return TransportState.EXTRACT_INSERT;
    }

    @Override
    default class_2487 serializeTag() {
        return new class_2487();
    }

    @Override
    default void deserializeTag(class_2487 nbt) {

    }
}
//?}

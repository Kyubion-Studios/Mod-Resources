package wily.factoryapi.mixin.base;

import net.minecraft.class_32;
import net.minecraft.server.MinecraftServer;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryEvent;
import wily.factoryapi.base.MinecraftServerAccessor;

@Mixin(MinecraftServer.class)
public abstract class MinecraftServerMixin implements MinecraftServerAccessor {
    @Inject(method = "saveEverything", at = @At("RETURN"))
    private void saveEverything(boolean bl, boolean bl2, boolean bl3, CallbackInfoReturnable<Boolean> cir) {
        FactoryEvent.ServerSave.EVENT.invoker.run((MinecraftServer) (Object)this,bl,bl2,bl3);
    }

    @Inject(method = "runServer", at = @At("HEAD"))
    private void runServer(CallbackInfo ci) {
        FactoryEvent.STARTING_SERVER_EVENT.invoker.accept((MinecraftServer) (Object) this);
    }

    @Inject(method = "<init>", at = @At("RETURN"))
    private void init(CallbackInfo ci){
        FactoryAPI.currentServer = (MinecraftServer) (Object) this;
    }

    @Accessor
    public abstract class_32.class_5143 getStorageSource();
}

//? if >=1.21.2 {
package wily.factoryapi.mixin.base;

import net.minecraft.class_10017;
import net.minecraft.class_1297;
import net.minecraft.class_897;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wily.factoryapi.base.client.FactoryRenderStateExtension;

@Mixin(class_897.class)
public class EntityRendererMixin {

    @Inject(method = "extractRenderState", at = @At("RETURN"))
    public void extractRenderState(class_1297 entity, class_10017 entityRenderState, float f, CallbackInfo ci) {
        FactoryRenderStateExtension.Accessor.of(entityRenderState).getExtensions().forEach(e-> e.tryExtractToRenderState(entity,f));
    }
}
//?}

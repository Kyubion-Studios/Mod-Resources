package wily.factoryapi.base;

import java.awt.*;
import net.minecraft.class_124;
import net.minecraft.class_2561;


public record SlotsIdentifier(class_124 color, String name,class_2561 component) implements IHasIdentifier{
    public static final SlotsIdentifier WATER = new SlotsIdentifier(class_124.field_1078,"water");
    public static final SlotsIdentifier LAVA = new SlotsIdentifier(class_124.field_1065,"lava");
    public static final SlotsIdentifier INPUT = new SlotsIdentifier(class_124.field_1078,"input");
    public static final SlotsIdentifier OUTPUT = new SlotsIdentifier(class_124.field_1061,"output");
    public static final SlotsIdentifier FUEL = new SlotsIdentifier(class_124.field_1065,"fuel");
    public static final SlotsIdentifier PURPLE = new SlotsIdentifier(class_124.field_1064,"input_output");
    public static final SlotsIdentifier ENERGY = new SlotsIdentifier(class_124.field_1075,"energy");
    public static final SlotsIdentifier GENERIC = new SlotsIdentifier(class_124.field_1080,"single");

    public Color getColor(){
        return new Color(color.method_532());
    }

    public SlotsIdentifier(class_124 color, String name){
        this(color,name,class_2561.method_43471("tooltip.factory_api.config.identifier." + name));
    }

    public String getFormattedName(){
        return component.getString();
    }
    public class_2561 getTooltip(String type){
        return class_2561.method_43469("tooltip.factory_api.config." + type, getFormattedName());
    }
    public String getName() {
        return this.name();
    }

    @Override
    public SlotsIdentifier identifier() {
        return this;
    }
}

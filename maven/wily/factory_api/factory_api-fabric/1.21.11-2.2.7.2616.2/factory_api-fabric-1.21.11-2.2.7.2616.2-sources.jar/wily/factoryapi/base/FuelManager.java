package wily.factoryapi.base;

//? fabric {
//?} else if forge {
/*import net.minecraftforge.common.ForgeHooks;
import net.minecraftforge.event.ForgeEventFactory;
import net.minecraftforge.event.furnace.FurnaceFuelBurnTimeEvent;
//? if <1.21.6 {
import net.minecraftforge.eventbus.api.EventPriority;
//?}
*///?} else if neoforge {
/*import net.neoforged.neoforge.event.furnace.FurnaceFuelBurnTimeEvent;
import net.neoforged.bus.api.EventPriority;
*///?}
//? if >=1.21.2 {
import wily.factoryapi.mixin.base.FuelValuesAccessor;
//?}
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIClient;
import wily.factoryapi.FactoryAPIPlatform;

import java.util.Collections;
import java.util.Map;
import java.util.Objects;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_9895;

public class FuelManager {

    public static int getBurnTime(class_1792 item){
        return getBurnTime(item.method_7854());
    }

    /**
     * The vanilla-registered fuels are used by Fabric, but not by Forge/NeoForge, as it allows itemstack-based fuels.
     * @return Map of the vanilla-registered fuels
     * */
    public static Map<class_1792, Integer> getMap(){
        //? if <1.21.2 {
        /*return AbstractFurnaceBlockEntity.getFuel();
        *///?} else {
        class_9895 fuelValues = getFuelValues();
        return fuelValues == null ? Collections.emptyMap() : ((FuelValuesAccessor)fuelValues).getValues();
        //?}
    }

    //? if >=1.21.2 {
    public static class_9895 getFuelValues(){
        return FactoryAPI.currentServer == null ? FactoryAPIClient.hasLevel() ? FactoryAPIClient.getLevel().method_61269() : null : FactoryAPI.currentServer.method_62735();
    }
    //?}

    public static int getBurnTime(class_1799 stack){
        if (stack.method_7960()) return 0;
        //? if forge {
        /*//? if <1.21.2 {
        return ForgeHooks.getBurnTime(stack, null);
        //?} else {
        /^FuelValues fuelValues = getFuelValues();
        int ret = stack.getBurnTime(null);
        return ForgeEventFactory.getItemBurnTime(stack, ret == -1 ? fuelValues == null ? 0 : fuelValues.burnDuration(stack) : ret, null);
        ^///?}
        *///?} else if neoforge {
        /*return stack.getBurnTime(null/^? if >1.21.2 {^/, getFuelValues()/^?}^/);
        *///?} else {
        //? if <1.21.2 {
        /*return Objects.requireNonNullElse(net.fabricmc.fabric.api.registry.FuelRegistry.INSTANCE.get(stack.getItem()), 0);
        *///?} else {
        class_9895 fuelValues = getFuelValues();
        return fuelValues == null ? 0 : fuelValues.method_61755(stack);
        //?}
        //?}
    }

    public static boolean isFuel(class_1792 item){
        return getBurnTime(item) > 0;
    }

    public static boolean isFuel(class_1799 stack){
        return isFuel(stack.method_7909());
    }

    public static void add(class_1792 item, int burnTime){
        //? if fabric {
        //? if <1.21.2 {
        /*net.fabricmc.fabric.api.registry.FuelRegistry.INSTANCE.add(item, burnTime);
        *///?} else if >=26.1 {
        /*net.fabricmc.fabric.api.registry.FuelValueEvents.BUILD.register((call, c) -> call.add(item, burnTime));
        *///?} else {
        net.fabricmc.fabric.api.registry.FuelRegistryEvents.BUILD.register((call, c)->call.method_61762(item, burnTime));
        //?}
        //?} elif (forge && <1.21.6) || neoforge {
        /*FactoryAPIPlatform.getForgeEventBus().addListener(EventPriority.NORMAL,false, FurnaceFuelBurnTimeEvent.class, e-> {
            if (e.getItemStack().is(item)) e.setBurnTime(burnTime);
        });
        *///?} elif forge {
        /*FurnaceFuelBurnTimeEvent.BUS.addListener(e-> {
            if (e.getItemStack().is(item)) e.setBurnTime(burnTime);
        });
        *///?} else
        /*throw new AssertionError();*/
    }
}

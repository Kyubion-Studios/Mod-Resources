package wily.factoryapi.util;

import com.google.common.cache.CacheBuilder;
import com.google.common.cache.CacheLoader;
import com.google.common.cache.LoadingCache;
import com.mojang.datafixers.util.Either;
import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.*;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIClient;
import wily.factoryapi.FactoryAPIPlatform;
import wily.factoryapi.base.ArbitrarySupplier;

import java.util.List;
import java.util.Map;
import java.util.Optional;
import net.minecraft.class_156;
import net.minecraft.class_1799;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_6903;
import net.minecraft.class_7923;
import net.minecraft.class_8824;
import net.minecraft.class_9326;

public class DynamicUtil {
    public static final ListMap<net.minecraft.class_2960, ArbitrarySupplier<class_1799>> COMMON_ITEMS = new ListMap<>();
    public static final LoadingCache<Pair<Dynamic<?>,Boolean>,class_1799> DYNAMIC_ITEMS_CACHE = CacheBuilder.newBuilder().build(CacheLoader.from(pair-> pair.getFirst().get("item").asString().result().or(()->pair.getFirst().asString().result()).map(s->class_7923.field_41178./*? if <1.21.2 {*//*get*//*?} else {*/method_63535/*?}*/(net.minecraft.class_2960.method_12829(s)).method_7854()).map(i-> {
        pair.getFirst().get("count").result().flatMap(d1-> Codec.INT.parse(d1).result()).ifPresent(i::method_7939);
        //? if <1.20.5 {
        /*if (pair.getSecond()) pair.getFirst().get("nbt").result().flatMap(d1-> CompoundTag.CODEC.parse(d1).result()).ifPresent(i::setTag);
        *///?} else
        if (pair.getSecond()) convertToRegistryIfPossible(pair.getFirst()).get("components").result().flatMap(d1->class_9326.field_49589.parse(d1).result()).ifPresent(i::method_57366);
        return i;
    }).orElse(class_1799.field_8037)));
    public static final LoadingCache<DynamicOps<?>,class_6903<?>> REGISTRY_OPS_CACHE = CacheBuilder.newBuilder().build(CacheLoader.from(o->class_6903.method_46632(o, FactoryAPIPlatform.getRegistryAccess())));

    public static final Codec<class_243> VEC3_OPTIONAL_CODEC = RecordCodecBuilder.create(i -> i.group(Codec.DOUBLE.fieldOf("x").orElse(0d).forGetter(class_243::method_10216),Codec.DOUBLE.fieldOf("y").orElse(0d).forGetter(class_243::method_10214),Codec.DOUBLE.fieldOf("z").orElse(0d).forGetter(class_243::method_10215)).apply(i, class_243::new));
    public static final Codec<class_243> VEC3_OBJECT_CODEC = Codec.either(VEC3_OPTIONAL_CODEC, class_243.field_38277).xmap(e-> e.map(v->v,v->v), Either::right);
    public static final Codec<class_241> VEC2_OPTIONAL_CODEC = RecordCodecBuilder.create(i -> i.group(Codec.FLOAT.fieldOf("x").orElse(0f).forGetter(vec2 -> vec2.field_1343), Codec.FLOAT.fieldOf("y").orElse(0f).forGetter(vec2 -> vec2.field_1342)).apply(i, class_241::new));
    public static final Codec<class_241> VEC2_CODEC = Codec.either(VEC2_OPTIONAL_CODEC, Codec.FLOAT.listOf().comapFlatMap((list) -> class_156.method_33141(list, 2).map((listx) -> new class_241(listx.get(0), listx.get(1))), (vec3) -> List.of(vec3.field_1343, vec3.field_1342))).xmap(e -> e.map(v->v,v->v), Either::right);

    public static final Codec<class_1799> COMPLETE_ITEM_CODEC = RecordCodecBuilder.create(i -> i.group(class_7923.field_41178.method_40294().fieldOf("item").forGetter(FactoryItemUtil::getItemHolder), Codec.INT.fieldOf("count").orElse(1).forGetter(class_1799::method_7947), /*? if <1.20.5 {*//*CompoundTag.CODEC.optionalFieldOf("nbt").forGetter((itemStack) -> Optional.ofNullable(itemStack.getTag()))*//*?} else {*/class_9326.field_49589.fieldOf("components").orElse(class_9326.field_49588).forGetter(class_1799::method_57380)/*?}*/).apply(i, /*? if >1.20.1 {*/class_1799::new/*?} else {*//*(item,count,nbt)->{ItemStack stack = new ItemStack(item,count); stack.setTag(nbt.orElse(null)); return stack;}*//*?}*/));
    public static final Codec<class_1799> ITEM_CODEC = Codec.either(class_7923.field_41178.method_40294().xmap(class_1799::new, FactoryItemUtil::getItemHolder), COMPLETE_ITEM_CODEC).xmap(e->e.right().orElseGet(e.left()::get), Either::right);
    public static Codec<ArbitrarySupplier<class_1799>> ITEM_WITHOUT_DATA_SUPPLIER_CODEC = Codec.of(ITEM_CODEC.xmap(ArbitrarySupplier::of,ArbitrarySupplier::get),DynamicUtil::getItemWithoutDataFromDynamic);
    public static Codec<ArbitrarySupplier<class_1799>> ITEM_SUPPLIER_CODEC = Codec.of(ITEM_CODEC.xmap(ArbitrarySupplier::of,ArbitrarySupplier::get),DynamicUtil::getItemFromDynamic);

    public static <T> DataResult<Pair<ArbitrarySupplier<class_1799>,T>> getItemWithoutDataFromDynamic(DynamicOps<T> ops, T input) {
        return getItemFromDynamic(ops, input, false);
    }
    public static <T> DataResult<Pair<ArbitrarySupplier<class_1799>,T>> getItemFromDynamic(DynamicOps<T> ops, T input) {
        return getItemFromDynamic(ops, input, true);
    }
    public static <T> DataResult<Pair<ArbitrarySupplier<class_1799>,T>> getItemFromDynamic(DynamicOps<T> ops, T input, boolean allowData) {
        return DataResult.success(Pair.of(getItemFromDynamic(new Dynamic<>(ops,input),allowData),input));
    }

    public static ArbitrarySupplier<class_1799> getItemFromDynamic(Dynamic<?> element, boolean allowData) {
        return element.get("common_item").asString().map(s->COMMON_ITEMS.get(net.minecraft.class_2960.method_12829(s))).result().orElseGet(()-> {
            Pair<Dynamic<?>,Boolean> pair = Pair.of(element,allowData);
            DYNAMIC_ITEMS_CACHE.refresh(pair);
            return ()-> DYNAMIC_ITEMS_CACHE.getUnchecked(pair);
        });
    }

    public static <T> Dynamic<T> convertToRegistryIfPossible(Dynamic<T> dynamic) {
        return !(dynamic.getOps() instanceof class_6903<?>) && (!FactoryAPI.isClient() || FactoryAPIClient.hasLevel()) ? dynamic.convert(getActualRegistryOps(dynamic.getOps())) : dynamic;
    }

    public static <T> DynamicOps<T> getActualRegistryOps(DynamicOps<T> ops) {
        return FactoryAPI.isClient() && !FactoryAPIClient.hasLevel() ? ops : (DynamicOps<T>) REGISTRY_OPS_CACHE.getUnchecked(ops);
    }

    public static Codec<class_2561> getComponentCodec() {
        return /*? if <=1.20.1 {*/ /*ExtraCodecs.COMPONENT *//*?} else {*/ class_8824.field_46597/*?}*/;
    }

}

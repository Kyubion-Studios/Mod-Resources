package wily.factoryapi.base;

import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Objects;
import java.util.function.BiConsumer;
import java.util.function.Supplier;
import net.minecraft.class_2350;
import net.minecraft.class_2371;

public class SideList<T extends IModifiableTransportHandler> extends class_2371<T> {


    public SideList(Supplier<T> defaultValue){
        super(new ArrayList<>(Arrays.stream(class_2350.values()).map(d->defaultValue.get()).toList()), defaultValue.get());
    }
    public T get(class_2350 direction) {
        return direction == null ? null : super.get(direction.ordinal());
    }
    public void put(class_2350 direction, T side) {
        set(direction.ordinal(),side);
    }
    public TransportState getTransport(class_2350 direction) {
        return getTransportOrDefault(direction,TransportState.NONE);
    }
    public TransportState getTransportOrDefault(@Nullable class_2350 direction, TransportState defaultState) {
        return direction == null ? defaultState : get(direction).getTransport();
    }
    public void setTransport(TransportState transportState, class_2350 direction) {
        get(direction).setTransport(transportState);
    }

    public boolean contains(class_2350 d) {
        return get(d) != null;
    }

    public void forEach(BiConsumer<class_2350,? super T> action) {
        Objects.requireNonNull(action);
        for (int i = 0; i < this.size(); i++) {
            action.accept(class_2350.values()[i],get(i));
        }
    }

}

package wily.factoryapi.base;

import net.minecraft.class_2520;

public interface ITagSerializable<T extends class_2520>
{
    T serializeTag();
    void deserializeTag(T nbt);
}
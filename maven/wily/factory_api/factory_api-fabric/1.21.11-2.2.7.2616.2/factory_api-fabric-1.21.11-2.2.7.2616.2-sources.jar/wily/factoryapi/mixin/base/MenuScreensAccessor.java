package wily.factoryapi.mixin.base;

import net.minecraft.class_1703;
import net.minecraft.class_3917;
import net.minecraft.class_3929;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_3929.class)
public interface MenuScreensAccessor {
    @Invoker("getConstructor")
    static <T extends class_1703> class_3929.class_3930<T, ?> getConstructor(class_3917<T> menuType) {
        return null;
    }
}

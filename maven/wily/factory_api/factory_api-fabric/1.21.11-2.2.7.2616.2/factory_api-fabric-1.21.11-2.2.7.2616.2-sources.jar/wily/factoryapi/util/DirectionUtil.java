package wily.factoryapi.util;


import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1542;
import net.minecraft.class_2350;
import net.minecraft.class_7833;
import org.joml.Quaternionf;

public class DirectionUtil {
    public static class_2350 nearestRotation(float rotateX, float rotateY, boolean invertYAxis){
        class_1297 entity = new class_1542(class_1299.field_6052,null);
        entity.method_36457(rotateX);
        entity.method_36456(rotateY);
        class_2350 d =class_2350.method_10159(entity)[0];
        return class_2350.class_2353.field_11064.method_10182(d) && invertYAxis ? d.method_10153() : d;
    }

    public static float rotationCyclic(float rotation){
        if (rotation> 180) return rotation - 360;
        else if ( rotation < 180) return 360 + rotation;
        return rotation;
    }
    public static float unCyclicRotation(float rotation){
        return rotation < 0 ? 360 + rotation : rotation;
    }

    public static double rotateByCenter(class_2350.class_2351 axis,double angle, double center, double centerXDistance,  double centerZDistance){
        switch (axis){
            default -> {return center;}
            case field_11048 -> {return center + centerXDistance * Math.cos(angle) - centerZDistance * Math.sin(angle);}
            case field_11051 -> {return center + centerXDistance * Math.sin(angle) + centerZDistance * Math.cos(angle);}
        }
    }
    public static double rotateZByCenter(double angle, double center, double centerXDistance,  double centerZDistance){
        return rotateByCenter(class_2350.class_2351.field_11051, angle,center,centerXDistance, centerZDistance);
    }
    public static double rotateXByCenter(double angle, double center, double centerXDistance,  double centerZDistance){
        return rotateByCenter(class_2350.class_2351.field_11048, angle,center,centerXDistance, centerZDistance);
    }

    public static Quaternionf getRotation(class_2350 direction) {
        return switch (direction) {
            case field_11033 ->  class_7833.field_40714.rotationDegrees(180.0F);
            case field_11036 -> new Quaternionf();
            case field_11043 -> class_7833.field_40714.rotationDegrees(-90.0F);
            case field_11035 -> class_7833.field_40714.rotationDegrees(90.0F);
            case field_11039 -> class_7833.field_40718.rotationDegrees(90.0F);
            case field_11034 -> class_7833.field_40718.rotationDegrees(-90.0F);
        };
    }
    public static Quaternionf getNorthRotation(class_2350 direction) {
        return switch (direction) {
            case field_11033 ->  class_7833.field_40714.rotationDegrees(-90.0F);
            case field_11036 -> class_7833.field_40714.rotationDegrees(90.0F);
            case field_11043 -> new Quaternionf();
            case field_11035 -> class_7833.field_40716.rotationDegrees(180.0F);
            case field_11039 -> class_7833.field_40716.rotationDegrees(90.0F);
            case field_11034 -> class_7833.field_40716.rotationDegrees(-90.0F);
        };
    }
    public static Quaternionf getRotationByInitial(class_2350 initial, class_2350 direction) {
        class_2350.class_2351 axis1 = initial.method_10166() == class_2350.class_2351.field_11048 ? class_2350.class_2351.field_11051 : class_2350.class_2351.field_11048;
        class_2350.class_2351 axis2 = initial.method_10166() == class_2350.class_2351.field_11052 ? class_2350.class_2351.field_11051 : class_2350.class_2351.field_11052;
        if (direction == initial.method_10153()) {return class_7833.field_40714.rotationDegrees(180.0F);}
        else if(direction == initial) return new Quaternionf();
        else if (direction == initial.method_35833(class_2350.class_2351.field_11048)) return class_7833.field_40714.rotationDegrees(-90.0F);
        else if (direction == initial.method_35834(class_2350.class_2351.field_11048)) return class_7833.field_40714.rotationDegrees(90.0F);
        if (direction == initial.method_35834(class_2350.class_2351.field_11051)) return class_7833.field_40718.rotationDegrees(90.0F);
        if (direction == initial.method_35833(class_2350.class_2351.field_11051)) return class_7833.field_40718.rotationDegrees(-90.0F);
        return new Quaternionf();
    }
    public static Quaternionf getHorizontalRotation(class_2350 direction) {
        return switch (direction) {
            case field_11043 -> new Quaternionf();
            case field_11035 -> class_7833.field_40716.rotationDegrees(180.0F);
            case field_11039 -> class_7833.field_40716.rotationDegrees(90.0F);
            case field_11034 -> class_7833.field_40716.rotationDegrees(-90.0F);
            default -> throw new IncompatibleClassChangeError();
        };
    }
}

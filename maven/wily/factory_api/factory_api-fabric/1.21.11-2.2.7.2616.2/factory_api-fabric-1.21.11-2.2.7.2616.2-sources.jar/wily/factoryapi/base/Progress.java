package wily.factoryapi.base;

import org.apache.commons.lang3.ArrayUtils;
import wily.factoryapi.util.CompoundTagUtil;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Consumer;
import net.minecraft.class_2487;

public class Progress implements ITagSerializable<class_2487> {

    public Progress.Identifier identifier;
    private final List<ProgressEntry> entries;

    public Progress(Progress.Identifier identifier, List<ProgressEntry> entries){
        this.identifier = identifier;
        this.entries = entries;
    }
    public Progress(Progress.Identifier identifier) {
        this(identifier, new ArrayList<>());
    }
    public Progress(Progress.Identifier identifier, int x, int y, int initialMaxProgress){
        this(identifier, List.of(new ProgressEntry(x,y,initialMaxProgress)));
    }
    public Progress(Progress.Identifier identifier, int entries, int defaultMaxProgress){
        this(identifier);
        for (int i = 0; i < entries; i++)
            add(0,0,defaultMaxProgress);
    }
    public Progress add(int x, int y, int maxProgress){
        entries.add(new ProgressEntry(x,y,maxProgress));
        return this;
    }
    public List<ProgressEntry> getEntries() {
        return entries;
    }
    public ProgressEntry first() {
        return get(0);
    }
    public ProgressEntry get(int index) {
        return entries.get(index);
    }

    public void forEach(Consumer<ProgressEntry> consumer){
        getEntries().forEach(consumer);
    }

    public void setValues(int[] array) {
        for (int i = 0; i < entries.size(); i++) {
            ProgressEntry p = entries.get(i);
            p.set(array[i*2]);
            p.maxProgress = array[i*2 + 1];
        }
    }
    public int[] getValues(){
        int[] values = new int[0];
        for (int i = 0; i < entries.size(); i++) {
            ProgressEntry p = entries.get(i);
            values = ArrayUtils.addAll(values,p.get(),p.maxProgress);
        }
        return values;
    }
    @Override
    public class_2487 serializeTag() {
        class_2487 compoundTag = new class_2487();
        compoundTag.method_10539(identifier.name, getValues());
        return compoundTag;
    }

    @Override
    public void deserializeTag(class_2487 tag) {
        for (int i = 0; i < entries.size(); i++) {
            ProgressEntry p = entries.get(i);
            int[] array = CompoundTagUtil.getIntArrayOrEmpty(tag, identifier.name);
            if (i * 2 < array.length) {
                p.set(array[i * 2]);
                p.maxProgress = array[i * 2 + 1];
            }
        }
    }
    public static class ProgressEntry extends Stocker<Integer>{

        public int maxProgress;

        public int x;
        public int y;
        public int minValue = 0;

        public ProgressEntry(int x, int y, int maxProgress){
            super(0);
            this.maxProgress = maxProgress;
            this.x = x;
            this.y = y;
        }
        public void set(int value){
            super.set(Math.max(minValue,Math.min(value,maxProgress)));
        }

        public int add(int value){
            int oldValue = get();
            set(get() + value);
            return get() - oldValue;
        }
        public int shrink(int value){
            int oldValue = get();
            set(get() - value);
            return oldValue - get();
        }
    }
    public record Identifier(String name) {
        public static Progress.Identifier DEFAULT = new Progress.Identifier("progress");
        public static Progress.Identifier ENERGY_STORAGE = new Progress.Identifier("energyStorage");
        public static Progress.Identifier TANK = new Progress.Identifier("tank");
        public static Progress.Identifier BURN_TIME = new Progress.Identifier("burnTime");
        public static Progress.Identifier GENERATING = new Progress.Identifier("gen");
        public static Progress.Identifier MATTER = new Progress.Identifier("matter");

    }
}

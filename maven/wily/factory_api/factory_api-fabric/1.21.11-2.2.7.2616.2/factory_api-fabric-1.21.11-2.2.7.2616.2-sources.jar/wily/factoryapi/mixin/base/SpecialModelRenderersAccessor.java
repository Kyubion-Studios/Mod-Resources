//? if >=1.21.4 {
package wily.factoryapi.mixin.base;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_10515;
import net.minecraft.class_10517;
import net.minecraft.class_5699;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_10517.class)
public interface SpecialModelRenderersAccessor {
    @Accessor("ID_MAPPER")
    static class_5699.class_10388<net.minecraft.class_2960, MapCodec<? extends class_10515.class_10516>> getIdMapper() {
        return null;
    }
}
//?}

package wily.factoryapi;

//? if fabric {
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidStorage;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariantAttributes;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.item.base.SingleItemStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StoragePreconditions;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.fabricmc.fabric.api.transfer.v1.transaction.TransactionContext;
import net.fabricmc.fabric.mixin.transfer.BucketItemAccessor;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1747;
import net.minecraft.class_1755;
import net.minecraft.class_1799;
import net.minecraft.class_3419;
import net.minecraft.class_3611;
import team.reborn.energy.api.EnergyStorage;
import org.jetbrains.annotations.Nullable;
import wily.factoryapi.base.FactoryStorage;
import wily.factoryapi.base.IFactoryItem;
import wily.factoryapi.base.IPlatformItemFluidHandler;
import wily.factoryapi.util.FluidInstance;

public interface ItemContainerPlatform {

    record ItemFluidContext(FluidInstance fluidInstance, class_1799 container) {
        public ItemFluidContext(class_1799 container) {
            this(FluidInstance.empty(),container);
        }
    }
    record ItemEnergyContext(int contextEnergy, class_1799 container) {
        public ItemEnergyContext(class_1799 container) {
            this(0,container);
        }
    }

    static boolean isBlockItem(class_1799 s) {return s.method_7909() instanceof class_1747;}

  
    static class_3611 getBucketFluid(class_1755 item) {
        //? if fabric && >=26.1 {
        /*return ((BucketItemAccessor)item).fabric_getContent();
        *///?} else if fabric {
        return ((BucketItemAccessor)item).fabric_getFluid();
        //?} elif forge || neoforge && <1.21 {
        /*return item.getFluid();
         *///?} else if neoforge {
        /*return item.content;
        *///?} else
        //throw new AssertionError();
    }

    static boolean isFluidContainer(class_1799 stack) {
        //? if fabric {
        return FluidStorage.ITEM.find(stack, modifiableStackContext(stack)) != null;
        //?} elif forge || neoforge {
        /*return !stack.isEmpty() && getItemFluidHandler(stack) != null;
        *///?} else
        /*throw new AssertionError();*/
    }

    static boolean isEnergyContainer(class_1799 stack) {
        //? if fabric {
        return EnergyStorage.ITEM.find(stack,modifiableStackContext(stack)) != null;
        //?} elif forge || neoforge {
        /*return !stack.isEmpty() && getItemEnergyStorage(stack) != null;
        *///?} else
        /*throw new AssertionError();*/
    }

    static FluidInstance getFluid(class_1799 stack) {
        //? if fabric {
        return getFluid(stack, modifiableStackContext(stack));
        //?} elif forge || (neoforge && <1.21.9) {
        /*return isFluidContainer(stack) ? FactoryAPIPlatform.fluidStackToInstance(getItemFluidHandler(stack).getFluidInTank(0)) : FluidInstance.empty();
        *///?} elif neoforge {
        /*ResourceHandler<FluidResource> fluidHandler = getItemFluidHandler(stack);
        return fluidHandler != null ? FluidInstance.create(fluidHandler.getResource(0).getFluid(), fluidHandler.getAmountAsInt(0)) : FluidInstance.empty();
        *///?} else
        /*throw new AssertionError();*/
    }

    static FluidInstance getFluid(class_1657 player, class_1268 hand) {
        //? if fabric {
        return getFluid(player.method_5998(hand), ContainerItemContext.ofPlayerHand(player, hand));
        //?} elif forge || neoforge {
        /*return getFluid(player.getItemInHand(hand));
        *///?} else
        /*throw new AssertionError();*/
    }

    static int fillItem(FluidInstance fluidInstance, class_1657 player, class_1268 hand) {
        //? if fabric {
        return fillItem(fluidInstance, player.method_5998(hand), ContainerItemContext.ofPlayerHand(player, hand), player).fluidInstance().getAmount();
         //?} elif forge || neoforge {
        /*return fillItem(player.getItemInHand(hand), player,hand,fluidInstance).fluidInstance().getAmount();
        *///?} else
        /*throw new AssertionError();*/
    }

    static ItemFluidContext fillItem(class_1799 stack, FluidInstance fluidInstance) {
        //? if fabric {
        return fillItem(fluidInstance, stack, modifiableStackContext(stack), null);
         //?} elif forge || neoforge {
        /*return fillItem(stack, null, null,fluidInstance);
        *///?} else
        /*throw new AssertionError();*/
    }

    static FluidInstance drainItem(int maxDrain, class_1657 player, class_1268 hand) {
        //? if fabric {
        return drainItem(maxDrain,player.method_5998(hand), ContainerItemContext.ofPlayerHand(player, hand), player).fluidInstance();
         //?} elif forge || neoforge {
        /*return drainItem(maxDrain, player.getItemInHand(hand), player, hand).fluidInstance();
        *///?} else
        /*throw new AssertionError();*/
    }

    static ItemFluidContext drainItem(int maxDrain, class_1799 stack) {
        //? if fabric {
        return drainItem(maxDrain, stack, modifiableStackContext(stack),null);
         //?} elif forge || neoforge {
        /*return drainItem(maxDrain, stack, null, null);
        *///?} else
        /*throw new AssertionError();*/
    }

    static int insertEnergy(int energy, class_1657 player, class_1268 hand) {
        //? if fabric {
        return insertEnergy(energy,ContainerItemContext.ofPlayerHand(player,hand),player).contextEnergy();
         //?} elif forge || neoforge {
        /*return insertEnergy(energy, player.getItemInHand(hand)).contextEnergy();
        *///?} else
        /*throw new AssertionError();*/
    }

    static ItemEnergyContext insertEnergy(int energy, class_1799 stack) {
        //? if fabric {
        return insertEnergy(energy, modifiableStackContext(stack),null);
         //?} elif forge || (neoforge && <1.21.9) {
        /*return new ItemEnergyContext(getItemEnergyStorage(stack).receiveEnergy(energy,false),stack);
        *///?} elif neoforge {
        /*try (Transaction transaction = Transaction.open(null))
        {
            int insert = getItemEnergyStorage(stack).insert(energy, transaction);
            transaction.commit();
            return new ItemEnergyContext(insert, stack);
        }
        *///?} else
        /*throw new AssertionError();*/
    }

    static int extractEnergy(int energy, class_1657 player, class_1268 hand) {
        //? if fabric {
        return extractEnergy(energy,ContainerItemContext.ofPlayerHand(player,hand),player).contextEnergy();
         //?} elif forge || neoforge {
        /*return extractEnergy(energy, player.getItemInHand(hand)).contextEnergy();
        *///?} else
        /*throw new AssertionError();*/
    }

    static ItemEnergyContext extractEnergy(int energy, class_1799 stack) {
        //? if fabric {
        return extractEnergy(energy, modifiableStackContext(stack),null);
         //?} elif forge || (neoforge && <1.21.9) {
        /*return new ItemEnergyContext(getItemEnergyStorage(stack).extractEnergy(energy,false),stack);
        *///?} elif neoforge {
        /*try (Transaction transaction = Transaction.open(null))
        {
            int insert = getItemEnergyStorage(stack).extract(energy, transaction);
            transaction.commit();
            return new ItemEnergyContext(insert, stack);
        }
        *///?} else
        /*throw new AssertionError();*/
    }

    static int getEnergy(class_1799 stack) {
        //? if fabric {
        EnergyStorage handStorage = modifiableStackContext(stack).find(EnergyStorage.ITEM);
        if (handStorage != null)
            return (int) handStorage.getAmount();
        return 0;
         //?} elif forge || (neoforge && <1.21.9) {
        /*return isEnergyContainer(stack) ? 0 : getItemEnergyStorage(stack).getEnergyStored();
        *///?} elif neoforge {
        /*return isEnergyContainer(stack) ? 0 : getItemEnergyStorage(stack).getAmountAsInt();
        *///?} else
        /*throw new AssertionError();*/
    }

    //? if fabric {
    static ContainerItemContext modifiableStackContext(class_1799 stack) {
        return ContainerItemContext.ofSingleSlot(new SingleItemStorage() {
            class_1799 itemStack = stack;
            @Override
            public ItemVariant getResource() {
                return ItemVariant.of(itemStack);
            }
            public long getAmount() {
                return itemStack.method_7947();
            }
            @Override
            public boolean isResourceBlank() {
                return itemStack.method_7960();
            }
            @Override
            protected long getCapacity(ItemVariant variant) {
                return itemStack.method_7914();
            }
            @Override
            public long insert(ItemVariant insertedVariant, long maxAmount, TransactionContext transaction) {
                StoragePreconditions.notBlankNotNegative(insertedVariant, maxAmount);
                if (insertedVariant.isOf(itemStack.method_7909())) {
                    int oldCount = itemStack.method_7947();
                    itemStack.method_7933(Math.min(stack.method_7914(), (int) maxAmount));
                    return itemStack.method_7947() - oldCount;
                }else if (itemStack.method_7960())
                    return (itemStack = insertedVariant.toStack(Math.min(itemStack.method_7914(),(int) maxAmount))).method_7947();
                return 0;
            }
            @Override
            public long extract(ItemVariant extractedVariant, long maxAmount, TransactionContext transaction) {
                StoragePreconditions.notBlankNotNegative(extractedVariant, maxAmount);
                if (extractedVariant.isOf(itemStack.method_7909())) {
                    int oldCount = itemStack.method_7947();
                    itemStack.method_7934(Math.max(itemStack.method_7947(),(int)maxAmount));
                    return oldCount - itemStack.method_7947();
                }
                return 0;
            }
        });
    }

    static FluidInstance getFluid(class_1799 stack, ContainerItemContext context) {
        Storage<FluidVariant> handStorage = FluidStorage.ITEM.find(stack, context);
        if (handStorage != null) {
            for (StorageView<FluidVariant> view : handStorage )
                return FluidInstance.create(view.getResource().getFluid(),view.getAmount());
        }
        return FluidInstance.empty();
    }

    static ItemFluidContext fillItem(FluidInstance fluidInstance, class_1799 stack, ContainerItemContext context, @Nullable class_1657 player) {
        long amount = fluidInstance.getPlatformAmount();
        StoragePreconditions.notBlankNotNegative(FluidVariant.of(fluidInstance.getFluid()), amount);
        Storage<FluidVariant> handStorage = FluidStorage.ITEM.find(stack,context);

        if (handStorage != null)
            try (Transaction transaction = Transaction.openOuter()) {
                try (Transaction nested = transaction.openNested()) {
                    fluidInstance.setAmount(handStorage.insert(FluidVariant.of(fluidInstance.getFluid()), amount, nested));
                    if (player != null) {
                         player.method_73183().method_43128(null, player.method_23317(), player.method_23318() + 0.5, player.method_23321(), FluidVariantAttributes.getFillSound(FluidVariant.of(fluidInstance.getFluid())), class_3419.field_15248, 1.0F, 1.0F);
                        if (!player.method_68878()) nested.commit();
                    }else nested.commit();
                }
                transaction.commit();
                return new ItemFluidContext(fluidInstance, context.getItemVariant().toStack((int) context.getAmount()));
            }
        return new ItemFluidContext( context.getItemVariant().toStack((int) context.getAmount()));
    }

    static ItemFluidContext drainItem(int maxDrain, class_1799 stack, ContainerItemContext context, @Nullable class_1657 player) {
        Storage<FluidVariant> handStorage = FluidStorage.ITEM.find(stack,context);

       if (handStorage != null) {
            for (StorageView<FluidVariant> view : handStorage) {
                if (view.isResourceBlank()) continue;
                FluidVariant storedResource = view.getResource();
                try (Transaction transaction = Transaction.openOuter()) {
                    long amount;
                    try (Transaction nested = transaction.openNested()) {
                        amount = view.extract(storedResource, FluidInstance.getPlatformFluidAmount(maxDrain), nested);
                        if (player != null) {
                            if (amount > 0) player.method_73183().method_43128(null, player.method_23317(), player.method_23318() + 0.5, player.method_23321(), FluidVariantAttributes.getEmptySound(storedResource), class_3419.field_15245, 1.0F, 1.0F);
                            if (!player.method_68878()) nested.commit();
                        } else nested.commit();
                    }
                    transaction.commit();
                    return new ItemFluidContext(FluidInstance.create(storedResource.getFluid(), amount), context.getItemVariant().toStack((int) context.getAmount()));
                }
            }
        }
        return new ItemFluidContext(context.getItemVariant().toStack((int) context.getAmount()));
    }

    static ItemEnergyContext insertEnergy(int energy, ContainerItemContext context, class_1657 player) {
        StoragePreconditions.notNegative(energy);
        EnergyStorage handStorage = context.find(EnergyStorage.ITEM);
        if (handStorage != null)
            try (Transaction transaction = Transaction.openOuter()) {
                try (Transaction nested = transaction.openNested()) {
                    energy = (int) handStorage.insert(energy, nested);
                    if (player == null ||!player.method_68878()) nested.commit();
                }
                transaction.commit();
                return new ItemEnergyContext(energy,context.getItemVariant().toStack((int) context.getAmount()));
            }
        return new ItemEnergyContext(0,context.getItemVariant().toStack((int) context.getAmount()));
    }

    static ItemEnergyContext extractEnergy(int energy, ContainerItemContext context, class_1657 player) {
        StoragePreconditions.notNegative(energy);
        EnergyStorage handStorage = context.find(EnergyStorage.ITEM);
        if (handStorage != null)
            try (Transaction transaction = Transaction.openOuter()) {
                int amount;
                try (Transaction nested = transaction.openNested()) {
                    amount = (int) handStorage.extract(energy, nested);
                    if (player == null ||!player.method_68878()) nested.commit();
                }
                transaction.commit();
                return new ItemEnergyContext(amount,context.getItemVariant().toStack((int) context.getAmount()));
            }
        return new ItemEnergyContext(0,context.getItemVariant().toStack((int) context.getAmount()));
    }
    //?} elif forge {
    /*static IFluidHandlerItem getItemFluidHandler(ItemStack stack) {
        return stack.getCapability(ForgeCapabilities.FLUID_HANDLER_ITEM).orElse(null);
    }
    static IEnergyStorage getItemEnergyStorage(ItemStack stack) {
        return stack.getCapability(ForgeCapabilities.ENERGY).orElse(null);
    }
    *///?} elif neoforge && <1.21.9 {
    /*static IFluidHandlerItem getItemFluidHandler(ItemStack stack) {
        return stack.getCapability(Capabilities.FluidHandler.ITEM);
    }
    static IEnergyStorage getItemEnergyStorage(ItemStack stack) {
        return stack.getCapability(Capabilities.EnergyStorage.ITEM);
    }
    *///?} elif neoforge {
    /*static ResourceHandler<FluidResource> getItemFluidHandler(ItemStack stack) {
        return stack.getCapability(Capabilities.Fluid.ITEM, ItemAccess.forStack(stack));
    }
    static EnergyHandler getItemEnergyStorage(ItemStack stack) {
        return stack.getCapability(Capabilities.Energy.ITEM, ItemAccess.forStack(stack));
    }
    *///?}
    //? if forge || (neoforge && <1.21.9) {
    /*static ItemFluidContext fillItem(ItemStack stack, Player player, InteractionHand hand, FluidInstance fluidInstance) {
        if (!isFluidContainer(stack) || (player == null && stack.getCount() != 1)) return new ItemFluidContext(stack);
        IFluidHandler.FluidAction action = FactoryAPIPlatform.fluidActionOf((player !=null && player.isCreative()));
        ItemStack toFill = action.execute() ? stack.copyWithCount(1) : stack.copy();
        IFluidHandlerItem tank = getItemFluidHandler(toFill);
        int amount = tank.fill(fluidInstance.toStack(), action);
        if(player != null && amount > 0) {
            if (action.execute()) {
                if (stack.getCount() > 1) {
                    player.setItemInHand(hand, stack.copyWithCount(stack.getCount() - 1));
                    player.addItem(tank.getContainer());
                } else player.setItemInHand(hand, tank.getContainer());
            }
            SoundEvent sound = fluidInstance.getFluid().getFluidType().getSound(fluidInstance.toStack(), SoundActions.BUCKET_FILL);
            if (sound != null) player.level().playSound(null, player.getX(), player.getY() + 0.5, player.getZ(),sound , SoundSource.PLAYERS, 0.6F, 0.8F);
        }
        return new ItemFluidContext(FluidInstance.create(fluidInstance.getFluid(),amount),tank.getContainer());
    }
    static ItemFluidContext drainItem(int maxDrain, ItemStack stack, Player player, InteractionHand hand) {
        if (!isFluidContainer(stack) || (player == null && stack.getCount() != 1)) return new ItemFluidContext(stack);
        IFluidHandler.FluidAction action = FactoryAPIPlatform.fluidActionOf((player !=null && player.isCreative()));
        ItemStack toDrain = action.execute() ? stack.copyWithCount(1) : stack.copy();
        IFluidHandlerItem tank = getItemFluidHandler(toDrain);
        FluidStack fluidStack = tank.drain(maxDrain, action);
        if(player != null && fluidStack.getAmount() > 0) {
            if (action.execute()) {
                if (stack.getCount() > 1) {
                    player.setItemInHand(hand, stack.copyWithCount(stack.getCount() - 1));
                    player.addItem(tank.getContainer());
                } else player.setItemInHand(hand, tank.getContainer());
            }
            SoundEvent sound = fluidStack.getFluid().getFluidType().getSound(fluidStack, SoundActions.BUCKET_EMPTY);
            if (sound != null) player.level().playSound(null, player.getX(), player.getY() + 0.5, player.getZ(),sound , SoundSource.PLAYERS, 0.6F, 0.8F);
        }

        return new ItemFluidContext(FluidInstance.create(fluidStack.getFluid(),fluidStack.getAmount()),tank.getContainer());
    }
    *///?} else if neoforge {
    /*static ItemFluidContext fillItem(ItemStack stack, Player player, InteractionHand hand, FluidInstance fluidInstance) {
        if (!isFluidContainer(stack) || (player == null && stack.getCount() != 1)) return new ItemFluidContext(stack);

        boolean simulate = (player != null && player.isCreative());
        ResourceHandler<FluidResource> tank = stack.getCapability(Capabilities.Fluid.ITEM, player == null ? ItemAccess.forStack(stack) : ItemAccess.forPlayerInteraction(player, hand));
        
        try (Transaction transaction = Transaction.open(null)) {
            int amount = tank.insert(FluidResource.of(fluidInstance.toStack()), fluidInstance.getAmount(), transaction);
            if (!simulate) transaction.commit();
            if(player != null && amount > 0) {
                SoundEvent sound = fluidInstance.getFluid().getFluidType().getSound(fluidInstance.toStack(), SoundActions.BUCKET_FILL);
                if (sound != null) player.level().playSound(null, player.getX(), player.getY() + 0.5, player.getZ(),sound , SoundSource.PLAYERS, 0.6F, 0.8F);
            }
            return new ItemFluidContext(FluidInstance.create(fluidInstance.getFluid(),amount), player == null ? stack : player.getItemInHand(hand));
        }
    }

    static ItemFluidContext drainItem(int maxDrain, ItemStack stack, Player player, InteractionHand hand) {
        if (!isFluidContainer(stack) || (player == null && stack.getCount() != 1)) return new ItemFluidContext(stack);

        boolean simulate = (player != null && player.isCreative());
        ResourceHandler<FluidResource> tank = stack.getCapability(Capabilities.Fluid.ITEM, player == null ? ItemAccess.forStack(stack) : ItemAccess.forPlayerInteraction(player, hand));

        try (Transaction transaction = Transaction.open(null)) {
            FluidResource resource = tank.getResource(0);
            int amount = tank.extract(resource, maxDrain, transaction);
            if (!simulate) transaction.commit();
            if (player != null && amount > 0) {
                SoundEvent sound = resource.getFluid().getFluidType().getSound(resource.toStack(amount), SoundActions.BUCKET_EMPTY);
                if (sound != null)
                    player.level().playSound(null, player.getX(), player.getY() + 0.5, player.getZ(), sound, SoundSource.PLAYERS, 0.6F, 0.8F);
            }

            return new ItemFluidContext(FluidInstance.create(resource.getFluid(), amount),  player == null ? stack : player.getItemInHand(hand));

        }
    }
    *///?}


}

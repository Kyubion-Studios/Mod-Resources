package wily.factoryapi.base.client;

import net.minecraft.class_1799;
import net.minecraft.class_310;
import net.minecraft.class_329;
import net.minecraft.class_365;
import wily.factoryapi.util.FactoryScreenUtil;

public interface GuiAccessor {
    class_1799 getLastToolHighlight();

    int getToolHighlightTimer();

    class_365 getSpectatorGui();

    //~ if >=26.2 'Gui gui' -> 'Hud gui'
    static GuiAccessor of(class_329 gui){
        return (GuiAccessor) gui;
    }

    static GuiAccessor getInstance(){
        return of(FactoryScreenUtil.getGuiOrHud(class_310.method_1551()));
    }
}

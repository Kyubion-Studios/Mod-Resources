package wily.factoryapi.base.network;

import net.minecraft.class_1799;
import net.minecraft.class_1860;
import net.minecraft.class_1863;
import net.minecraft.class_1937;
import net.minecraft.class_2540;
import net.minecraft.class_3956;
import net.minecraft.class_7923;
import net.minecraft.class_8786;
import net.minecraft.class_9695;
//? if >1.20.1 {
//?}
import net.minecraft.world.item.crafting.*;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIPlatform;
import wily.factoryapi.base.network.CommonNetwork;
import java.util.*;
import java.util.function.Function;
import java.util.function.Supplier;
import java.util.stream.Collectors;

public class CommonRecipeManager {

    public static <R extends class_1860<?>> /*? if >1.20.1 {*/class_8786<R>/*?} else {*//*R*//*?}*/ byId(net.minecraft.class_2960 id, class_3956<R> type) {
        return (/*? if >1.20.1 {*/class_8786<R>/*?} else {*//*R*//*?}*/)/*? if <1.21.2 {*//*getRecipeManager().byKey(id).orElse(null)*//*?} else {*/recipesByType.getOrDefault(type, Collections.emptyMap()).get(id)/*?}*/;
    }

    public static <R extends class_1860<?>> Collection</*? if >1.20.1 {*/class_8786<R>/*?} else {*//*R*//*?}*/> byType(class_3956<R> type) {
        return /*? if <1.21.2 {*/ /*((RecipeManagerAccessor)getRecipeManager()).getRecipeByType(type)/^? if <1.20.5 {^//^.values()^//^?}^/*//*?} else {*/(Collection) recipesByType.get(type).values()/*?}*/;
    }

    public static <R extends class_1860<I>, I extends /*? if <1.20.5 {*//*Container*//*?} else {*/class_9695/*?}*/> Optional</*? if >1.20.1 {*/class_8786<R>/*?} else {*//*R*//*?}*/> getRecipeFor(class_3956<R> type, I input, class_1937 level) {
        Collection</*? if >1.20.1 {*/class_8786<R>/*?} else {*//*R*//*?}*/> recipes = byType(type);
        for (/*? if >1.20.1 {*/class_8786<R>/*?} else {*//*R*//*?}*/ recipe : recipes) {
            if (recipe/*? if >1.20.1 {*/.comp_1933()/*?}*/.method_8115(input,level)) return Optional.of(recipe);
        }
        return Optional.empty();
    }
    public static <R extends class_1860<I>, I extends /*? if <1.20.5 {*//*Container*//*?} else {*/class_9695/*?}*/> Optional<class_1799> getResultFor(class_3956<R> type, I input, class_1937 level) {
        return getRecipeFor(type,input,level).map(r->r/*? if >1.20.1 {*/.comp_1933()/*?}*/.method_8116(input/*? if <26.1 {*/,level.method_30349()/*?}*/));
    }

    //? if <1.21.2 {
    /*public static RecipeManager getRecipeManager(){
        return FactoryAPI.currentServer == null ? FactoryAPIClient.getRecipeManager() : FactoryAPI.currentServer.getRecipeManager();
    }
    *///?}

    //? if >=1.21.2 {
    private static final Set<class_3956<?>> recipeTypesToSync = new HashSet<>();
    private static Map<class_3956<?>,Map<net.minecraft.class_2960,class_8786<?>>> recipesByType = Collections.emptyMap();

    public static void updateRecipes(class_1863 manager){
        recipesByType = manager.method_8126().stream().collect(Collectors.groupingBy(h->h.comp_1933().method_17716(),Collectors.toMap(h->h.comp_1932()./*? if <1.21.11 {*/method_29177/*?} else {*//*identifier*//*?}*/(), Function.identity())));
        for (class_3956<?> recipeType : recipeTypesToSync) {
            ClientPayload.getInstance().syncRecipeTypes.put(recipeType, recipesByType.get(recipeType));
        }
    }

    public static void clearRecipes(){
        recipesByType = Collections.emptyMap();
        ClientPayload.getInstance().syncRecipeTypes.clear();
    }

    public static boolean canSyncType(class_3956<?> type){
        return recipeTypesToSync.contains(type);
    }

    public static void addRecipeTypeToSync(class_3956<?> recipeType){
        recipeTypesToSync.add(recipeType);
    }

    public record ClientPayload(Map<class_3956<?>,Map<net.minecraft.class_2960,class_8786<?>>> syncRecipeTypes) implements CommonNetwork.Payload {
        public static final CommonNetwork.Identifier<ClientPayload> ID = CommonNetwork.Identifier.create(FactoryAPI.createModLocation("send_client_recipes"), ClientPayload::new);
        private static final ClientPayload instance = new ClientPayload(new HashMap<>());

        public static ClientPayload getInstance(){
            return instance;
        }

        public ClientPayload(CommonNetwork.PlayBuf buf){
            this(buf.get().method_34067(b->b.method_52962(class_7923.field_41188::method_10200), b->b.method_34067(class_2540::method_10810, b1->class_8786.field_48357.decode(buf.get()))));
        }

        @Override
        public void apply(Context context) {
            recipesByType = syncRecipeTypes;
        }

        @Override
        public CommonNetwork.Identifier<? extends CommonNetwork.Payload> identifier() {
            return ID;
        }

        @Override
        public void encode(CommonNetwork.PlayBuf buf) {
            buf.get().method_34063(syncRecipeTypes, (b,t)-> b.method_52963(class_7923.field_41188::method_10206,t),(b,t)-> b.method_34063(t,class_2540::method_10812,(b1,h)->class_8786.field_48357.encode(buf.get(),h)));
        }
    }
    //?}
}

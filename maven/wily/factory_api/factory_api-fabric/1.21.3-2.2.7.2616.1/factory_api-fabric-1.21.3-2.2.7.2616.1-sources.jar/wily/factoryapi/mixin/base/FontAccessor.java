package wily.factoryapi.mixin.base;

import net.minecraft.class_2960;
import net.minecraft.class_327;
import net.minecraft.class_377;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_327.class)
public interface FontAccessor {
    //? if <1.21.9 {
    @Invoker("getFontSet")
    class_377 getDefaultFontSet(class_2960 arg);
    @Accessor
    boolean getFilterFishyGlyphs();
    //?} else {
    /*@Invoker("getGlyph")
    BakedGlyph getBakedGlyph(int i, Style style);
    *///?}
}

package wily.factoryapi.base.client;

import com.mojang.serialization.MapCodec;
import net.minecraft.class_1747;
import net.minecraft.class_1799;
import net.minecraft.class_2680;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_811;
import org.jetbrains.annotations.Nullable;

public interface IFactoryBlockEntityWLRenderer /*? if >=1.21.4 {*//*extends SpecialModelRenderer<ItemStack>*//*?}*/ {
    //? if <1.21.9 {
    void renderByItemBlockState(class_2680 state, class_1799 itemStack, class_811 displayContext, class_4587 poseStack, class_4597 multiBufferSource, int i, int j);
    default void renderByItem(class_1799 itemStack, class_811 displayContext, class_4587 poseStack, class_4597 multiBufferSource, int i, int j) {
        renderByItemBlockState(((class_1747)(itemStack.method_7909())).method_7711().method_9564(), itemStack, displayContext, poseStack, multiBufferSource, i, j);
    }
    //?}
    //? if >=1.21.4 {
    /*@Override
    default ItemStack extractArgument(ItemStack itemStack) {
        return itemStack;
    }

    default MapCodec<SpecialModelRenderer.Unbaked> createUnbakedCodec(){
        return MapCodec.unit(new SpecialModelRenderer.Unbaked(){

            //? if >=1.21.9 {
            /^@Override
            public @Nullable SpecialModelRenderer<?> bake(BakingContext bakingContext) {
                return IFactoryBlockEntityWLRenderer.this;
            }
            ^///?} else {
            @Override
            public @Nullable SpecialModelRenderer<?> bake(EntityModelSet entityModelSet) {
                return IFactoryBlockEntityWLRenderer.this;
            }
            //?}

            @Override
            public MapCodec<? extends Unbaked> type() {
                return createUnbakedCodec();
            }
        });
    }

    //? if <1.21.9 {
    @Override
    default void render(@Nullable ItemStack object, ItemDisplayContext itemDisplayContext, PoseStack poseStack, MultiBufferSource multiBufferSource, int i, int j, boolean bl) {
        renderByItem(object,itemDisplayContext,poseStack,multiBufferSource,i,j);
    }
    //?}
    *///?}
}

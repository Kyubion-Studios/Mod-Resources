package wily.factoryapi.util;

import java.util.Optional;
import net.minecraft.class_2487;

public class CompoundTagUtil {

    public static class_2487 getCompoundTagOrEmpty(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getCompoundOrEmpty(name)*//*?} else {*/tag.method_10562(name)/*?}*/;
    }

    public static Optional<class_2487> getCompoundTag(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getCompound(name)*//*?} else {*/tag.method_10545(name) ? Optional.of(tag.method_10562(name)) : Optional.empty()/*?}*/;
    }

    public static Optional<Boolean> getBoolean(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getBoolean(name)*//*?} else {*/tag.method_10545(name) ? Optional.of(tag.method_10577(name)): Optional.empty()/*?}*/;
    }

    public static Optional<Byte> getByte(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getByte(name)*//*?} else {*/tag.method_10545(name) ? Optional.of(tag.method_10571(name)) : Optional.empty()/*?}*/;
    }

    public static Optional<Integer> getInt(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getInt(name)*//*?} else {*/tag.method_10545(name) ? Optional.of(tag.method_10550(name)) : Optional.empty()/*?}*/;
    }

    public static Optional<Long> getLong(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getLong(name)*//*?} else {*/tag.method_10545(name) ? Optional.of(tag.method_10537(name)) : Optional.empty()/*?}*/;
    }

    public static Optional<Float> getFloat(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getFloat(name)*//*?} else {*/tag.method_10545(name) ? Optional.of(tag.method_10583(name)) : Optional.empty()/*?}*/;
    }

    public static Optional<Double> getDouble(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getDouble(name)*//*?} else {*/tag.method_10545(name) ? Optional.of(tag.method_10574(name)) : Optional.empty()/*?}*/;
    }

    public static Optional<byte[]> getByteArray(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getByteArray(name)*//*?} else {*/tag.method_10545(name) ? Optional.of(tag.method_10547(name)) : Optional.empty()/*?}*/;
    }

    public static Optional<int[]> getIntArray(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getIntArray(name)*//*?} else {*/tag.method_10545(name) ? Optional.of(tag.method_10561(name)) : Optional.empty()/*?}*/;
    }

    public static Optional<long[]> getLongArray(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getLongArray(name)*//*?} else {*/tag.method_10545(name) ? Optional.of(tag.method_10565(name)) : Optional.empty()/*?}*/;
    }

    public static byte[] getByteArrayOrEmpty(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getByteArray(name).orElseGet(()->new byte[0])*//*?} else {*/tag.method_10547(name)/*?}*/;
    }

    public static int[] getIntArrayOrEmpty(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getIntArray(name).orElseGet(()->new int[0])*//*?} else {*/tag.method_10561(name)/*?}*/;
    }

    public static long[] getLongArrayOrEmpty(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getLongArray(name).orElseGet(()->new long[0])*//*?} else {*/tag.method_10565(name)/*?}*/;
    }

    public static Optional<String> getString(class_2487 tag, String name){
        return /*? if >1.21.4 {*//*tag.getString(name)*//*?} else {*/tag.method_10545(name) ? Optional.of(tag.method_10558(name)) : Optional.empty()/*?}*/;
    }
}

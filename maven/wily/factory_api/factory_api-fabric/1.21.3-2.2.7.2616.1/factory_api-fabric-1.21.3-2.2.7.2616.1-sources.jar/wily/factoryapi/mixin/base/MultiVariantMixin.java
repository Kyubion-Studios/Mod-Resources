package wily.factoryapi.mixin.base;

//?} else if <26.1 {
/*import net.minecraft.util.random.WeightedList;
import net.minecraft.client.renderer.block.model.BlockStateModel;
import net.minecraft.client.resources.model.WeightedVariants;
*///?} else {
/*import net.minecraft.util.random.WeightedList;
import net.minecraft.client.renderer.block.dispatch.BlockStateModel;
import net.minecraft.client.renderer.block.dispatch.WeightedVariants;
*///?}
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Mutable;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;
import wily.factoryapi.base.client.FactoryOptions;

import java.util.List;
import java.util.function.Function;
import net.minecraft.class_807;
import net.minecraft.class_813;

@Mixin(/*? if >1.21.4 {*//*WeightedVariants*//*?} else {*/class_807/*?}*/.class)
public class MultiVariantMixin {
    //? if <1.21.5 {
    @Mutable
    @Shadow @Final private List<class_813> variants;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void init(List list, CallbackInfo ci) {
        if (!FactoryOptions.RANDOM_BLOCK_ROTATIONS.get()) {
            this.variants = List.of(variants.get(0));
        }
    }
    //?} else {
    /*@Mutable
    @Shadow @Final private WeightedList<BlockStateModel> list;

    @Inject(method = "<init>", at = @At("RETURN"))
    private void init(WeightedList<BlockStateModel> weightedList, CallbackInfo ci) {
        if (!FactoryOptions.RANDOM_BLOCK_ROTATIONS.get()) {
            this.list = WeightedList.of(list.unwrap().getFirst().value());
        }
    }
    *///?}
}

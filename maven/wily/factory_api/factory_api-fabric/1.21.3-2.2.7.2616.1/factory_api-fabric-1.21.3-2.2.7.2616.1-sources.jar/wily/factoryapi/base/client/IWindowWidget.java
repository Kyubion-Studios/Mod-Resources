package wily.factoryapi.base.client;

import wily.factoryapi.base.ArbitrarySupplier;
import wily.factoryapi.base.client.drawable.DrawableStatic;
import wily.factoryapi.util.FactoryScreenUtil;

import java.util.List;
import net.minecraft.class_332;
import net.minecraft.class_364;
import net.minecraft.class_4068;
import net.minecraft.class_768;
import net.minecraft.class_8021;
import net.minecraft.class_8030;

public interface IWindowWidget extends class_364, class_4068 {

    //? if >=1.21.9 {
    /*@Override
    default boolean mouseClicked(MouseButtonEvent mouseButtonEvent, boolean bl) {
        for (Renderable nestedRenderable : getNestedRenderables())
            if (nestedRenderable instanceof GuiEventListener listener && listener.mouseClicked(mouseButtonEvent, bl)) return true;
        return false;
    }
    @Override
    default boolean mouseReleased(MouseButtonEvent mouseButtonEvent) {
        for (Renderable nestedRenderable : getNestedRenderables())
            if (nestedRenderable instanceof GuiEventListener listener && listener.mouseReleased(mouseButtonEvent)) return true;
        return false;
    }
    @Override
    default boolean mouseDragged(MouseButtonEvent mouseButtonEvent, double f, double g) {
        for (Renderable nestedRenderable : getNestedRenderables())
            if (nestedRenderable instanceof GuiEventListener listener && listener.mouseDragged(mouseButtonEvent, f, g)) return true;
        return false;
    }
    *///?} else {
    @Override
    default boolean method_25402(double d, double e, int i) {
        for (class_4068 nestedRenderable : getNestedRenderables())
            if (nestedRenderable instanceof class_364 listener && listener.method_25402(d,e,i)) return true;
        return false;
    }
    @Override
    default boolean method_25406(double d, double e, int i) {
        for (class_4068 nestedRenderable : getNestedRenderables())
            if (nestedRenderable instanceof class_364 listener && listener.method_25406(d,e,i)) return true;
        return false;
    }
    @Override
    default boolean method_25403(double d, double e, int i, double f, double g) {
        for (class_4068 nestedRenderable : getNestedRenderables())
            if (nestedRenderable instanceof class_364 listener && listener.method_25403(d,e,i,f,g)) return true;
        return false;
    }
    //?}

    //? if >=26.1 {
    /*default void extractRenderState(net.minecraft.client.gui.GuiGraphics guiGraphics, int i, int j, float f) {
        for (Renderable nestedRenderable : getNestedRenderables()) {
            nestedRenderable.extractRenderState(guiGraphics,i,j,f);
        }
    }
    *///?} else {
    default void method_25394(class_332 guiGraphics, int i, int j, float f) {
        for (class_4068 nestedRenderable : getNestedRenderables()) {
            nestedRenderable.method_25394(guiGraphics,i,j,f);
        }
    }
    //?}

    default void playDownSound(float grave) {
        FactoryScreenUtil.playButtonDownSound(grave);
    }
    class_768 getBounds();

    boolean isVisible();

    @Override
    default class_8030 method_48202() {
        return FactoryScreenUtil.rect2iToRectangle(getBounds());
    }

    <R extends class_4068> R addNestedRenderable(R drawable);

    List<? extends class_4068> getNestedRenderables();

    default ArbitrarySupplier<class_4068> getNestedAt(int x, int y){
        for (class_4068 nested : getNestedRenderables()) {
            if (nested instanceof class_8021 layout && FactoryScreenUtil.isMouseOver(x,y, layout.method_46426(), layout.method_46427(), layout.method_25364(), layout.method_25368()))
                return ()->nested;
            else if (nested instanceof DrawableStatic drawable && drawable.inMouseLimit(x,y)) return ()->nested;
        }
        return ArbitrarySupplier.empty();
    }
}

package wily.factoryapi.mixin.base;

import com.mojang.authlib.GameProfile;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import wily.factoryapi.base.FactoryExtraMenuSupplier;

import java.util.Optional;
import java.util.function.Consumer;
import net.minecraft.class_124;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_3222;
import net.minecraft.class_3908;

@Mixin(class_3222.class)
public abstract class ServerPlayerMixin extends class_1657 implements FactoryExtraMenuSupplier.PrepareMenu {

    public ServerPlayerMixin(class_1937 level, class_2338 blockPos, float f, GameProfile gameProfile) {
        super(level, /*? if <1.21.6 {*/ blockPos, f,/*?}*/ gameProfile);
    }

    @Shadow protected abstract void nextContainerCounter();

    @Shadow public abstract void method_7346();

    @Shadow protected abstract void initMenu(class_1703 abstractContainerMenu);

    @Shadow private int containerCounter;

    @Override
    public Optional<class_1703> prepareMenu(class_3908 provider, Consumer<class_1703> openClientMenu) {
        if (provider == null) {
            return Optional.empty();
        } else {
            if (this.field_7512 != this.field_7498) {
                this.method_7346();
            }

            this.nextContainerCounter();
            class_1703 abstractContainerMenu = provider.createMenu(this.containerCounter, this.method_31548(), this);
            if (abstractContainerMenu == null) {
                if (this.method_7325()) {
                    //? if >=26.1 {
                    /*this.sendOverlayMessage(Component.translatable("container.spectatorCantOpen").withStyle(ChatFormatting.RED));
                    *///?} else {
                    this.method_7353(class_2561.method_43471("container.spectatorCantOpen").method_27692(class_124.field_1061), true);
                    //?}
                }

                return Optional.empty();
            } else {
                openClientMenu.accept(abstractContainerMenu);
                this.initMenu(abstractContainerMenu);
                this.field_7512 = abstractContainerMenu;
                return Optional.of(field_7512);
            }
        }
    }
}

package wily.factoryapi.base.client.drawable;

import wily.factoryapi.base.client.FactoryGuiMatrixStack;
import wily.factoryapi.util.FluidInstance;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.function.Supplier;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_4068;
import net.minecraft.class_768;

public abstract class AbstractDrawableStatic<D extends AbstractDrawableStatic<D,T>, T extends IFactoryDrawableType> extends class_768 implements IFactoryDrawableType, class_4068{
    public T drawable;
    protected final List<class_2561> tooltips = new ArrayList<>();
    public boolean hovered = false;
    protected class_310 mc = class_310.method_1551();
    public Supplier<Boolean> visible = ()-> true;
    protected IFactoryDrawableType overlay;

    public AbstractDrawableStatic(T drawable, int posX, int posY){
        super(posX,posY,drawable.width(),drawable.height());
        this.drawable = drawable;
    }

    public D overlay(IFactoryDrawableType overlay){
        this.overlay = overlay;
        return (D) this;
    }

    public D visible(Supplier<Boolean> visible){
        this.visible = visible;
        return (D) this;
    }

    public D tooltip(class_2561 component){
        tooltips.add(component);
        return (D) this;
    }

    public D tooltips(List<class_2561> components){
        tooltips.addAll(components);
        return (D) this;
    }

    public D clearTooltips(){
        tooltips.clear();
        return (D) this;
    }

    public void draw(net.minecraft.class_332 graphics) {
        draw(graphics, method_3321(), method_3322());
    }

    @Override
    public void draw(net.minecraft.class_332 graphics, int x, int y) {
        IFactoryDrawableType.super.draw(graphics, x, y);
        FactoryGuiMatrixStack.of(graphics.method_51448()).pushPose();
        FactoryGuiMatrixStack.of(graphics.method_51448()).translate(0F,0F,1F);
        if (overlay != null) {
            int dX = overlay instanceof AbstractDrawableStatic<?,?> d ? d.method_3321() : 0;
            int dY = overlay instanceof AbstractDrawableStatic<?,?> d ? d.method_3322() : 0;
            overlay.draw(graphics, x + dX + (width() - overlay.width()) / 2, y + dY + (height() - overlay.height()) / 2);
        }
        FactoryGuiMatrixStack.of(graphics.method_51448()).popPose();
    }

    @Override
    public boolean isSprite() {
        return drawable.isSprite();
    }

    public void drawAsFluidTank(net.minecraft.class_332 graphics, FluidInstance instance, int capacity, boolean hasColor) {
        drawable.drawAsFluidTank(graphics, method_3321(), method_3322(), instance, capacity, hasColor);
    }
    public boolean inMouseLimit(double mouseX, double mouseY) {
        return drawable.inMouseLimit(mouseX,mouseY,method_3321(),method_3322());
    }

    public net.minecraft.class_2960 texture() {
        return drawable.texture();
    }

    public int width() {
        return method_3319();
    }

    public int height() {
        return method_3320();
    }

    public int uvX() {
        return drawable.uvX();
    }

    public int uvY() {
        return drawable.uvY();
    }

    //? if >=26.1 {

    /*@Override
    public void extractRenderState(GuiGraphicsExtractor graphics, int mouseX, int mouseY, float a) {
        if (!visible.get()) return;
        hovered = inMouseLimit(mouseX, mouseY);
        draw(graphics);
        if (hovered && !tooltips.isEmpty())
            graphics.setTooltipForNextFrame(mc.font, tooltips.stream().map(Component::getVisualOrderText).toList(), mouseX, mouseY);
    }
    *///?} else {
    @Override
    public void method_25394(net.minecraft.class_332 guiGraphics, int i, int j, float f) {
        if (!visible.get()) return;
        hovered = inMouseLimit(i,j);
        draw(guiGraphics);
        //? if >=1.21.6 {
        /*if (hovered && !tooltips.isEmpty()) guiGraphics.setTooltipForNextFrame(mc.font, tooltips.stream().map(Component::getVisualOrderText).toList(), i, j);
        *///?} else {
        if (hovered && !tooltips.isEmpty()) guiGraphics.method_51434(mc.field_1772, tooltips,i,j);
        //?}
    }
    //?}
}

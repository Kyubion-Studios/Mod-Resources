package wily.factoryapi.util;

import com.google.gson.JsonObject;
import com.mojang.serialization.Codec;
import com.mojang.serialization.JsonOps;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1887;
import net.minecraft.class_2487;
import net.minecraft.class_2561;
import net.minecraft.class_5321;
import net.minecraft.class_5455;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9334;
import net.minecraft.class_9336;
import net.minecraft.nbt.*;
import wily.factoryapi.FactoryAPI;
import wily.factoryapi.FactoryAPIPlatform;
import wily.factoryapi.init.FactoryRegistries;

import java.util.*;

public class FactoryItemUtil {
    //? if >=1.20.5 {
    public static final Codec<List<class_1792>> ITEM_COMPONENTS_CODEC = net.minecraft.class_2960.field_25139.xmap(r-> FactoryAPIPlatform.getRegistryValue(r,class_7923.field_41178), class_7923.field_41178::method_10221).listOf();
    public static final class_9139<class_9129,List<class_1792>> ITEM_COMPONENTS_STREAM_CODEC = class_9135.method_56896(ITEM_COMPONENTS_CODEC);
    //?}

    public static class_2487 getFromJson(JsonObject obj){
        return class_2487.field_25128.parse(JsonOps.INSTANCE,obj).result().orElseGet(class_2487::new);
    }

    public static List<class_1792> getItemComponents(class_1799 itemStack){
        //? if <1.20.5 {
        /*List<Item> list = new ArrayList<>();
        if (itemStack.hasTag() && !itemStack.getTag().getList("Components",8).isEmpty())
            itemStack.getTag().getList("Components",8).forEach(t->list.add(BuiltInRegistries.ITEM.get(new net.minecraft.resources.ResourceLocation(t.getAsString()))));
        return list;
        *///?} else {
        return itemStack.method_57825(FactoryRegistries.ITEM_COMPONENTS_COMPONENT.get(),new ArrayList<>());
        //?}
    }

    public static boolean equalItems(class_1799 itemStack, class_1799 itemStack1){
        //? if <1.20.5 {
        /*return ItemStack.isSameItemSameTags(itemStack,itemStack1);
        *///?} else
        return class_1799.method_31577(itemStack,itemStack1);
    }

    public static boolean compareItems(class_1799 itemStack, class_1799 itemStack1, boolean checkCount) {
        return compareItems(itemStack, itemStack1, checkCount, true);
    }

    public static boolean compareItems(class_1799 itemStack, class_1799 itemStack1, boolean checkCount, boolean strict){
        if (strict) {
            if (checkCount) return class_1799.method_7973(itemStack, itemStack1);
            else return equalItems(itemStack, itemStack1);
        } else if (class_1799.method_7984(itemStack, itemStack1) && (!checkCount || itemStack.method_7947() == itemStack1.method_7947())){
            //? if <1.20.5 {
            /*return NbtUtils.compareNbt(itemStack.getTag(), itemStack1.getTag(), true);
            *///?} else {
            for (class_9336<?> component : itemStack1.method_57353()) {
                if (!Objects.equals(itemStack.method_57824(component.comp_2443()),component.comp_2444())) return false;
            }
            //?}
        }
        return false;
    }

    public static boolean hasCustomName(class_1799 stack){
        return /*? if <1.20.5 {*//*stack.hasCustomHoverName()*//*?} else {*/stack.method_57826(class_9334.field_49631)/*?}*/;
    }

    public static void setCustomName(class_1799 stack, class_2561 name){
        //? if <1.20.5 {
        /*if (name == null) stack.resetHoverName();
        else stack.setHoverName(name);
        *///?} else {
        stack.method_57379(class_9334.field_49631,name);
        //?}
    }

    public static int getEnchantmentLevel(class_1799 stack, /*? if >=1.21 {*/ class_5321<class_1887> /*?} else {*//*Enchantment*//*?}*/ enchantment){
        return getEnchantmentLevel(stack, enchantment, FactoryAPI.currentServer.method_30611());
    }

    public static int getEnchantmentLevel(class_1799 stack, /*? if >=1.21 {*/ class_5321<class_1887> /*?} else {*//*Enchantment*//*?}*/ enchantment, class_5455 registryAccess){
        return /*? if <1.21 {*//*EnchantmentHelper.getItemEnchantmentLevel(enchantment, stack)*//*?} else {*/FactoryAPIPlatform.getRegistryValue(registryAccess, enchantment).map(e->stack.method_58657().method_57536(e)).orElse(0)/*?}*/;
    }

    public static class_6880<class_1792> getItemHolder(class_1799 stack) {
        return stack./*? if >=26.1 {*//*typeHolder*//*?} else {*/method_41409/*?}*/();
    }

}

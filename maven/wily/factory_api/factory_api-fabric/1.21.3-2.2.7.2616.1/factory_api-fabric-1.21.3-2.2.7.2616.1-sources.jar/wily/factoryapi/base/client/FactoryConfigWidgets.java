package wily.factoryapi.base.client;


import com.google.gson.JsonIOException;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;
import com.mojang.serialization.DataResult;
import com.mojang.serialization.JsonOps;
import net.minecraft.class_156;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_339;
import net.minecraft.class_342;
import net.minecraft.class_357;
import net.minecraft.class_5676;
import net.minecraft.class_7172;
import net.minecraft.class_7919;
import net.minecraft.client.gui.components.*;
import wily.factoryapi.base.config.FactoryConfig;
import wily.factoryapi.base.config.FactoryConfigControl;
import wily.factoryapi.base.config.FactoryConfigDisplay;


import java.io.StringReader;
import java.util.ArrayList;
import java.util.List;
import java.util.function.*;

public class FactoryConfigWidgets {
    private static final List<WidgetOverride<?>> overrides = new ArrayList<>();
    public static final Function<class_2561,class_7919> TOOLTIP_CACHE = class_156.method_34866(c->class_7919.method_47407(c));

    public static class_7919 getCachedTooltip(class_2561 component) {
        return component == null ? null : TOOLTIP_CACHE.apply(component);
    }

    public interface WidgetOverride<T> {
        class_339 createWidget(FactoryConfig<T> config, Function<T,class_7919> tooltip, int x, int y, int width, Consumer<T> afterSet);
    }

    public static <T> class_339 getOverride(FactoryConfig<T> config, Function<T,class_7919> tooltipFunction, int x, int y, int width, Consumer<T> afterSet) {
        for (WidgetOverride<?> override : overrides) {
            class_339 widgetOverride = ((WidgetOverride<T>)override).createWidget(config, tooltipFunction, x, y, width, afterSet);
            if (widgetOverride != null) return widgetOverride;
        }
        return null;
    }

    public static <T> class_339 createWidget(FactoryConfig<T> config, int x, int y, int width, Consumer<T> afterSet) {
        FactoryConfigDisplay<T> display = config.getDisplay();
        Function<T,class_7919> tooltipFunction = v -> getCachedTooltip(display.tooltip().apply(v));
        class_339 override = getOverride(config, tooltipFunction, x, y, width, afterSet);
        if (override != null) return override;
        if (config.control().equals(FactoryConfigControl.TOGGLE)) {
            return class_5676.<Boolean>method_32606(b -> display.valueToComponent().apply((T) b)/*? if >=1.21.11 {*//*, () -> (Boolean) config.get()*//*?}*/).method_42729(class_7172.field_38278.method_42721()).method_32618(((Function<Boolean, class_7919>) tooltipFunction)::apply)/*? if <1.21.11 {*/.method_32619((Boolean) config.get())/*?}*/.method_32617(x, y, width, 20, display.name(), (cycleButton, object) -> FactoryConfig.saveOptionAndConsume(config, (T)object, afterSet));
        } else if (config.control() instanceof FactoryConfigControl.FromInt<T> c) {
            return class_5676.method_32606(display.valueToComponent()/*? if >=1.21.11 {*//*, config*//*?}*/).method_42729(listSupplier(c.valueGetter(), c.valuesSize())).method_32618(tooltipFunction::apply)/*? if <1.21.11 {*/.method_32619(config.get())/*?}*/.method_32617(x, y, width, 20, display.name(), (cycleButton, object) -> FactoryConfig.saveOptionAndConsume(config, object,afterSet));
        } else if (config.control() instanceof FactoryConfigControl.FromDouble<T> c) {
            return createSlider(config, x, y, width, afterSet, c.valueGetter(), c.valueSetter(), tooltipFunction);
        } else if (config.control() instanceof FactoryConfigControl.Int c) {
            return createSlider((FactoryConfig<Integer>)config, x, y, width, (Consumer<Integer>)afterSet, d-> (int)((c.max().getAsInt() - c.min()) * d) + c.min(), i->  (double)(i - c.min()) / (c.max().getAsInt() - c.min()), (Function<Integer, class_7919>) tooltipFunction);
        } else if (config.control() instanceof FactoryConfigControl.TextEdit<T> c) {
            class_342 editBox = new class_342(class_310.method_1551().field_1772, x, y, width, 20, display.name());

            c.codec().encodeStart(JsonOps.INSTANCE, config.get()).result().ifPresent(v-> editBox.method_1852(v.toString()));
            editBox.method_1863(s -> {
                DataResult<T> result;
                try {
                    result = c.codec().parse(JsonOps.INSTANCE, JsonParser.parseReader(new StringReader(s)));
                } catch (JsonIOException | JsonSyntaxException e) {
                    result = DataResult.error(e::getMessage);
                }
                if (result.result().isPresent()) {
                    editBox.method_1868(0xE0E0E0);
                    config.set(result.result().get());
                    config.save();
                    editBox.method_47400(tooltipFunction.apply(config.get()));
                } else {
                    editBox.method_1868(0xFF5555);
                    editBox.method_47400(class_7919.method_47407(class_2561.method_43470(result.error().get().message())));
                }
            });
            return editBox;
        }
        return null;
    }

    public static <T> class_357 createSlider(FactoryConfig<T> config, int x, int y, int width, Consumer<T> afterSet, Function<Double,T> valueGetter, Function<T,Double> valueSetter, Function<T,class_7919> tooltipFunction) {
        return new class_357(x, y, width, 20, config.getDisplay().getMessage(config.get()), valueSetter.apply(config.get())) {
            @Override
            protected void method_25346() {
                method_25355(config.getDisplay().getMessage(valueGetter.apply(field_22753)));
                method_47400(tooltipFunction.apply(valueGetter.apply(field_22753)));
            }

            @Override
            protected void method_25344() {
                FactoryConfig.saveOptionAndConsume(config, valueGetter.apply(field_22753), afterSet);
                field_22753 = valueSetter.apply(config.get());
            }
        };
    }

    public static <T> class_339 createWidget(FactoryConfig<T> config) {
        return createWidget(config, 0, 0, 0, v-> {});
    }

    public static <T> class_5676.class_5680<T> listSupplier(Function<Integer,T> valueGetter, Supplier<Integer> valuesSize) {
        List<T> list = new ArrayList<>();
        for (int i = 0; i < valuesSize.get(); i++) {
            list.add(valueGetter.apply(i));
        }
        return class_5676.class_5680.method_32627(list);
    }
}
//? if <1.21.4 {
package wily.factoryapi.mixin.base;

import net.minecraft.class_1799;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_756;
import net.minecraft.class_811;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;
import wily.factoryapi.base.client.IFactoryBlockEntityWLRenderer;
import wily.factoryapi.base.client.IFactoryItemClientExtension;

@Mixin(class_756.class)
public abstract class BlockEntityWithoutLevelRendererMixin {
    @Inject(method = "renderByItem", at = @At("HEAD"), cancellable = true)
    private void injectRender(class_1799 itemStack, class_811 itemDisplayContext, class_4587 poseStack, class_4597 multiBufferSource, int i, int j, CallbackInfo info){
        if (!itemStack.method_7960()) {
            IFactoryItemClientExtension e;
            IFactoryBlockEntityWLRenderer beWLR;
            if ((e = IFactoryItemClientExtension.map.get(itemStack.method_7909())) == null || (beWLR = e.getCustomRenderer()) == null) return;
            beWLR.renderByItem(itemStack, itemDisplayContext, poseStack, multiBufferSource, i, j);
            info.cancel();
        }
    }
}
//?}
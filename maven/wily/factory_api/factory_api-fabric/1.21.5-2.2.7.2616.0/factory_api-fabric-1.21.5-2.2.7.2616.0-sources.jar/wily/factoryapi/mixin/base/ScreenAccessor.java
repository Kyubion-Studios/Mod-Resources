package wily.factoryapi.mixin.base;

import net.minecraft.class_437;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_437.class)
public interface ScreenAccessor {
	//? if >=1.21.6 {
	/*@Invoker
	static void callDefaultHandleGameClickEvent(ClickEvent clickEvent, Minecraft minecraft, Screen screen) {
		throw new UnsupportedOperationException();
	}
	*///?}
}

package wily.factoryapi.base;

import wily.factoryapi.FactoryAPI;
import wily.factoryapi.util.ListMap;

public record FactoryStorage<T extends IPlatformHandler>(Class<T> type) {

    public static final ListMap<net.minecraft.resources.Identifier, FactoryStorage<?>> STORAGES = new ListMap<>();

    public static <T extends FactoryStorage<?>> T register(net.minecraft.resources.Identifier location, T storage){
        STORAGES.put(location,storage);
        return storage;
    }
    public static <T extends FactoryStorage<?>> T registerDefault(String name, T storage){
        return register(FactoryAPI.modIdentifier(name),storage);
    }

    public static final FactoryStorage<IPlatformFluidHandler> FLUID = registerDefault("fluid_storage", new FactoryStorage<>(IPlatformFluidHandler.class));
    public static final FactoryStorage<IPlatformItemHandler> ITEM = registerDefault("item_storage",new FactoryStorage<>(IPlatformItemHandler.class));
    public static final FactoryStorage<IPlatformEnergyStorage> ENERGY = registerDefault("energy_storage",new FactoryStorage<>(IPlatformEnergyStorage.class));
    public static final FactoryStorage<ICraftyEnergyStorage> CRAFTY_ENERGY = registerDefault("crafty_energy_storage",new FactoryStorage<>(ICraftyEnergyStorage.class));

}